"""W2 real distributed ConFIRM services: producer, independent verifier, consumer.

No simulated reasoner. All actual GO/GAF source reads and frontier/decision
replay are performed by the existing publisher/checker in distinct Python
Docker containers. Only the verifier and consumer receive the operator's
random HMAC receipt key. They DO NOT trust any producer assertion.

Threat boundary: controlled Docker filesystem separation with a trusted host,
operator and receipt channel. No remote hostile kernel/host guarantee.
"""
from __future__ import annotations
import hashlib
import hmac
import json
import os
import subprocess
import sys
import tempfile
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

REPO=Path("/app")
SOURCE=Path("/sources")
OPERATOR=Path("/operator")
ROLE=os.environ["W2_ROLE"]
PORT=int(os.environ.get("W2_PORT","8080"))
MAX_HTTP=24*1024*1024
MAX_EVENTS=100000
MAX_DEPTH=3

def encode(v):
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=True).encode("utf-8")

def digest(v):
    return hashlib.sha256(encode(v)).hexdigest()

def operator_contract():
    # On container startup, the trusted operator controls this read-only
    # bind-mounted directory; producers never receive this mount.
    return json.loads((OPERATOR/"active.json").read_text(encoding="utf-8"))

def key():
    return (OPERATOR/"receipt.key").read_bytes()

def signature(payload):
    return hmac.new(key(),encode(payload),hashlib.sha256).hexdigest()

def parse_claim(verdicts,query):
    if verdicts==[]:return "UNKNOWN"
    if not isinstance(verdicts,list) or len(verdicts)!=1:
        return "INVALID"
    row=verdicts[0]
    if not isinstance(row,list) or len(row)!=4 or row[0]!=query:
        return "INVALID"
    status,trusted,candidate=row[1:]
    if type(trusted)!=int or type(candidate)!=int or trusted<0 or candidate<0:
        return "INVALID"
    if status=="PROVEN" and trusted>=1:return status
    if status=="HYPOTHESIZED" and trusted==0 and candidate>=1:return status
    if status=="REFUTED" and trusted==0 and candidate==0:return status
    return "INVALID"


def actual_producer(request):
    version=request.get("producer_version")
    if version not in ("v1","v2"):
        return {"ok":False,"reason":"producer_revision_not_registered"}
    ids=request.get("query_indices")
    if ids!=[0,8,16,32]:
        return {"ok":False,"reason":"unsupported_original_source_query_cohort"}
    path=SOURCE/version
    with tempfile.TemporaryDirectory(prefix="w2_producer_") as tmp:
        trace=Path(tmp)/"transcript.json"
        start=time.perf_counter()
        res=subprocess.run([
            sys.executable,str(REPO/"scripts/capture_www2027_go_transition_audit.py"),
            "--processed",str(path),"--source-indices",",".join(map(str,ids)),
            "--max-depth",str(MAX_DEPTH),"--budget","4000",
            "--max-seconds","30","--output",str(trace)
        ],text=True,capture_output=True,timeout=100)
        seconds=round(time.perf_counter()-start,6)
        if res.returncode!=0 or not trace.is_file():
            return {"ok":False,"reason":"producer_failed","stderr_tail":res.stderr[-450:]}
        obj=json.loads(trace.read_text(encoding="utf-8"))
        if obj.get("passed_capture_completeness") is not True:
            return {"ok":False,"reason":"producer_incomplete"}
        return {"ok":True,"trace":obj,"producer_wall_seconds":seconds}


def independent_verifier(request):
    from trustkg.independent_transition_audit import trusted_go_snapshot,canonical_sha256
    active=operator_contract()
    source=SOURCE/active["revision"]
    pin=canonical_sha256(trusted_go_snapshot(source))
    if pin!=active["source_pin"]:
        return {"ok":False,"reason":"operator_trusted_source_changed"}
    if active.get("indices")!=[0,8,16,32]:
        return {"ok":False,"reason":"wrong_trusted_operator_query_contract"}
    trace=request.get("trace")
    if not isinstance(trace,dict):return {"ok":False,"reason":"invalid_untrusted_producer_json"}
    ids=active["indices"]
    from verify_www2027_go_transition_audit import audit_file
    with tempfile.TemporaryDirectory(prefix="w2_checker_") as tmp:
        t=Path(tmp)/"input.json"
        report_file=Path(tmp)/"report.json"
        t.write_bytes(encode(trace)+b"\n")
        begin=time.perf_counter()
        report=audit_file(input_path=t,processed=source,source_indices=ids,
                          max_depth=MAX_DEPTH,max_events=MAX_EVENTS,
                          output_path=report_file)
        wall=round(time.perf_counter()-begin,6)
    if report.get("passed") is not True or report.get("independent_verdict_reconstruction_passed") is not True:
        return {"ok":False,"reason":(report.get("failures") or [{}])[0].get("reason","full_verification_failed"),
                "verifier_wall_seconds":wall,"structured_rejection":bool(report.get("failures"))}
    rows=report.get("independent_verdict_rows",[])
    if len(rows)!=len(ids):
        return {"ok":False,"reason":"independent_claim_row_count_mismatch"}
    statuses=[]
    for i,r in enumerate(rows):
        if r.get("source_index")!=ids[i] or r.get("equal") is not True:
            return {"ok":False,"reason":"independent_source_order_or_claim_mismatch"}
        label=parse_claim(r.get("verdicts"),active["queries"][i])
        if label=="INVALID":
            return {"ok":False,"reason":"independent_claim_schema_invalid"}
        statuses.append(label)
    receipt={
        "protocol":"W2_SOURCE_PINNED_VERIFIER_RECEIPT_v1",
        "source_pin":active["source_pin"],
        "revision":active["revision"],
        "query_manifest_sha256":active["query_manifest_sha256"],
        "indices":ids,
        "trace_sha256":digest(trace),
        "nonce":request.get("nonce"),
        "issued_unix":int(time.time()),
        "statuses":statuses,
        "certificate_count":report["certificate_count"],
        "complete_frontier_replay":True,
    }
    if not isinstance(receipt["nonce"],str) or len(receipt["nonce"])<12:
        return {"ok":False,"reason":"missing_operator_request_nonce"}
    return {"ok":True,"receipt":receipt,"mac":signature(receipt),
            "verifier_wall_seconds":wall}


USED_NONCES=set()

def action_consumer(request):
    active=operator_contract()
    trace=request.get("trace")
    packet=request.get("signed_verifier_receipt")
    # Rejections themselves contain no evidence of source claims;
    # fail closed and return visible QUARANTINE disposition.
    denied={
        "ok":True,"authorized":0,"denied_negative":0,
        "abstained":0,"quarantined":len(active["indices"]),
        "actions":["QUARANTINE_UNVERIFIED"]*len(active["indices"]),
        "verified_receipt":False,
    }
    if not isinstance(trace,dict) or not isinstance(packet,dict):
        return denied
    receipt=packet.get("receipt")
    mac=packet.get("mac")
    if not isinstance(receipt,dict) or not isinstance(mac,str):
        return denied
    if not hmac.compare_digest(signature(receipt),mac):
        return denied
    if receipt.get("protocol")!="W2_SOURCE_PINNED_VERIFIER_RECEIPT_v1":
        return denied
    if (receipt.get("source_pin")!=active["source_pin"]
        or receipt.get("revision")!=active["revision"]
        or receipt.get("query_manifest_sha256")!=active["query_manifest_sha256"]
        or receipt.get("indices")!=active["indices"]
        or receipt.get("trace_sha256")!=digest(trace)
        or receipt.get("nonce")!=request.get("nonce")):
        return denied
    if not isinstance(receipt.get("nonce"),str) or len(receipt["nonce"])<12:
        return denied
    if abs(int(time.time())-receipt.get("issued_unix",0))>90:
        return denied
    if receipt["nonce"] in USED_NONCES:return denied
    statuses=receipt.get("statuses")
    if not isinstance(statuses,list) or len(statuses)!=len(active["indices"]):
        return denied
    if any(s not in ("PROVEN","REFUTED","HYPOTHESIZED","UNKNOWN") for s in statuses):
        return denied
    USED_NONCES.add(receipt["nonce"])
    actions=[
        "AUTHORIZE_SOURCE_GROUNDED_CONSUMPTION" if s=="PROVEN" else
        "DENY_QUALIFIED_NEGATIVE" if s=="REFUTED" else
        "ABSTAIN_UNPROVEN"
        for s in statuses
    ]
    return {
        "ok":True,"authorized":actions.count("AUTHORIZE_SOURCE_GROUNDED_CONSUMPTION"),
        "denied_negative":actions.count("DENY_QUALIFIED_NEGATIVE"),
        "abstained":actions.count("ABSTAIN_UNPROVEN"),
        "quarantined":0,"actions":actions,"verified_receipt":True,
    }


class Handler(BaseHTTPRequestHandler):
    def _reply(self,code,body):
        data=encode(body)
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path=="/health":
            return self._reply(200,{"ok":True,"role":ROLE})
        return self._reply(404,{"ok":False,"reason":"unknown_endpoint"})

    def do_POST(self):
        if self.path!="/work":
            return self._reply(404,{"ok":False,"reason":"unknown_endpoint"})
        size=int(self.headers.get("Content-Length","0"))
        if size<1 or size>MAX_HTTP:
            return self._reply(413,{"ok":False,"reason":"request_too_large"})
        try:
            data=json.loads(self.rfile.read(size))
            if ROLE=="producer":result=actual_producer(data)
            elif ROLE=="verifier":result=independent_verifier(data)
            elif ROLE=="consumer":result=action_consumer(data)
            else:raise ValueError("unknown W2 service role")
            return self._reply(200,result)
        except Exception as exc:
            # Transport/network errors never produce a trusted certificate.
            return self._reply(500,{"ok":False,"reason":"service_execution_failed",
                                    "error_type":type(exc).__name__,
                                    "detail":str(exc)[:500]})

    def log_message(self,format,*args):
        return


if __name__=="__main__":
    ThreadingHTTPServer(("0.0.0.0",PORT),Handler).serve_forever()
