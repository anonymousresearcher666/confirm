"""Capture certificate events from full processed GO/GO-CAM search.

This is an engine-generated trace, not an independently authenticated
transcript. Offline replay checks consistency, not historical attestation.
"""
from __future__ import annotations
import argparse
import json
from collections import Counter
from pathlib import Path
from time import perf_counter

from trustkg.kb import Atom, KnowledgeBase, Rule
from trustkg.trust import TRUSTED, CertifiedReasoner, Schema, TrustContext, aggregate_claim_decisions
from trustkg.certificate_evidence import atom_data, snapshot_data, snapshot_digest, subsumption_state_data


def rows(path, limit=None):
    with Path(path).open(encoding="utf-8") as stream:
        for index, line in enumerate(stream):
            if limit is not None and index >= limit:
                break
            if line.strip():
                yield json.loads(line)


def context_from_go(root, max_facts):
    facts = [Atom(row["predicate"], tuple(row["args"]))
             for row in rows(root / "facts.jsonl", max_facts)]
    trusted = list(rows(root / "trusted_rules.jsonl"))
    rules = []
    for row in trusted:
        expr = row["compiled_expression"]
        head = expr["head"]
        rules.append(Rule(
            row["rule_id"],
            Atom(head["predicate"], tuple(head["args"])),
            tuple(Atom(x["predicate"], tuple(x["args"])) for x in expr["body"]),
        ))
    obj = json.loads((root / "schema.json").read_text(encoding="utf-8"))
    schema = Schema(
        types={key: frozenset(values) for key, values in obj.get("types", {}).items()},
        domain=obj.get("domain", {}), range_=obj.get("range", {}),
        disjoint=frozenset(frozenset(p) for p in obj.get("disjoint", [])),
        functional=frozenset(obj.get("functional", [])),
        irreflexive=frozenset(obj.get("irreflexive", [])),
    )
    # Real GO inputs may optionally carry operator-controlled explicit negatives.
    # Previous producer omitted these while the independent verifier loaded them,
    # making end-to-end source semantics diverge on such datasets.
    negatives_path = root / "negatives.jsonl"
    negatives = frozenset(
        Atom(row["predicate"], tuple(row["args"]))
        for row in rows(negatives_path)
    ) if negatives_path.is_file() else frozenset()
    return TrustContext(
        KnowledgeBase(facts=facts, rules=rules), schema=schema,
        negatives=negatives,
        rule_status={row["rule_id"]: row.get("status", TRUSTED)
                     for row in trusted},
    )


def signature(answers):
    return sorted(
        [[atom_data(d.claim), d.status, d.trusted_proof_count,
          d.candidate_proof_count]
         for d in aggregate_claim_decisions(answers)],
        key=repr,
    )


class TracingReasoner(CertifiedReasoner):
    def __init__(self, context, *, max_depth, digest):
        super().__init__(context, max_depth=max_depth)
        self.events = []
        self.expanded = []
        self.digest = digest

    def _expand(self, state):
        item = subsumption_state_data(state)
        self.events.append({"type": "expanded", "state": item})
        self.expanded.append(item)
        return super()._expand(state)

    def certify(self, state, seen):
        cert = super().certify(state, seen)
        if cert is None:
            return None
        if cert.kind == "C-SUBSUME":
            now = subsumption_state_data(state)
            attrs = ("query", "goals", "proof", "substitution")
            indices = [
                i for i, old in enumerate(self.expanded)
                if old["depth"] <= now["depth"]
                and all(old[key] == now[key] for key in attrs)
            ]
            record = {
                "version": 2, "kind": cert.kind, "state": now,
                "snapshot_sha256": self.digest, "max_depth": self.max_depth,
                "witness": {"seen_index": indices[0] if indices else -1},
            }
        else:
            witness = cert.witness
            if isinstance(witness, Atom):
                witness = atom_data(witness)
            elif isinstance(witness, tuple):
                witness = list(witness)
            record = {
                "version": 1, "kind": cert.kind,
                "state": {
                    "goals": [atom_data(a) for a in state.normalized_goals()],
                    "depth": state.depth,
                },
                "snapshot_sha256": self.digest, "max_depth": self.max_depth,
                "witness": witness,
            }
        self.events.append({"type": "certificate", "evidence": record})
        return cert


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--processed", type=Path, default=Path("data/go_case_study/processed"))
    p.add_argument("--queries", type=int, default=2)
    p.add_argument("--max-facts", type=int, default=None,
                   help="Subset smoke only; omit to load all available facts")
    p.add_argument("--max-depth", type=int, default=3)
    p.add_argument("--budget", type=int, default=500)
    p.add_argument("--output", type=Path,
                   default=Path("results/www2027/go_certificates_full_trace.json"))
    args = p.parse_args()
    if args.queries < 1 or args.budget < 1 or args.max_depth < 0:
        p.error("invalid query count, budget, or depth")
    start = perf_counter()
    context = context_from_go(args.processed, args.max_facts)
    snapshot = snapshot_data(context)
    digest = snapshot_digest(snapshot)
    queries = list(rows(args.processed / "queries.jsonl", args.queries))
    if not queries:
        raise ValueError("No queries found in processed GO data")
    loading_seconds = perf_counter() - start
    runs, traces = [], []
    for i, item in enumerate(queries):
        q = item["query"]
        query = Atom(q["predicate"], tuple(q["args"]))
        t0 = perf_counter()
        baseline, base_stats = CertifiedReasoner(
            context, max_depth=args.max_depth
        ).search(query, certified=True, budget=args.budget)
        baseline_seconds = perf_counter() - t0
        logged = TracingReasoner(context, max_depth=args.max_depth, digest=digest)
        t1 = perf_counter()
        observed, logged_stats = logged.search(
            query, certified=True, budget=args.budget
        )
        capture_seconds = perf_counter() - t1
        traces.append({"query": atom_data(query), "events": logged.events})
        kinds = dict(Counter(
            x["evidence"]["kind"] for x in logged.events
            if x["type"] == "certificate"
        ))
        runs.append({
            "query_index": i, "query": atom_data(query),
            "baseline_decisions": signature(baseline),
            "captured_decisions": signature(observed),
            "matches_baseline": signature(baseline) == signature(observed),
            "complete": not base_stats.exhausted_budget and not logged_stats.exhausted_budget,
            "baseline_expanded": base_stats.expanded,
            "captured_expanded": logged_stats.expanded,
            "certificate_kinds": kinds,
            "baseline_seconds": round(baseline_seconds, 6),
            "capture_seconds": round(capture_seconds, 6),
        })
    payload = {
        "experiment": "www27_full_go_certificate_trace_v1",
        "trust_limit": "Untrusted self-issued log; independently authenticated state history not yet implemented",
        "processed": str(args.processed),
        "max_facts": args.max_facts, "facts_loaded": len(context.kb.facts),
        "trusted_rules_loaded": len(context.kb.rules),
        "max_depth": args.max_depth, "budget": args.budget,
        "snapshot_sha256": digest, "snapshot": snapshot,
        "queries": traces, "runs": runs,
        "load_seconds": round(loading_seconds, 6),
        "passed": all(x["matches_baseline"] and x["complete"] for x in runs),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, separators=(",", ":")) + "\n",
                           encoding="utf-8")
    print(json.dumps({
        "experiment": payload["experiment"],
        "facts_loaded": payload["facts_loaded"],
        "trusted_rules_loaded": payload["trusted_rules_loaded"],
        "queries": len(traces), "load_seconds": payload["load_seconds"],
        "snapshot_sha256": digest, "passed": payload["passed"],
        "runs": [
            {key: x[key] for key in (
                "query_index", "matches_baseline", "complete",
                "baseline_expanded", "captured_expanded",
                "certificate_kinds", "baseline_seconds", "capture_seconds"
            )}
            for x in runs
        ],
        "output": str(args.output),
    }, indent=2))
    if not payload["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
