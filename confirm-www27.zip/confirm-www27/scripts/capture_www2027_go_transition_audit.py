"""Capture a NEW independently replayable GO search trace (audit protocol v2).

Unlike legacy certificate trace v1, each expanded state includes ALL
generated children, terminal states are recorded, and producer-side raw
states/proof/substitution are explicit. Trace remains a LOCAL artifact;
only concise independently checked experiment reports are pushed.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from time import perf_counter

from trustkg.kb import Atom
from trustkg.trust import CertifiedReasoner
from trustkg.certificate_evidence import (
    atom_data, full_snapshot_data, full_state_data,
    snapshot_digest, subsumption_state_data,
)
from capture_www2027_go_certificate_trace import context_from_go, rows, signature


class AuditTracingReasoner(CertifiedReasoner):
    def __init__(self, context, *, max_depth, digest):
        super().__init__(context, max_depth=max_depth)
        self.digest = digest
        self.events = []
        self.expanded = []

    def _expand(self, state):
        children = CertifiedReasoner._expand(self, state)
        self.events.append({
            "type": "expanded",
            "state": full_state_data(state),
            "children": [full_state_data(c) for c in children],
        })
        self.expanded.append(subsumption_state_data(state))
        return children

    def _completed_proof_is_consistent(self, state):
        valid = CertifiedReasoner._completed_proof_is_consistent(self, state)
        self.events.append({
            "type": "terminal", "state": full_state_data(state),
            "consistent": valid,
        })
        return valid

    def certify(self, state, seen):
        cert = CertifiedReasoner.certify(self, state, seen)
        if cert is None:
            return None
        if cert.kind == "C-SUBSUME":
            witness_state = subsumption_state_data(state)
            keys = ("query", "goals", "proof", "substitution")
            eligible = [
                i for i, prior in enumerate(self.expanded)
                if prior["depth"] <= witness_state["depth"]
                and all(prior[key] == witness_state[key] for key in keys)
            ]
            evidence = {
                "version": 2,
                "kind": cert.kind, "state": witness_state,
                "snapshot_sha256": self.digest,
                "max_depth": self.max_depth,
                "witness": {"seen_index": eligible[0] if eligible else -1},
            }
        else:
            witness = cert.witness
            if isinstance(witness, Atom):
                witness = atom_data(witness)
            elif isinstance(witness, tuple):
                witness = list(witness)
            evidence = {
                "version": 1, "kind": cert.kind,
                "state": {
                    "goals": [
                        atom_data(a) for a in state.normalized_goals()
                    ],
                    "depth": state.depth,
                },
                "snapshot_sha256": self.digest,
                "max_depth": self.max_depth,
                "witness": witness,
            }
        self.events.append({
            "type": "certificate",
            "state": full_state_data(state),
            "evidence": evidence,
        })
        return cert


def capture(*, processed, source_indices, max_depth, budget, max_seconds,
            output):
    start = perf_counter()
    context = context_from_go(processed, None)
    full_snapshot = full_snapshot_data(context)
    digest = snapshot_digest(full_snapshot)
    source = list(rows(processed / "queries.jsonl"))
    if any(i < 0 or i >= len(source) for i in source_indices):
        raise ValueError("One or more query indices are outside queries.jsonl")
    loaded_seconds = perf_counter() - start
    runs, traces = [], []
    for source_index in source_indices:
        item = source[source_index]["query"]
        query = Atom(item["predicate"], tuple(item["args"]))
        producer = AuditTracingReasoner(
            context, max_depth=max_depth, digest=digest,
        )
        begun = perf_counter()
        observed, stats = producer.search(
            query, certified=True, budget=budget,
            max_seconds=max_seconds,
        )
        elapsed = perf_counter() - begun
        complete = not stats.exhausted_budget
        traces.append({
            "source_index": source_index,
            "query": atom_data(query),
            "events": producer.events,
        })
        # Never infer REFUTED from zero returned derivations. The producer
        # must actually return a direct contradiction witness, which the
        # separate verifier will reconstruct from its trusted inputs.
        direct_refutations = [
            answer for answer in observed
            if answer.status == "REFUTED"
            and not answer.proof and answer.refutation is not None
            and answer.claim == query
        ]
        if len(direct_refutations) > 1:
            raise ValueError("ambiguous direct negative witness")
        witness = ({
            "kind": "trusted_direct_contradiction",
            "claim": atom_data(query),
            "reason": direct_refutations[0].refutation,
            "trusted_snapshot_sha256": digest,
        } if direct_refutations else None)
        runs.append({
            **({"refutation_witness": witness} if witness else {}),
            "source_index": source_index,
            "complete": complete,
            "seconds": round(elapsed, 6),
            "expanded": stats.expanded,
            "generated": stats.generated,
            "certificates_by_kind": dict(Counter(
                event["evidence"]["kind"]
                for event in producer.events
                if event["type"] == "certificate"
            )),
            "terminal_events": sum(
                event["type"] == "terminal" for event in producer.events
            ),
            "decision_summary": signature(observed),
        })
        print("AUDIT_CAPTURE_PROGRESS " + json.dumps({
            "source_index": source_index, "complete": complete,
            "events": len(producer.events),
            "expanded": stats.expanded,
            "certificates": runs[-1]["certificates_by_kind"],
        }), flush=True)
    payload = {
        "protocol": "independent_go_transition_audit_v2",
        "trust_boundary": (
            "All trace events are producer-controlled. Separate verifier "
            "MUST load original facts/rules/query from trusted local files "
            "and recompute transitions; trace digest alone is not an anchor."
        ),
        "producer_snapshot_sha256": digest,
        "source_indices": source_indices,
        "facts_loaded": len(context.kb.facts),
        "rules_loaded": len(context.kb.rules),
        "max_depth": max_depth,
        "budget": budget,
        "max_seconds": max_seconds,
        "load_seconds": round(loaded_seconds, 6),
        "queries": traces,
        "runs": runs,
        "passed_capture_completeness": all(run["complete"] for run in runs),
    }
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(payload, separators=(",", ":"), ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    return payload


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--processed", type=Path,
                        default=Path("data/go_case_study/processed"))
    parser.add_argument("--source-indices", type=str, default="0,1")
    parser.add_argument("--max-depth", type=int, default=3)
    parser.add_argument("--budget", type=int, default=1000)
    parser.add_argument("--max-seconds", type=float, default=20.0)
    parser.add_argument("--output", type=Path, default=Path(
        "results/www2027/audit_v2_full_trace.json"
    ))
    args = parser.parse_args()
    try:
        indices = [int(s.strip()) for s in args.source_indices.split(",")]
    except ValueError:
        parser.error("--source-indices must be comma-separated integers")
    if (not indices or len(indices) != len(set(indices))
            or args.max_depth < 0 or args.budget < 1
            or args.max_seconds <= 0):
        parser.error("invalid source index/depth/budget/time")
    report = capture(
        processed=args.processed,
        source_indices=indices, max_depth=args.max_depth,
        budget=args.budget, max_seconds=args.max_seconds,
        output=args.output,
    )
    print(json.dumps({
        "protocol": report["protocol"],
        "producer_snapshot_sha256": report["producer_snapshot_sha256"],
        "facts_loaded": report["facts_loaded"],
        "source_indices": report["source_indices"],
        "passed_capture_completeness": report["passed_capture_completeness"],
        "output": str(args.output),
        "runs": [{
            key: row[key] for key in (
                "source_index", "complete", "expanded", "generated",
                "certificates_by_kind", "terminal_events",
            )
        } for row in report["runs"]],
    }, indent=2))
    if not report["passed_capture_completeness"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
