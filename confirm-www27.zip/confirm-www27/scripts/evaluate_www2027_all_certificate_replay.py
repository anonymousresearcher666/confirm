"""End-to-end independently replayed FIVE-certificate controlled GO probes.

A fresh trusted-verifier OS process independently reloads operator-provided
facts/rules/schema/statuses/queries from a TEMPORARY, source-pinned
controlled fixture and replays the entire producer frontier. The first
five probes reuse established real-GO+labelled-diagnostic cases,
plus separately labelled mixed trusted/candidate and candidate-only
derivations. Each run also checks an unpruned reference search,
aggregated verdict/proof counts, and two producer tampering attempts.

Controlled fixtures and traces are ephemeral: compact summary JSON
is the only published scientific artifact. This does NOT establish
five-certificate *natural frequency* or real-world source authentication.

REFUTED is not manufactured as a trusted full frontier terminal;
its controlled verifier-only unit tests are separately gated.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path
from time import perf_counter

from trustkg.kb import Atom, KnowledgeBase, Rule
from trustkg.trust import CANDIDATE, TRUSTED, CertifiedReasoner, TrustContext
from trustkg.certificate_evidence import atom_data, full_snapshot_data, snapshot_digest
from capture_www2027_go_certificate_trace import context_from_go, signature
from capture_www2027_go_transition_audit import AuditTracingReasoner
from evaluate_www2027_go_controlled_certificates import _cases, _pick_entities

ROOT=Path(__file__).resolve().parents[1]
VERIFY=ROOT/"scripts/verify_www2027_controlled_full_replay.py"
EXPECTED_KINDS=("C-PRE","C-TYPE","C-DEPTH","C-SUBSUME","C-UNSAT")


def sha256(path):
    h=hashlib.sha256()
    with path.open("rb") as stream:
        for b in iter(lambda: stream.read(1<<20),b""):
            h.update(b)
    return h.hexdigest()


def write_jsonlines(path, rows):
    path.write_text(
        "".join(json.dumps(x,sort_keys=True)+"\n" for x in rows),
        encoding="utf-8",
    )


def write_processed_fixture(path,context,query):
    path.mkdir(parents=True,exist_ok=True)
    snapshot=full_snapshot_data(context)
    write_jsonlines(path/"facts.jsonl",snapshot["facts"])
    write_jsonlines(path/"negatives.jsonl",snapshot["negatives"])
    write_jsonlines(path/"queries.jsonl",[{"query":atom_data(query)}])
    write_jsonlines(path/"trusted_rules.jsonl",[
        {
            "rule_id":r["name"],"status":r["status"],
            "compiled_expression":{"head":r["head"],"body":r["body"]},
            "fixture_provenance":"controlled_audit_only",
        } for r in snapshot["rules"]
    ])
    (path/"schema.json").write_text(
        json.dumps(snapshot["schema"],sort_keys=True)+"\n",encoding="utf-8"
    )
    return {
        "snapshot_sha256":snapshot_digest(snapshot),
        "files_sha256":{
            p.name:sha256(p) for p in sorted(path.iterdir()) if p.is_file()
        },
    }


def mixed_cases(base):
    _,support,_=_pick_entities(base)
    gene=support.args[0]
    trusted=Rule(
        "diagnostic_mixed_trusted",Atom("diagnostic_mixed",("?gene",)),
        (Atom("annotatedTo",("?gene","?term")),)
    )
    candidate=Rule(
        "diagnostic_mixed_candidate",Atom("diagnostic_mixed",("?gene",)),
        (Atom("annotatedTo",("?gene","?term")),)
    )
    candidate_only=Rule(
        "diagnostic_candidate_only",Atom("diagnostic_candidate_only",("?gene",)),
        (Atom("annotatedTo",("?gene","?term")),)
    )
    rules=[*base.kb.rules,trusted,candidate,candidate_only]
    statuses=dict(base.rule_status)
    statuses.update({
        trusted.name:TRUSTED,
        candidate.name:CANDIDATE,
        candidate_only.name:CANDIDATE,
    })
    context=TrustContext(
        KnowledgeBase(facts=list(base.kb.facts),rules=rules),
        schema=base.schema,negatives=base.negatives,rule_status=statuses,
    )
    return [
        {"name":"mixed_trusted_and_candidate",
         "kind":None,"context":context,
         "query":Atom("diagnostic_mixed",(gene,)),
         "max_depth":3,"expected_status":"PROVEN",
         "requires_both_proof_classes":True,
         "injection":"two same-head labelled rules with trusted and candidate status"},
        {"name":"candidate_only",
         "kind":None,"context":context,
         "query":Atom("diagnostic_candidate_only",(gene,)),
         "max_depth":3,"expected_status":"HYPOTHESIZED",
         "requires_both_proof_classes":False,
         "injection":"candidate-only rule over real full-GO annotation facts"},
    ]


def call_verifier(trusted_dir,trace_path,expected_digest,depth,report_path,limit):
    begin=perf_counter()
    try:
        run=subprocess.run([
            sys.executable,str(VERIFY),
            "--processed",str(trusted_dir),
            "--input",str(trace_path),
            "--source-indices","0",
            "--max-depth",str(depth),
            "--pinned-digest",expected_digest,
            "--output",str(report_path),
        ],cwd=ROOT,capture_output=True,text=True,timeout=limit)
        timed_out=False
    except subprocess.TimeoutExpired:
        return {"passed":False,"timeout":True,"seconds":perf_counter()-begin}
    try: data=json.loads(report_path.read_text(encoding="utf-8"))
    except (OSError,ValueError):data=None
    return {
        "passed":run.returncode==0 and bool(data and data.get("passed")),
        "exit_code":run.returncode,"timeout":timed_out,
        "seconds":round(perf_counter()-begin,6),"report":data,
        "stderr_tail":run.stderr[-300:] if run.returncode else "",
    }


def tamper_existing_certificate_or_expansion(trace):
    """Attack an event that really exists in this completed producer trace.

    A mixed trusted/candidate derivation can be fully successful and
    legitimately emit NO pruning certificate. A certificate-only attack
    is inapplicable there; use a real frontier transition instead.
    The verifier must detect either form with a structured failure.
    """
    events=trace["queries"][0]["events"]
    for event in events:
        if event["type"]=="certificate":
            event["evidence"]["snapshot_sha256"]="0"*64
            return "certificate_snapshot_digest"
    for event in events:
        if event["type"]=="expanded" and event.get("children"):
            event["children"].pop(0)
            return "expanded_transition_child_erased"
    raise ValueError("no_certificate_or_nonempty_expansion_to_attack")


def attack_checks(work,trace,fixture,digest,depth,timeout):
    checks=[]
    for name,mutate in (
        ("forged_aggregated_verdict",lambda d:d["runs"][0].__setitem__(
            "decision_summary",[[
                {"predicate":"forged","args":["probe"]},"PROVEN",99,0
            ]]
        )),
        ("tampered_certificate_or_frontier",tamper_existing_certificate_or_expansion),
    ):
        malicious=copy.deepcopy(trace)
        try:
            attack_surface=mutate(malicious)
        except ValueError as error:
            checks.append({"name":name,"rejected":False,
                           "reason":str(error)})
            continue
        entry=work/f"attack_{name}.json"
        entry.write_text(json.dumps(malicious),encoding="utf-8")
        report=work/f"attack_{name}_verdict.json"
        observed=call_verifier(
            fixture,entry,digest,depth,report,timeout
        )
        d=observed.get("report") or {}
        # Mere process crash, no structured report, timeout: not credit.
        rejected=(
            observed.get("exit_code") not in (None,0,124)
            and not observed.get("timeout")
            and d.get("passed") is False
            and bool(d.get("failures"))
        )
        checks.append({
            "name":name,"rejected":rejected,
            "attack_surface":attack_surface,
            "structured_reason":d.get("failures",[])[:1],
        })
    return checks


def exercise(base,case,root,budget,max_seconds,timeout):
    name=case["name"]
    ctx=case["context"]
    depth=case["max_depth"]
    query=case["query"]
    processed=root/name/"source"
    provenance=write_processed_fixture(processed,ctx,query)
    records={}
    for mode in ("uncertified_reference","certified"):
        started=perf_counter()
        if mode=="uncertified_reference":
            answers,stats=CertifiedReasoner(ctx,max_depth=depth).search(
                query,certified=False,budget=budget,max_seconds=max_seconds
            )
            events=None
        else:
            tracer=AuditTracingReasoner(
                ctx,max_depth=depth,digest=provenance["snapshot_sha256"]
            )
            answers,stats=tracer.search(
                query,certified=True,budget=budget,max_seconds=max_seconds
            )
            events=tracer.events
        records[mode]={
            "complete":not stats.exhausted_budget,
            "decisions":signature(answers),
            "expanded":stats.expanded,
            "elapsed_seconds":round(perf_counter()-started,6),
        }
    kinds=Counter(
        e["evidence"]["kind"] for e in events
        if e["type"]=="certificate"
    )
    actual=records["certified"]["decisions"]
    trace={
        "protocol":"independent_go_transition_audit_v2",
        "producer_snapshot_sha256":provenance["snapshot_sha256"],
        "source_indices":[0],
        "facts_loaded":len(ctx.kb.facts),
        "rules_loaded":len(ctx.kb.rules),
        "max_depth":depth,
        "passed_capture_completeness":records["certified"]["complete"],
        "queries":[{
            "source_index":0,"query":atom_data(query),"events":events
        }],
        "runs":[{
            "source_index":0,"complete":records["certified"]["complete"],
            "decision_summary":actual,
        }],
    }
    path=root/name/"untrusted_trace.json"
    path.write_text(json.dumps(trace),encoding="utf-8")
    verified=call_verifier(
        processed,path,provenance["snapshot_sha256"],depth,
        root/name/"trusted_verdict.json",timeout
    )
    decisions_equal=(
        records["uncertified_reference"]["decisions"]==actual
    )
    expected_status=case.get("expected_status")
    if expected_status:
        status_agrees=(
            len(actual)==1 and actual[0][1]==expected_status
        )
    else:
        status_agrees=True
    if case.get("requires_both_proof_classes"):
        status_agrees=status_agrees and (
            actual and actual[0][2]>0 and actual[0][3]>0
        )
    elif expected_status=="HYPOTHESIZED":
        status_agrees=status_agrees and (
            actual and actual[0][2]==0 and actual[0][3]>0
        )
    expected_cert=case.get("kind")
    expected_activated=(
        kinds[expected_cert]>0 if expected_cert else True
    )
    tamper=attack_checks(
        root/name,trace,processed,provenance["snapshot_sha256"],
        depth,timeout
    ) if verified["passed"] else []
    replay=verified.get("report") or {}
    observed_counts={}
    if replay.get("results"):
        observed_counts=replay["results"][0].get("certificates_by_kind",{})
    passed=all((
        records["uncertified_reference"]["complete"],
        records["certified"]["complete"],
        decisions_equal,status_agrees,expected_activated,
        verified["passed"],replay.get("independent_verdict_reconstruction_passed") is True,
        dict(kinds)==observed_counts,
        len(tamper)==2,
        all(x["rejected"] for x in tamper),
    ))
    return {
        "name":name,"kind_expected":expected_cert,
        "injection":case["injection"],
        "max_depth":depth,
        "facts":len(ctx.kb.facts),
        "rules":len(ctx.kb.rules),
        "source_sha256":provenance["files_sha256"],
        "expected_pinned_snapshot_sha256":provenance["snapshot_sha256"],
        "complete_pair":(
            records["uncertified_reference"]["complete"] and
            records["certified"]["complete"]
        ),
        "decisions_equal":decisions_equal,
        "expected_status_satisfied":bool(status_agrees),
        "expected_certificate_activated":expected_activated,
        "independent_os_process_passed":verified["passed"],
        "independent_verdict_rederived":replay.get(
            "independent_verdict_reconstruction_passed"
        ),
        "certificate_counts_producer":dict(kinds),
        "certificate_counts_independently_replayed":observed_counts,
        "independent_claims":replay.get("independent_verdict_rows",[]),
        "tamper_checks":tamper,
        "reference_seconds":records["uncertified_reference"]["elapsed_seconds"],
        "producer_seconds":records["certified"]["elapsed_seconds"],
        "verifier_seconds":verified["seconds"],
        "verifier_failures":replay.get("failures") or verified.get("stderr_tail"),
        "passed":passed,
    }


def run(processed,budget,max_seconds,verify_timeout):
    begun=perf_counter()
    base=context_from_go(processed,None)
    cases=[*_cases(base),*mixed_cases(base)]
    if len(cases)!=7:
        raise ValueError("Expected exactly five certificate + two mixed cases")
    rows=[]
    with tempfile.TemporaryDirectory(prefix="www27_all_cert_verifier_") as d:
        root=Path(d)
        for c in cases:
            row=exercise(base,c,root,budget,max_seconds,verify_timeout)
            rows.append(row)
            print("ALL_CERT_CONTROLLED "+json.dumps({
                "name":row["name"],"passed":row["passed"],
                "expected":row["kind_expected"],
                "observed":row["certificate_counts_independently_replayed"],
                "decisions":row["independent_claims"],
            }),flush=True)
    activated={x["kind_expected"] for x in rows
               if x["kind_expected"] and x["expected_certificate_activated"]}
    statuses={v[1] for row in rows
              for d in row["independent_claims"]
              for v in d.get("verdicts",[])}
    return {
        "experiment":"www27_all_five_certificates_mixed_status_full_replay_v1",
        "passed":(
            len(rows)==7 and all(r["passed"] for r in rows)
            and set(EXPECTED_KINDS)<=activated
            and {"PROVEN","HYPOTHESIZED"}<=statuses
        ),
        "trusted_source_origin":"real_full_GO_plus_explicit_diagnostic_injections",
        "facts_original":len(base.kb.facts),
        "source_rule_templates_original":len(base.kb.rules),
        "cases":len(rows),
        "certificate_kinds_independently_exercised":sorted(activated),
        "statuses_independently_exercised":sorted(statuses),
        "structured_tamper_attempts":sum(len(x["tamper_checks"]) for x in rows),
        "structured_tamper_rejections":sum(
            sum(k["rejected"] for k in x["tamper_checks"]) for x in rows
        ),
        "seconds_total":round(perf_counter()-begun,6),
        "rows":rows,
        "limitations":[
            "Five GO certificate kinds are activated with explicit labelled diagnostic probes; frequency is NOT natural.",
            "The controlled temporary trusted fixture is generated by the harness and locally pinned; no third-party cryptographic provenance or hostile host isolation.",
            "A separate verifier process independently reloads the fixture and recomputes all transitions, certificates, proof statuses and aggregated verdicts.",
            "Mixed status PROVEN with both trusted/candidate proof counts and a candidate-only HYPOTHESIZED proof are tested; full terminal REFUTED is not asserted without a real complete producer proof.",
            "Explicit refutation and REFUTED aggregation are covered by separate isolated verifier regression tests, not this complete producer replay.",
            "Completeness is conditional on the finite search budget and timeout. No generalized Horn/OWL completeness or poisoning detection claim.",
            "No manuscript LaTeX was modified.",
        ],
    }


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--processed",type=Path,default=Path("data/go_case_study/processed"))
    p.add_argument("--budget",type=int,default=2500)
    p.add_argument("--max-seconds",type=float,default=25)
    p.add_argument("--verify-timeout",type=int,default=75)
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    try:
        result=run(a.processed,a.budget,a.max_seconds,a.verify_timeout)
    except Exception as e:
        result={"experiment":"www27_all_five_certificates_mixed_status_full_replay_v1",
                "passed":False,
                "error":{"type":type(e).__name__,"message":str(e)}}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",
                        encoding="utf-8")
    print("ALL_CERT_REPLAY_SUMMARY "+json.dumps({
        "passed":result["passed"],
        "kinds":result.get("certificate_kinds_independently_exercised"),
        "statuses":result.get("statuses_independently_exercised"),
        "attacks":result.get("structured_tamper_rejections"),
        "error":result.get("error"),
    }),flush=True)
    return 0 if result["passed"] else 1

if __name__=="__main__":
    raise SystemExit(main())
