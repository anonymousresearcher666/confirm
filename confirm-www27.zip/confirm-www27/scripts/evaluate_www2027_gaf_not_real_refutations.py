"""P2.3: independent verification of real GO GAF NOT annotations, no injections.

Select the earliest eligible original GAF2.2 NOT|relation rows from exact
SHA256-pinned human/mouse snapshot artifacts. Respect the *relation* and
annotation extension: do not treat NOT|enables as a negation of every generic
GO annotation. No synthetic negatives are added in the positive test.
Each pinned GAF NOT record becomes an explicit negative of a
gafQualifiedAssociation(gene,relation,GO term,extension) atom in a trusted
temporary fixture. Producer and independent verifier are distinct OS processes;
a second separate-source scan verifies original raw GAF support.

This is direct negative-annotation assurance, NOT OWL NOT-propagation or a
claim about unqualified GO annotatedTo. Fail closed if no genuine NOT exists.
"""
from __future__ import annotations
import argparse
import copy
import gzip
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from trustkg.kb import Atom,KnowledgeBase
from trustkg.trust import TrustContext
from trustkg.certificate_evidence import atom_data
from evaluate_www2027_all_certificate_replay import (
    write_processed_fixture,call_verifier,
)

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data/go_case_study"
MANIFEST=DATA/"manifest.json"
CAPTURE=ROOT/"scripts/capture_www2027_go_transition_audit.py"


def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1<<20),b""):
            h.update(chunk)
    return h.hexdigest()


def gaf_record(line,record_index,source):
    if not line or line.startswith("!"):
        return None
    fields=line.rstrip("\r\n").split("\t")
    if len(fields)<15 or not fields[0] or not fields[1]:
        return None
    qualified=fields[3].split("|")
    if "NOT" not in qualified or qualified.count("NOT")!=1:
        return None
    relation=[item for item in qualified if item!="NOT" and item]
    if len(relation)!=1 or not fields[4].startswith("GO:"):
        return None
    go_id=fields[4]
    if len(go_id)!=10 or not go_id[3:].isdigit():
        return None
    # GAF DB Object ID can already be curie-qualified (MGI:101759).
    # Never create MGI:MGI:101759: it breaks joins with canonical IDs.
    entity=(
        fields[1] if fields[1].startswith(fields[0]+":")
        else fields[0]+":"+fields[1]
    )
    extension=fields[15] if len(fields)>15 else ""
    # Preserve the GAF relation and extension. The exact NOT statement is
    # narrower than an unqualified GO annotation to the same GO term.
    atom=Atom("gafQualifiedAssociation",(
        entity,relation[0],
        "http://purl.obolibrary.org/obo/"+go_id.replace(":","_"),
        extension,
    ))
    return {
        "source":source,"line_index":record_index,
        "raw_line_sha256":hashlib.sha256(line.encode("utf-8")).hexdigest(),
        "atom":atom,
        "db":fields[0],"raw_db_object_id":fields[1],
        "entity":entity,"relation":relation[0],
        "go_id":go_id,"qualifier":fields[3],
        "evidence_code":fields[6],"references":fields[5],
        "assigned_by":fields[14],"annotation_date":fields[13],
        "annotation_extension":extension,
    }


def read_gaf(path,source,per_source):
    found=[]
    eligible_count=0
    seen=set()
    with gzip.open(path,"rt",encoding="utf-8") as stream:
        for row_index,line in enumerate(stream):
            record=gaf_record(line,row_index,source)
            if record is None:
                continue
            eligible_count+=1
            key=record["atom"]
            if key in seen:
                continue
            seen.add(key)
            if len(found)<per_source:
                found.append(record)
    return found,eligible_count


def external_gaf_recheck(path,selected):
    """Rescan original gzipped source independently of fixture serialization."""
    needed={item["line_index"]:item for item in selected}
    if not needed:return False
    matched=set()
    with gzip.open(path,"rt",encoding="utf-8") as stream:
        for row_index,line in enumerate(stream):
            if row_index not in needed:continue
            check=gaf_record(line,row_index,needed[row_index]["source"])
            original=needed[row_index]
            if (check is None or
                check["atom"]!=original["atom"] or
                check["raw_line_sha256"]!=original["raw_line_sha256"]):
                return False
            matched.add(row_index)
    return matched==set(needed)


def producer(fixture,trace,timeout):
    args=[sys.executable,str(CAPTURE),"--processed",str(fixture),
          "--source-indices","0","--max-depth","2",
          "--budget","300","--max-seconds","25","--output",str(trace)]
    try:
        r=subprocess.run(args,cwd=ROOT,timeout=timeout,
                         capture_output=True,text=True)
    except subprocess.TimeoutExpired:
        return {"ok":False,"error":"producer_timeout"}
    return {"ok":r.returncode==0,"exit_code":r.returncode,
            "stderr_tail":r.stderr[-500:] if r.returncode else ""}


def attack(work,trace,fixture,pin,name,alter,timeout):
    mutant=copy.deepcopy(trace)
    alter(mutant)
    if mutant==trace:raise ValueError("mutant has not changed: "+name)
    m=work/("attack_"+name+".json")
    m.write_text(json.dumps(mutant,separators=(",",":"))+"\n",encoding="utf-8")
    result=call_verifier(
        fixture,m,pin,2,work/("attack_report_"+name+".json"),timeout
    )
    report=result.get("report") or {}
    rejected=(
        result.get("exit_code") not in (None,0,124)
        and result.get("timeout") is False
        and report.get("passed") is False
        and bool(report.get("failures"))
    )
    return {"name":name,"rejected":rejected,
            "diagnostic":(report.get("failures") or [{}])[0].get("reason")}


def run(output,per_source,timeout):
    m=json.loads(MANIFEST.read_text(encoding="utf-8"))
    configured={item["name"]:item for item in m["sources"]}
    selected=[]
    inspected=[]
    selected_paths={}
    for key in ("human_gaf","mouse_gaf"):
        if key not in configured:
            raise ValueError("manifest missing expected original GO GAF source "+key)
        source=configured[key]
        path=ROOT/source["path"]
        if not path.is_file():raise ValueError("original GAF missing: "+str(path))
        actual=sha256_file(path)
        if actual!=source["sha256"]:
            raise ValueError("original GAF sha256 differs from frozen manifest: "+key)
        items,eligible_count=read_gaf(path,key,per_source)
        if items and not external_gaf_recheck(path,items):
            raise ValueError("original GAF source line recheck mismatch: "+key)
        selected.extend(items)
        selected_paths[key]=path
        inspected.append({
            "source":key,"manifest_url":source["url"],
            "manifest_sha256":source["sha256"],"observed_sha256":actual,
            "eligible_genuine_not_rows":eligible_count,
            "selected_distinct_negative_annotations":len(items),
        })
    if not selected:
        raise ValueError("no GAF NOT|relation records found in pinned source archives")
    rows=[]
    attacks=[]
    with tempfile.TemporaryDirectory(prefix="www27_real_gaf_NOT_") as dir_name:
        root=Path(dir_name)
        for i,record in enumerate(selected):
            name=record["source"]+"_n"+str(i)
            work=root/name
            work.mkdir()
            # Real negative assertion only. No synthetic negative evidence,
            # nonactual GO membership, or fabricated ontology axiom.
            ctx=TrustContext(
                KnowledgeBase(facts=[],rules=[]),
                negatives=frozenset([record["atom"]]),
            )
            fixture=work/"trusted_gaf_negative_fixture"
            meta=write_processed_fixture(fixture,ctx,record["atom"])
            trace=work/"actual_producer.json"
            produced=producer(fixture,trace,timeout)
            if not produced["ok"]:
                raise ValueError("producer failed "+name+" "+str(produced))
            obj=json.loads(trace.read_text(encoding="utf-8"))
            record_claim=atom_data(record["atom"])
            expected=[[record_claim,"REFUTED",0,0]]
            summary=obj["runs"][0]["decision_summary"]
            if summary!=expected:
                raise ValueError("real NOT producer failed to emit REFUTED: "+name)
            witness=obj["runs"][0].get("refutation_witness")
            if (not witness or witness.get("reason")!="explicit-negative"
                or witness.get("claim")!=record_claim):
                raise ValueError("genuine producer GAF NOT witness absent: "+name)
            verified=call_verifier(
                fixture,trace,meta["snapshot_sha256"],2,
                work/"genuine_verification.json",timeout
            )
            report=verified.get("report") or {}
            accepted=(verified["passed"] and
                      report.get("independent_verdict_reconstruction_passed") is True
                      and obj.get("passed_capture_completeness") is True)
            if not accepted:raise ValueError("independent verifier rejected real NOT "+name)
            cases={
                "source":record["source"],
                "gaf_record_index":record["line_index"],
                "gaf_line_sha256":record["raw_line_sha256"],
                "original_annotation":{
                    "db":record["db"],"raw_db_object_id":record["raw_db_object_id"],
                    "entity":record["entity"],
                    "qualifier":record["qualifier"],"relation":record["relation"],
                    "go_id":record["go_id"],
                    "reference":record["references"],
                    "evidence_code":record["evidence_code"],
                    "assigned_by":record["assigned_by"],
                    "annotation_date":record["annotation_date"],
                    "annotation_extension":record["annotation_extension"],
                },
                "atom":record_claim,
                "real_not_source_rechecked":True,
                "trusted_fixture_snapshot_sha256":meta["snapshot_sha256"],
                "producer_status":"REFUTED",
                "independent_verifier_accepted":accepted,
                "reconstructed_reason":"explicit-negative",
            }
            rows.append(cases)
            if i==0 or record["source"]!=selected[i-1]["source"]:
                for attack_name,alter in (
                    ("erase_witness",lambda tr:tr["runs"][0].pop("refutation_witness")),
                    ("forge_witness_relation",lambda tr:tr["runs"][0]["refutation_witness"]["claim"]["args"].__setitem__(1,"invented_relation")),
                    ("forge_witness_pin",lambda tr:tr["runs"][0]["refutation_witness"].__setitem__("trusted_snapshot_sha256","0"*64)),
                    ("change_refuted_to_proven",lambda tr:tr["runs"][0].__setitem__(
                        "decision_summary",[[record_claim,"PROVEN",1,0]])),
                ):
                    result=attack(work,obj,fixture,meta["snapshot_sha256"],
                                  attack_name,alter,timeout)
                    result["source"]=record["source"]
                    attacks.append(result)
            print("WWW27_REAL_GAF_NOT "+json.dumps({
                "source":record["source"],"line":record["line_index"],
                "relation":record["relation"],"qualified_GO":record["go_id"],
                "verifier_passed":accepted,
            }),flush=True)
    accepted=all(x["independent_verifier_accepted"] for x in rows)
    passed=accepted and bool(attacks) and all(x["rejected"] for x in attacks)
    return {
        "experiment":"www27_authentic_pinned_GAF_NOT_independent_refuted_v1",
        "passed":passed,
        "real_negative_source_count":len(rows),
        "verified_real_gaf_negative_count":sum(x["independent_verifier_accepted"] for x in rows),
        "distinct_source_files_with_negative":len({x["source"] for x in rows}),
        "tampering_attempts":len(attacks),
        "tampering_structured_rejections":sum(x["rejected"] for x in attacks),
        "source_archives":inspected,
        "real_negative_records":rows,
        "attacks":attacks,
        "limitations":[
            "Original external source GAF lines are pinned to the repository manifest and rechecked, but no third-party cryptographic signature attestation is claimed.",
            "NOT is interpreted ONLY with the exact GAF relation and annotation extension, not as generic RDF annotatedTo negation.",
            "The trusted fixture for the independent verifier is generated by the operator-side harness from the pinned original GAF. Full GAF-to-fixture parsing is part of trusted ingestion.",
            "Current verifier checks a one-fact relation-preserving explicit negative; no GO ontology propagation of NOT or natural frequency generalization.",
            "Source annotations may or may not appear among the first 10000 positive GAF records selected by the existing GO compiler.",
            "No synthetic negative was added to the genuine-GAF test.",
        ],
    }


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--per-source",type=int,default=3)
    p.add_argument("--timeout",type=int,default=80)
    a=p.parse_args()
    try:
        if a.per_source<1 or a.per_source>10 or a.timeout<40:
            raise ValueError("unsupported sample size or timeout")
        result=run(a.output,a.per_source,a.timeout)
    except Exception as e:
        result={
            "experiment":"www27_authentic_pinned_GAF_NOT_independent_refuted_v1",
            "passed":False,"blocked_reason":f"{type(e).__name__}: {e}",
        }
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("WWW27_GAF_NOT_SUMMARY "+json.dumps({
        "passed":result["passed"],"cases":result.get("real_negative_source_count"),
        "rejections":result.get("tampering_structured_rejections"),
        "attacks":result.get("tampering_attempts"),
        "blocked_reason":result.get("blocked_reason"),
    }),flush=True)
    return 0 if result["passed"] else 1


if __name__=="__main__":
    raise SystemExit(main())
