"""Full-GO controlled activation tests for all five pruning certificate kinds.

Uses the complete native GO graph PLUS a tiny labelled diagnostic query,
rule or duplicate support when needed. These are CONTROLLED STRESS CASES,
not naturally occurring GO query frequencies. Each compared search is
depth- and budget-bounded; pruning counts and preserved outcomes must match.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from time import perf_counter

from trustkg.kb import Atom, KnowledgeBase, Rule
from trustkg.trust import CANDIDATE, CertifiedReasoner, TrustContext
from trustkg.certificate_evidence import atom_data, snapshot_data, snapshot_digest

from capture_www2027_go_certificate_trace import context_from_go
from evaluate_www2027_go_differential import _decisions, _proven


def _pick_entities(context):
    gene = None
    annotations = defaultdict(list)
    parents = set()
    for fact in context.kb.facts:
        if len(fact.args) != 2:
            continue
        if fact.predicate == "annotatedTo":
            annotations[fact.args[0]].append(fact)
            if gene is None:
                gene = fact.args[0]
        elif fact.predicate == "subClassOf":
            parents.add(fact.args[0])
    candidates = [
        (len(facts), key, fact)
        for key, facts in annotations.items()
        if len(facts) <= 5
        for fact in facts if fact.args[1] in parents
    ]
    if not candidates:
        candidates = [
            (len(facts), key, fact)
            for key, facts in annotations.items()
            for fact in facts if fact.args[1] in parents
        ]
    candidates.sort(key=lambda x: (x[0], x[1], x[2].args[1]))
    if not candidates:
        raise ValueError("No real annotatedTo/GO subclass join support available")
    duplicate_support = candidates[0][2]
    typed_bp = sorted(
        entity for entity, classes in context.schema.types.items()
        if "GO_BiologicalProcess" in classes
        and "GO_CellularComponent" not in classes
    )
    if not typed_bp:
        raise ValueError("GO schema has no typed BiologicalProcess entity")
    return gene, duplicate_support, typed_bp[0]


def _with_probe(base, *, name=None, rule=None, duplicate=None):
    if rule is None and duplicate is None:
        return base
    rules = list(base.kb.rules)
    statuses = dict(base.rule_status)
    facts = list(base.kb.facts)
    if rule is not None:
        rules.append(rule)
        statuses[rule.name] = CANDIDATE
    if duplicate is not None:
        facts.append(duplicate)
    return TrustContext(
        KnowledgeBase(facts=facts, rules=rules),
        schema=base.schema, negatives=base.negatives,
        rule_status=statuses, injected_rules=base.injected_rules,
    )


def _cases(base):
    gene, duplicate, bp = _pick_entities(base)
    dup_rule = Rule(
        "diagnostic_duplicate_conjunction",
        Atom("diagnostic_duplicate", ("?gene",)),
        (
            Atom("annotatedTo", ("?gene", "?term")),
            Atom("subClassOf", ("?term", "?parent")),
        ),
    )
    unsat_rule = Rule(
        "diagnostic_unsat_conjunction",
        Atom("diagnostic_unsat", ("?gene",)),
        (
            Atom("locatedIn", ("?gene", "?same")),
            Atom("involvedIn", ("?gene", "?same")),
        ),
    )
    return [
        {
            "name": "pre_missing_predicate",
            "kind": "C-PRE",
            "context": base,
            "query": Atom("diagnostic_absent", (gene,)),
            "max_depth": 4,
            "injection": "no changes to GO facts/rules",
        },
        {
            "name": "type_range_incompatible",
            "kind": "C-TYPE",
            "context": base,
            "query": Atom("locatedIn", (gene, bp)),
            "max_depth": 4,
            "injection": "no changes; ground object typed BiologicalProcess",
        },
        {
            "name": "depth_zero_requires_rule",
            "kind": "C-DEPTH",
            "context": base,
            "query": Atom("locatedIn", (gene, "?component")),
            "max_depth": 0,
            "injection": "no changes; no rule application permitted",
        },
        {
            "name": "subsume_duplicate_source",
            "kind": "C-SUBSUME",
            "context": _with_probe(base, rule=dup_rule, duplicate=duplicate),
            "query": Atom("diagnostic_duplicate", (duplicate.args[0],)),
            "max_depth": 3,
            "injection": "one repeated real annotation fact + one diagnostic candidate rule",
        },
        {
            "name": "unsat_disjoint_range_obligations",
            "kind": "C-UNSAT",
            "context": _with_probe(base, rule=unsat_rule),
            "query": Atom("diagnostic_unsat", (gene,)),
            "max_depth": 5,
            "injection": "one diagnostic candidate conjunction with shared range term",
        },
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--processed", type=Path,
                        default=Path("data/go_case_study/processed"))
    parser.add_argument("--budget", type=int, default=1500)
    parser.add_argument("--max-seconds", type=float, default=8.0)
    parser.add_argument("--output", type=Path, default=Path(
        "results/www2027/go_controlled_certificate_coverage_v1.json"
    ))
    args = parser.parse_args()
    if args.budget < 1 or args.max_seconds <= 0:
        parser.error("budget/time must be positive")
    start = perf_counter()
    original = context_from_go(args.processed, None)
    cases = _cases(original)
    load_seconds = perf_counter() - start
    rows = []
    for case in cases:
        ctx = case["context"]
        modes = {}
        for mode in ("unpruned", "certified"):
            begin = perf_counter()
            answers, stats = CertifiedReasoner(
                ctx, max_depth=case["max_depth"],
            ).search(
                case["query"], certified=(mode == "certified"),
                budget=args.budget, max_seconds=args.max_seconds,
            )
            modes[mode] = {
                "decisions": _decisions(answers),
                "proven": _proven(answers),
                "expanded": stats.expanded,
                "generated": stats.generated,
                "seconds": round(perf_counter() - begin, 6),
                "complete": not stats.exhausted_budget,
                "pruned": stats.pruned,
                "certificate_seconds": round(stats.certificate_seconds, 6),
            }
        a, b = modes["unpruned"], modes["certified"]
        complete = a["complete"] and b["complete"]
        activated = b["pruned"].get(case["kind"], 0) > 0
        passed = complete and a["decisions"] == b["decisions"] and (
            a["proven"] == b["proven"]
        ) and activated
        row = {
            "name": case["name"], "expected_kind": case["kind"],
            "injection": case["injection"],
            "query": atom_data(case["query"]),
            "facts_loaded": len(ctx.kb.facts),
            "rules_loaded": len(ctx.kb.rules),
            "snapshot_sha256": snapshot_digest(snapshot_data(ctx)),
            "max_depth": case["max_depth"],
            "complete_pair": complete,
            "expected_kind_activated": activated,
            "decisions_equal": a["decisions"] == b["decisions"],
            "proven_equal": a["proven"] == b["proven"],
            "unpruned": a, "certified": b,
            "passed": passed,
        }
        rows.append(row)
        print("GO_CONTROLLED_CERT_PROGRESS "+json.dumps({
            "case": row["name"],
            "expected_kind": row["expected_kind"],
            "activated": activated, "complete": complete,
            "decisions_equal": row["decisions_equal"], "passed": passed,
        }), flush=True)
    report = {
        "experiment": "www27_go_full_graph_controlled_certificate_coverage_v1",
        "regime": "FULL GO + minimal diagnostic perturbations where labelled",
        "facts_loaded": len(original.kb.facts),
        "trusted_rules_loaded": len(original.kb.rules),
        "load_seconds": round(load_seconds, 6),
        "expected_kinds": [r["expected_kind"] for r in rows],
        "observed_kinds": sorted({
            kind for r in rows for kind in r["certified"]["pruned"]
        }),
        "summary": {
            "requested_cases": len(rows),
            "complete_pairs": sum(r["complete_pair"] for r in rows),
            "activated_expected_kinds": sum(
                r["expected_kind_activated"] for r in rows
            ),
            "decision_mismatches": sum(not r["decisions_equal"] for r in rows),
            "proven_mismatches": sum(not r["proven_equal"] for r in rows),
            "pruned_by_kind": dict(Counter({
                kind: sum(r["certified"]["pruned"].get(kind, 0) for r in rows)
                for kind in ("C-PRE", "C-TYPE", "C-DEPTH", "C-SUBSUME", "C-UNSAT")
            })),
        },
        "rows": rows,
        "passed": all(r["passed"] for r in rows),
        "limitations": [
            "These are controlled injected diagnostic probes, not natural GO queries.",
            "C-SUBSUME reuses a deliberately duplicated real annotation fact.",
            "The same engine is used for the unpruned differential baseline.",
            "No guarantee on behavior beyond the finite tested scenarios.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "experiment": report["experiment"],
        "summary": report["summary"],
        "passed": report["passed"],
        "output": str(args.output),
    }, indent=2), flush=True)
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
