"""Full-GO differential evaluation: UNPRUNED vs CERTIFIED on real queries.

The existing capture experiment compares certified search against the same
certified search with tracing. This complementary experiment tests actual
pruning preservation against an uncertified, fully explored reference.

Finite search-depth boundedness and budget/time completion are REQUIRED.
No standalone checker or offline attestation is claimed by this script.
"""
from __future__ import annotations

import argparse
import json
import random
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from time import perf_counter

from trustkg.kb import Atom
from trustkg.trust import CertifiedReasoner, aggregate_claim_decisions, proven_claims
from trustkg.certificate_evidence import atom_data, snapshot_data, snapshot_digest
from capture_www2027_go_certificate_trace import context_from_go, rows


def _decisions(answers):
    return sorted([
        {
            "claim": atom_data(decision.claim),
            "status": decision.status,
            "trusted_proofs": decision.trusted_proof_count,
            "candidate_proofs": decision.candidate_proof_count,
            "refutations": list(decision.refutations),
        }
        for decision in aggregate_claim_decisions(answers)
    ], key=lambda d: repr(d["claim"]))


def _proven(answers):
    return sorted((atom_data(a) for a in proven_claims(answers)), key=repr)


def _select(source, *, count, selection, seed):
    if selection == "prefix":
        return [(i, row) for i, row in enumerate(source[:count])]
    groups = defaultdict(list)
    for i, row in enumerate(source):
        groups[(
            row.get("family", "unspecified"),
            row.get("proof_depth", "unspecified"),
            bool(row.get("explicit", False)),
        )].append((i, row))
    rng = random.Random(seed)
    keys = sorted(groups, key=repr)
    for group in groups.values():
        rng.shuffle(group)
    selected = []
    while len(selected) < count:
        made_progress = False
        for key in keys:
            if groups[key]:
                selected.append(groups[key].pop())
                made_progress = True
                if len(selected) >= count:
                    break
        if not made_progress:
            break
    return selected


def _summary(values):
    if not values:
        return None
    ordered = sorted(values)
    return {
        "mean": round(statistics.mean(values), 6),
        "median": round(statistics.median(values), 6),
        "p95": round(ordered[int(0.95 * (len(ordered) - 1))], 6),
        "sum": round(sum(values), 6),
    }


def evaluate(*, processed, queries, selection, seed, depth, budget,
             max_seconds, max_facts, source_indices=None):
    loading_started = perf_counter()
    ctx = context_from_go(processed, max_facts)
    snapshot_sha = snapshot_digest(snapshot_data(ctx))
    source = list(rows(processed / "queries.jsonl"))
    if source_indices is None:
        selected = _select(source, count=queries, selection=selection, seed=seed)
    else:
        if len(set(source_indices)) != len(source_indices):
            raise ValueError("Duplicate --source-indices are not allowed")
        if any(index < 0 or index >= len(source) for index in source_indices):
            raise ValueError("Source query index out of range")
        if queries != len(source_indices):
            raise ValueError("--queries must equal number of --source-indices")
        selected = [(index, source[index]) for index in source_indices]
    if len(selected) < queries:
        raise ValueError(
            f"Requested {queries} queries but only {len(selected)} available"
        )
    load_seconds = perf_counter() - loading_started
    results = []
    pruning = Counter()
    completeness_failures = []
    decision_failures = []
    totals = {
        "unpruned_expanded": 0,
        "certified_expanded": 0,
        "unpruned_generated": 0,
        "certified_generated": 0,
        "certified_checks": 0,
        "certified_successes": 0,
        "certification_internal_seconds": 0.0,
    }
    for sample_idx, (source_index, record) in enumerate(selected):
        q = record["query"]
        query = Atom(q["predicate"], tuple(q["args"]))
        # Alternate execution order to reduce systematic warm-cache bias.
        ordered_modes = (
            ("unpruned", "certified")
            if sample_idx % 2 == 0 else ("certified", "unpruned")
        )
        modes = {}
        for mode in ordered_modes:
            enabled = mode == "certified"
            searcher = CertifiedReasoner(ctx, max_depth=depth)
            start = perf_counter()
            answers, stats = searcher.search(
                query, certified=enabled,
                budget=budget, max_seconds=max_seconds,
            )
            seconds = perf_counter() - start
            modes[mode] = {
                "decisions": _decisions(answers),
                "proven": _proven(answers),
                "elapsed_seconds": round(seconds, 6),
                "expanded": stats.expanded,
                "generated": stats.generated,
                "pruned": dict(stats.pruned),
                "certificate_checks": stats.certificate_checks,
                "certificate_successes": stats.certificate_successes,
                "certificate_seconds": round(stats.certificate_seconds, 6),
                "complete": not stats.exhausted_budget,
                "exhausted_state_budget": stats.exhausted_state_budget,
                "exhausted_time_budget": stats.exhausted_time_budget,
                "answers": len(answers),
                "rule_derived_proofs": sum(bool(a.rules_used) for a in answers),
            }
            totals[f"{mode}_expanded"] += stats.expanded
            totals[f"{mode}_generated"] += stats.generated
            if enabled:
                pruning.update(stats.pruned)
                totals["certified_checks"] += stats.certificate_checks
                totals["certified_successes"] += stats.certificate_successes
                totals["certification_internal_seconds"] += stats.certificate_seconds
        reference, guarded = modes["unpruned"], modes["certified"]
        complete = reference["complete"] and guarded["complete"]
        equivalent_decisions = reference["decisions"] == guarded["decisions"]
        equivalent_proven = reference["proven"] == guarded["proven"]
        if not complete:
            completeness_failures.append(source_index)
        if complete and (not equivalent_proven or not equivalent_decisions):
            decision_failures.append(source_index)
        results.append({
            "source_index": source_index,
            "selection_group": {
                "family": record.get("family"),
                "proof_depth": record.get("proof_depth"),
                "explicit": record.get("explicit"),
            },
            "query": atom_data(query),
            "complete_pair": complete,
            "proven_equal": equivalent_proven,
            "decisions_equal": equivalent_decisions,
            "unpruned": reference,
            "certified": guarded,
        })
        print("GO_DIFF_PROGRESS " + json.dumps({
            "completed": sample_idx + 1,
            "total": queries,
            "source_index": source_index,
            "complete_pair": complete,
            "proven_equal": equivalent_proven,
            "decisions_equal": equivalent_decisions,
            "unpruned_expanded": reference["expanded"],
            "certified_expanded": guarded["expanded"],
        }), flush=True)
    complete = [r for r in results if r["complete_pair"]]
    summary = {
        "requested_queries": queries,
        "fully_explored_pairs": len(complete),
        "incomplete_pairs": len(completeness_failures),
        "proven_mismatch_cases": sum(not r["proven_equal"] for r in complete),
        "decision_mismatch_cases": sum(not r["decisions_equal"] for r in complete),
        "proven_query_count": sum(bool(r["unpruned"]["proven"]) for r in complete),
        "derived_proof_query_count": sum(
            r["unpruned"]["rule_derived_proofs"] > 0 for r in complete
        ),
        "pruned": dict(pruning),
        "totals": {
            **{k: int(v) if k != "certification_internal_seconds"
               else round(v, 6) for k, v in totals.items()}
        },
        "unpruned_query_seconds": _summary(
            [r["unpruned"]["elapsed_seconds"] for r in complete]
        ),
        "certified_query_seconds": _summary(
            [r["certified"]["elapsed_seconds"] for r in complete]
        ),
        "incomplete_source_indices": completeness_failures,
        "mismatch_source_indices": decision_failures,
    }
    return {
        "experiment": "www27_go_full_graph_unpruned_certified_v1",
        "dataset": "GO/GO-CAM processed, full graph unless max_facts supplied",
        "processed_root": str(processed),
        "facts_loaded": len(ctx.kb.facts),
        "trusted_rules_loaded": len(ctx.kb.rules),
        "fact_limit": max_facts,
        "source_queries": len(source),
        "selection": "explicit_source_indices" if source_indices is not None else selection,
        "requested_source_indices": source_indices,
        "seed": seed,
        "max_depth": depth,
        "budget": budget,
        "max_seconds_per_search": max_seconds,
        "snapshot_sha256": snapshot_sha,
        "load_seconds": round(load_seconds, 6),
        "summary": summary,
        "rows": results,
        "passed": (
            not completeness_failures
            and not decision_failures
            and summary["fully_explored_pairs"] == queries
        ),
        "limitations": [
            "A finite-depth, finite-query differential comparison, NOT formal soundness.",
            "Unpruned reference uses the same inference implementation.",
            "Query-time results exclude snapshot loading and offline verification.",
            "No independent attestation of producer search history.",
            "Cases selected by fixed deterministic stratification, not IID sampling.",
        ],
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--processed", type=Path,
                   default=Path("data/go_case_study/processed"))
    p.add_argument("--queries", type=int, default=20)
    p.add_argument("--selection", choices=("stratified", "prefix"),
                   default="stratified")
    p.add_argument("--source-indices", type=str, default=None,
                   help="Comma-separated 0-based query.jsonl indices; requires matching --queries")
    p.add_argument("--seed", type=int, default=20271019)
    p.add_argument("--max-depth", type=int, default=3)
    p.add_argument("--budget", type=int, default=3000)
    p.add_argument("--max-seconds", type=float, default=30.0)
    p.add_argument("--max-facts", type=int, default=None,
                   help="Use only for a synthetic/subset smoke; default full KG")
    p.add_argument("--output", type=Path,
                   default=Path("results/www2027/go_differential_20q.json"))
    args = p.parse_args()
    if (args.queries < 1 or args.budget < 1 or args.max_depth < 0
            or args.max_seconds <= 0
            or (args.max_facts is not None and args.max_facts < 1)):
        p.error("invalid query, search, or fact limit")
    try:
        source_indices = (
            [int(x.strip()) for x in args.source_indices.split(",")]
            if args.source_indices is not None else None
        )
    except ValueError:
        p.error("--source-indices must be comma-separated integers")
    if source_indices is not None and (
        not source_indices or len(source_indices) != args.queries
    ):
        p.error("--queries must match --source-indices count")
    result = evaluate(
        processed=args.processed, queries=args.queries,
        selection=args.selection, seed=args.seed,
        depth=args.max_depth, budget=args.budget,
        max_seconds=args.max_seconds, max_facts=args.max_facts,
        source_indices=source_indices,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "experiment": result["experiment"],
        "facts_loaded": result["facts_loaded"],
        "trusted_rules_loaded": result["trusted_rules_loaded"],
        "snapshot_sha256": result["snapshot_sha256"],
        "selection": result["selection"],
        "summary": result["summary"],
        "passed": result["passed"],
        "output": str(args.output),
    }, indent=2))
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
