"""WWW27 P2.4: full real-GO producer-to-independent-checker mixed-source replay.

Single operator-pinned snapshot: original 85k+ GO facts and T1/T2/T3 source
rules/schema PLUS real GAF NOT|relation negatives from SHA256-pinned raw
archives. Includes 8 full-GO positive queries, 16 real GAF negative
associations from distinct source entities (8 per archive) and 8
non-entailed controls. The GAF relation/extension are ALWAYS retained.

The producer and checker each launch in separate OS processes. The checker
reconstructs the exact 32-query frontier and all decision/witness records.
The GAF negative ingestion occurs on the trusted operator side; it is
NOT a producer-provided negative. Tests are explicitly source-relative.
"""
from __future__ import annotations
import argparse
import copy
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from time import perf_counter

from trustkg.certificate_evidence import atom_data
from trustkg.independent_transition_audit import trusted_go_snapshot,canonical_sha256
from evaluate_www2027_gaf_not_real_refutations import gaf_record,sha256_file

ROOT=Path(__file__).resolve().parents[1]
GO=ROOT/"data/go_case_study/processed"
MANIFEST=ROOT/"data/go_case_study/manifest.json"
CAPTURE=ROOT/"scripts/capture_www2027_go_transition_audit.py"
VERIFY=ROOT/"scripts/verify_www2027_go_transition_audit.py"
PINNED_GO_INPUTS={
    "facts.jsonl":"4b7d88e5b8644d72852ec66b0214cf8a22efce244fc4ea94aa97d4f111406a3b",
    "queries.jsonl":"582cf475116ec44caa39008363d85387e7aea6055f514bbae902d59bb78db7cb",
    "schema.json":"7054e2d96778b9818cc9dfa2f93f2439a1c9b91562c2b56ee3f28e597b1e9251",
    "trusted_rules.jsonl":"d8d9288326b8bff16af5e168719ea4895738629e612ced4ccb5f6701f1022260",
}


def call(script,opts,timeout):
    start=perf_counter()
    try:
        proc=subprocess.run([sys.executable,str(script),*map(str,opts)],
            cwd=ROOT,capture_output=True,text=True,timeout=timeout,
            env={**os.environ,"PYTHONPATH":str(ROOT/"src")+os.pathsep+str(ROOT/"scripts")})
    except subprocess.TimeoutExpired:
        return {"exit":124,"timeout":True,"seconds":round(perf_counter()-start,6),
                "stderr_tail":"timeout"}
    return {"exit":proc.returncode,"timeout":False,
            "seconds":round(perf_counter()-start,6),
            "stderr_tail":proc.stderr[-800:] if proc.returncode else ""}


def qualified_negative_samples(entry,n):
    raw=ROOT/entry["path"]
    if not raw.is_file():
        raise ValueError("missing frozen GAF: "+str(raw))
    if sha256_file(raw)!=entry["sha256"]:
        raise ValueError("original GAF hash differs from frozen manifest: "+entry["name"])
    seen_entities=set()
    seen_atoms=set()
    selected=[]
    eligible=0
    with gzip.open(raw,"rt",encoding="utf-8") as handle:
        for source_row,line in enumerate(handle):
            value=gaf_record(line,source_row,entry["name"])
            if value is None:
                continue
            eligible+=1
            entity=value["entity"]
            if entity in seen_entities or value["atom"] in seen_atoms:
                continue
            if len(selected)<n:
                seen_entities.add(entity)
                seen_atoms.add(value["atom"])
                selected.append(value)
    if len(selected)!=n:
        raise ValueError("insufficient genuine NOT annotations from distinct entities: "+entry["name"])
    # Re-read raw original lines, retaining exact row hashes, not only the
    # normalized GAF atoms used for the trusted runtime fixture.
    wanted={value["line_index"]:value for value in selected}
    matched=set()
    with gzip.open(raw,"rt",encoding="utf-8") as handle:
        for source_row,line in enumerate(handle):
            if source_row not in wanted:continue
            reparse=gaf_record(line,source_row,entry["name"])
            if (reparse is None or reparse["atom"]!=wanted[source_row]["atom"]
                or reparse["raw_line_sha256"]!=wanted[source_row]["raw_line_sha256"]):
                raise ValueError("independent original line reparse failed")
            matched.add(source_row)
    if matched!=set(wanted):
        raise ValueError("missing genuine selected GAF lines")
    return selected,{
        "source":entry["name"],"original_url":entry["url"],
        "raw_sha256":entry["sha256"],"eligible_not_rows":eligible,
        "sampled_distinct_entities":len(selected),
    }


def selected_go_positives(n):
    known=set()
    chosen=[]
    with (GO/"queries.jsonl").open(encoding="utf-8") as f:
        for source_index,line in enumerate(f):
            if not line.strip():continue
            query=json.loads(line)["query"]
            key=(query["predicate"],tuple(query["args"]))
            if key in known:continue
            known.add(key)
            chosen.append({"query":query,"source_index":source_index})
            if len(chosen)==n:break
    if len(chosen)!=n:raise ValueError("insufficient distinct GO positive source queries")
    return chosen


def store_jsonl(path,rows):
    path.write_text("".join(json.dumps(x,sort_keys=True)+"\n" for x in rows),encoding="utf-8")


def patch_fixture(work,positive,negatives):
    processed=work/"operator_trusted_go_with_original_NOT"
    processed.mkdir()
    for name in ("facts.jsonl","schema.json","trusted_rules.jsonl"):
        shutil.copyfile(GO/name,processed/name)
    # Canonical negative order must equal producer full_snapshot_data() order;
    # producer holds these in a frozenset while the independent loader reads
    # source-file order. Unsorted human-then-mouse rows would break the pin.
    sorted_negatives=sorted(
        negatives,key=lambda item:(item["atom"].predicate,item["atom"].args)
    )
    store_jsonl(processed/"negatives.jsonl",[
        atom_data(n["atom"]) for n in sorted_negatives
    ])
    negative_queries=[{"query":atom_data(n["atom"])} for n in negatives]
    positive_queries=[{"query":x["query"]} for x in positive]
    # UNKNOWN controls are explicit unasserted *relation-qualified* queries,
    # not false biological negatives; these should always remain undecided.
    unknown_queries=[{"query":{
        "predicate":"gafQualifiedAssociation",
        "args":[positive[i]["query"]["args"][0],"enables",
                "urn:confirm:unasserted_real_go_control_"+str(i),""],
    }} for i in range(len(positive))]
    all_queries=positive_queries+negative_queries+unknown_queries
    query_sig=[(q["query"]["predicate"],tuple(q["query"]["args"])) for q in all_queries]
    if len(set(query_sig))!=len(query_sig):
        raise ValueError("mixed GO/GAF cohort is not distinct")
    store_jsonl(processed/"queries.jsonl",all_queries)
    digest=canonical_sha256(trusted_go_snapshot(processed))
    return processed,digest,{
        "positive_go_query_count":len(positive),
        "real_not_query_count":len(negatives),
        "unknown_control_count":len(unknown_queries),
        "total":len(all_queries),
        "genuine_positive_indices":[x["source_index"] for x in positive],
        "all_query_source_indices":list(range(len(all_queries))),
        "trusted_fixture_sha256":{
            n:sha256_file(processed/n)
            for n in ("facts.jsonl","schema.json","trusted_rules.jsonl",
                      "negatives.jsonl","queries.jsonl")
        },
    }


def require_true_deployment_decisions(trace,positive_count,negative_count):
    runs=trace["runs"]
    if len(runs)!=2*positive_count+negative_count:
        raise ValueError("unexpected producer cohort size")
    seen=[]
    for index,row in enumerate(runs):
        if row.get("complete") is not True:
            raise ValueError("incomplete bounded search for query "+str(index))
        query=trace["queries"][index]["query"]
        decisions=row["decision_summary"]
        if index<positive_count:
            ok=(bool(decisions)
                and any(v[0]==query and v[1]=="PROVEN" for v in decisions)
                and "refutation_witness" not in row)
            label="PROVEN"
        elif index<positive_count+negative_count:
            ok=(decisions==[[query,"REFUTED",0,0]]
                and row.get("refutation_witness",{}).get("reason")=="explicit-negative")
            label="REFUTED"
        else:
            ok=(decisions==[] and "refutation_witness" not in row)
            label="UNKNOWN"
        if not ok:
            raise ValueError("producer semantic mismatch "+label+" index "+str(index))
        seen.append({"query_index":index,"expected":label,"passed":ok,
                     "witness":bool(row.get("refutation_witness")),
                     "event_count":len(trace["queries"][index]["events"]),
                     "certificate_counts":row["certificates_by_kind"]})
    return seen


def verified(source,trace,indices,output,timeout,pin):
    run=call(VERIFY,[
        "--input",trace,"--processed",source,
        "--source-indices",",".join(map(str,indices)),
        "--max-depth","3","--max-events","100000",
        "--output",output,
    ],timeout)
    try:
        report=json.loads(output.read_text(encoding="utf-8"))
    except (OSError,ValueError):
        report=None
    good=(
        run["exit"]==0 and not run["timeout"]
        and isinstance(report,dict) and report.get("passed") is True
        and report.get("trusted_snapshot_sha256")==pin
        and report.get("independent_verdict_reconstruction_passed") is True
        and not report.get("failures")
    )
    return run,report,good


def attack(work,original,source,indices,pin,timeout,name,modify):
    mutant=copy.deepcopy(original)
    modify(mutant)
    if mutant==original:raise ValueError("non-effective attack "+name)
    trace=work/("falsified_"+name+".json")
    report=work/("attack_result_"+name+".json")
    trace.write_text(json.dumps(mutant,separators=(",",":"))+"\n",encoding="utf-8")
    response,verdict,accepted=verified(source,trace,indices,report,timeout,pin)
    structured=(
        not accepted and response["exit"] not in (0,124)
        and not response["timeout"]
        and isinstance(verdict,dict)
        and verdict.get("passed") is False
        and bool(verdict.get("failures"))
    )
    return {
        "name":name,"structured_rejection":structured,
        "reason":(verdict.get("failures") or [{}])[0].get("reason")
                  if isinstance(verdict,dict) else None,
        "exit_code":response["exit"],
    }


def experiment(timeout,per_gaf):
    for name,sha in PINNED_GO_INPUTS.items():
        if sha256_file(GO/name)!=sha:
            raise ValueError("full GO processed files differ from frozen baseline: "+name)
    manifest=json.loads(MANIFEST.read_text(encoding="utf-8"))
    names={x["name"]:x for x in manifest["sources"]}
    negative=[]
    source_rows=[]
    for key in ("human_gaf","mouse_gaf"):
        samples,summary=qualified_negative_samples(names[key],per_gaf)
        negative.extend(samples)
        source_rows.append(summary)
    go=selected_go_positives(8)
    with tempfile.TemporaryDirectory(prefix="www27_P24_full_GO_mixed_") as tmp:
        work=Path(tmp)
        processed,pin,cohort=patch_fixture(work,go,negative)
        capture_path=work/"genuine_full_GO_source_producer.json"
        c=call(CAPTURE,[
            "--processed",processed,"--source-indices",
            ",".join(map(str,cohort["all_query_source_indices"])),
            "--max-depth","3","--budget","3000",
            "--max-seconds","35","--output",capture_path,
        ],timeout)
        if c["exit"]!=0 or c["timeout"] or not capture_path.is_file():
            raise ValueError("complete GO producer capture failed "+str(c))
        producer_trace=json.loads(capture_path.read_text(encoding="utf-8"))
        if (producer_trace.get("passed_capture_completeness") is not True
            or producer_trace.get("producer_snapshot_sha256")!=pin):
            raise ValueError("producer not complete or wrong trusted source pin")
        cases=require_true_deployment_decisions(producer_trace,8,len(negative))
        checked_path=work/"external_complete_independent_check.json"
        v,verdict,passage=verified(
            processed,capture_path,cohort["all_query_source_indices"],
            checked_path,timeout,pin,
        )
        if not passage:
            raise ValueError("independent complete mixed-go checker failed "+str(v)+
                             " "+str((verdict or {}).get("failures")))
        n=8
        u=n+len(negative)
        actions=[
            ("erase_real_NOT_witness",
             lambda trace:trace["runs"][n].pop("refutation_witness")),
            ("forge_real_NOT_reason",
             lambda trace:trace["runs"][n]["refutation_witness"].__setitem__(
                "reason","not_attested")),
            ("forge_real_NOT_entity",
             lambda trace:trace["runs"][n]["refutation_witness"]["claim"]["args"].__setitem__(
                0,"urn:confirm:forged_entity")),
            ("forge_refuted_as_proven",
             lambda trace:trace["runs"][n].__setitem__(
                "decision_summary",[[trace["queries"][n]["query"],"PROVEN",1,0]])),
            ("claim_unknown_is_refuted",
             lambda trace:trace["runs"][u].__setitem__(
                "decision_summary",[[trace["queries"][u]["query"],"REFUTED",0,0]])),
            ("delete_positive_search_event",
             lambda trace:trace["queries"][0]["events"].pop(0)),
            ("wrong_real_source_query_index",
             lambda trace:trace["source_indices"].__setitem__(0,999999)),
            ("missing_negative_source_run",
             lambda trace:trace["runs"].pop(n)),
        ]
        attacks=[]
        for name,mutate in actions:
            row=attack(work,producer_trace,processed,cohort["all_query_source_indices"],
                       pin,timeout,name,mutate)
            attacks.append(row)
            print("WWW27_P24_ATTACK "+json.dumps(row),flush=True)
        verified_queries=sum(x["passed"] for x in cases)
        verified_attacks=sum(x["structured_rejection"] for x in attacks)
        return {
            "experiment":"www27_p24_real_GO_full_snapshot_qualified_NOT_mixed_replay_v1",
            "passed":verified_queries==cohort["total"]
                     and verified_attacks==len(attacks),
            "real_GO_full_source_and_real_negative_in_same_snapshot":True,
            "original_source_sha256":PINNED_GO_INPUTS,
            "genuine_NOT_archives":source_rows,
            "operator_trusted_combined_snapshot_sha256":pin,
            "cohort":cohort,
            "independent_replay_queries":verified_queries,
            "independent_replay_verdicts_passed":passage,
            "independent_verifier_process_seconds":v["seconds"],
            "producer_process_seconds":c["seconds"],
            "producer_events_total":sum(x["event_count"] for x in cases),
            "real_NOT_samples":[{
                "source":e["source"],"original_line_index":e["line_index"],
                "original_line_sha256":e["raw_line_sha256"],
                "qualified_claim":atom_data(e["atom"]),
                "relation":e["relation"],"extension":e["annotation_extension"],
                "gaf_evidence":e["evidence_code"],
            } for e in negative],
            "query_rows":cases,
            "tampering_attempts":len(attacks),
            "tampering_structured_rejections":verified_attacks,
            "attacks":attacks,
            "limitations":[
                "Pinned original full GO processed facts/rules/schema plus original GAF NOT rows in one operator-built snapshot. The raw-source-to-trusted-fixture mapping is trusted ingestion, not independently implemented by the checker.",
                "GAF NOT applies only to gafQualifiedAssociation with an exact relation and annotation extension, never generic annotatedTo or unrestricted OWL propagation.",
                "Eight positive GO queries selected deterministically from source; eight UNKNOWN query objects are intentionally synthetic nonentailed controls, NOT synthetic negative facts.",
                "This establishes exact bounded full frontier/claims replay for a mixed cohort, not the correctness of the biological sources, cryptographic provenance, or arbitrary OWL completeness.",
                "The original real GO compiler excluded NOT; this follow-up adds them additively to a temporary trusted fixture, leaving the original processed files unchanged.",
            ]
        }


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--per-gaf",type=int,default=8)
    p.add_argument("--timeout",type=int,default=120)
    a=p.parse_args()
    try:
        if a.per_gaf<3 or a.per_gaf>20 or a.timeout<60:
            raise ValueError("unsupported sample/timeout")
        result=experiment(a.timeout,a.per_gaf)
    except Exception as err:
        result={
            "experiment":"www27_p24_real_GO_full_snapshot_qualified_NOT_mixed_replay_v1",
            "passed":False,
            "blocked_reason":f"{type(err).__name__}: {err}",
        }
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("WWW27_P24_SUMMARY "+json.dumps({
        "passed":result["passed"],
        "cohort":result.get("cohort"),
        "replay_queries":result.get("independent_replay_queries"),
        "rejected_mutants":result.get("tampering_structured_rejections"),
        "blocked_reason":result.get("blocked_reason"),
    }),flush=True)
    return 0 if result["passed"] else 1


if __name__=="__main__":
    raise SystemExit(main())
