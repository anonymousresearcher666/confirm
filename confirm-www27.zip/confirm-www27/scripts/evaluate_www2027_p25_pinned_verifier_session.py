"""WWW 2027 P2.5: repeated independent verification on ONE trusted frozen snapshot.

Comparisons:
* cold: original independent verifier CLI, new OS process and source index per
  32-query batch, 3 repetitions.
* warm: one separate independent verifier OS process, trusted snapshot/index
  loaded ONCE, then full event/claim verification independently repeated 3
  times. Never cache derived verdicts or accepted producer event states.

Security: operator controls --processed, --source-indices, --max-depth,
--pinned-digest, and request paths. The untrusted trace contains no trusted
source. Four forged traces must be rejected with structured reasons in BOTH
modes. This is a repeated-workload conditional optimization, not a cold-start
performance claim and not proof of a sandbox against host compromise.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import statistics
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path
from time import perf_counter

from trustkg.independent_transition_audit import (
    TrustedGOIndex,atom,canonical_sha256,replay_trace,trusted_go_snapshot,
)
from trustkg.independent_verdict_audit import compare_decisions
from evaluate_www2027_p24_full_go_real_not_mixed import (
    MANIFEST,GO,CAPTURE,VERIFY,call,patch_fixture,qualified_negative_samples,
    selected_go_positives,PINNED_GO_INPUTS,
)
from evaluate_www2027_gaf_not_real_refutations import sha256_file

ROOT=Path(__file__).resolve().parents[1]


def trusted_query_list(path,indices):
    source=[]
    with (path/"queries.jsonl").open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                obj=json.loads(line)["query"]
                source.append(atom(obj["predicate"],obj["args"]))
    if not indices or len(set(indices))!=len(indices) or any(
        x<0 or x>=len(source) for x in indices
    ):
        raise ValueError("invalid external query indices")
    return [source[i] for i in indices]


def verify_one(trace,expected_queries,index,pin,indices,max_depth):
    """A fresh, source-authorized replay, no cached acceptance decisions."""
    if (
        type(trace) is not dict
        or trace.get("protocol")!="independent_go_transition_audit_v2"
        or trace.get("source_indices")!=indices
        or trace.get("max_depth")!=max_depth
        or trace.get("producer_snapshot_sha256")!=pin
        or trace.get("passed_capture_completeness") is not True
        or trace.get("facts_loaded")!=len(index.snapshot["facts"])
    ):
        return {"passed":False,"failures":[{"reason":"mismatching_trusted_metadata_or_snapshot"}]}
    replay=replay_trace(trace,expected_queries,index,max_depth=max_depth)
    if replay["passed"]:
        verdict=compare_decisions(trace,index,indices)
    else:
        verdict={"passed":False,"failures":[{"reason":"verdict_check_skipped_failed_transition_replay"}]}
    return {
        "passed":bool(replay["passed"] and verdict["passed"]),
        "failures":replay["failures"]+verdict["failures"],
        "certificate_count":replay["certificate_count"],
        "replayed_query_count":replay["queries"],
        "independent_verdict_rows":verdict.get("rows"),
        "transition_replay_seconds":replay["elapsed_seconds"],
    }


def worker(processed,trace_file,external_indices,depth,pin,repeats,mutant_paths,output):
    begin=perf_counter()
    a=perf_counter()
    source=trusted_go_snapshot(processed)
    digest=canonical_sha256(source)
    queries=trusted_query_list(processed,external_indices)
    loaded=perf_counter()-a
    if digest!=pin:
        raise ValueError("trusted snapshot digest does not match operator pin")
    a=perf_counter()
    index=TrustedGOIndex(source)
    prepared=perf_counter()-a
    checked=[]
    for repeat in range(repeats):
        a=perf_counter()
        trace=json.loads(trace_file.read_text(encoding="utf-8"))
        result=verify_one(trace,queries,index,pin,external_indices,depth)
        elapsed=perf_counter()-a
        checked.append({
            "repeat":repeat,"passed":result["passed"],
            "elapsed_seconds":round(elapsed,6),
            "transition_replay_seconds":result.get("transition_replay_seconds"),
            "independent_query_count":result.get("replayed_query_count"),
            "certificate_count":result.get("certificate_count"),
            "failures":result["failures"][:3],
        })
    rejects=[]
    for path in mutant_paths:
        start=perf_counter()
        mutated=json.loads(path.read_text(encoding="utf-8"))
        result=verify_one(mutated,queries,index,pin,external_indices,depth)
        rejects.append({
            "name":path.stem,"structured_rejection":(
                result["passed"] is False and bool(result["failures"])
            ),
            "reason":result["failures"][0]["reason"] if result["failures"] else None,
            "elapsed_seconds":round(perf_counter()-start,6),
        })
    payload={
        "passed":all(x["passed"] for x in checked)
        and all(x["structured_rejection"] for x in rejects),
        "trusted_digest_reconstructed":digest,
        "trusted_snapshot_load_seconds":round(loaded,6),
        "trusted_index_build_seconds":round(prepared,6),
        "total_fresh_warm_verifier_process_seconds":round(perf_counter()-begin,6),
        "repetitions":checked,"mutants":rejects,
        "source_loaded_once":True,"index_built_once":True,
        "per_request_frontier_rederived":True,
    }
    output.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    return payload


def make_mutants(original,dir):
    n=8
    u=24
    moves=[
        ("erase_real_negative_witness",
          lambda q:q["runs"][n].pop("refutation_witness")),
        ("forge_negative_source_digest",
          lambda q:q["runs"][n]["refutation_witness"].__setitem__(
              "trusted_snapshot_sha256","0"*64)),
        ("forge_unknown_as_refuted",
          lambda q:q["runs"][u].__setitem__(
              "decision_summary",[[q["queries"][u]["query"],"REFUTED",0,0]])),
        ("delete_real_positive_event",
          lambda q:q["queries"][0]["events"].pop(0)),
    ]
    paths=[]
    for name,change in moves:
        attack=copy.deepcopy(original)
        change(attack)
        if attack==original:
            raise ValueError("mutation was ineffective: "+name)
        p=dir/("tampered_"+name+".json")
        p.write_text(json.dumps(attack,separators=(",",":"))+"\n",encoding="utf-8")
        paths.append(p)
    return paths


def cold_checker(processed,trace,indices,depth,path,timeout):
    finished=call(VERIFY,[
        "--input",trace,"--processed",processed,
        "--source-indices",",".join(map(str,indices)),
        "--max-depth",str(depth),"--output",path,
    ],timeout)
    try:
        payload=json.loads(path.read_text(encoding="utf-8"))
    except (OSError,ValueError):
        payload=None
    return finished,payload


def run(repeats,timeout):
    for name,sha in PINNED_GO_INPUTS.items():
        if sha256_file(GO/name)!=sha:
            raise ValueError("frozen full GO source SHA mismatch "+name)
    manifest=json.loads(MANIFEST.read_text(encoding="utf-8"))
    by_name={s["name"]:s for s in manifest["sources"]}
    negatives=[]
    archives=[]
    for kind in ("human_gaf","mouse_gaf"):
        rec,meta=qualified_negative_samples(by_name[kind],8)
        negatives.extend(rec)
        archives.append(meta)
    with tempfile.TemporaryDirectory(prefix="www27_P25_warm_source_") as temp:
        work=Path(temp)
        source,digest,cohort=patch_fixture(work,selected_go_positives(8),negatives)
        trace_file=work/"genuine_source_producer.json"
        captured=call(CAPTURE,[
            "--processed",source,"--source-indices",
            ",".join(map(str,cohort["all_query_source_indices"])),
            "--max-depth","3","--budget","3000","--max-seconds","35",
            "--output",trace_file,
        ],timeout)
        if captured["exit"]!=0 or captured["timeout"]:
            raise ValueError("failed genuine 32 query producer capture "+str(captured))
        trace=json.loads(trace_file.read_text(encoding="utf-8"))
        if not trace.get("passed_capture_completeness"):
            raise ValueError("producer search incomplete")
        cases=trace["runs"]
        if len(cases)!=32 or any(run["complete"] is not True for run in cases):
            raise ValueError("producer did not return 32 complete runs")
        indices=cohort["all_query_source_indices"]
        mutants=make_mutants(trace,work)
        cold=[]
        for i in range(repeats):
            started,report=cold_checker(source,trace_file,indices,3,
                work/("cold_baseline_"+str(i)+".json"),timeout)
            valid=(started["exit"]==0 and not started["timeout"]
                   and type(report) is dict
                   and report.get("passed") is True
                   and report.get("independent_verdict_reconstruction_passed") is True
                   and report.get("trusted_snapshot_sha256")==digest)
            cold.append({
                "repeat":i,"passed":valid,
                "whole_process_wall_seconds":started["seconds"],
                "snapshot_load_seconds":report.get("snapshot_load_seconds") if report else None,
                "index_prepare_seconds":report.get("trusted_index_prepare_seconds") if report else None,
                "transition_replay_seconds":report.get("transition_replay_seconds") if report else None,
            })
            if not valid:raise ValueError("cold independent verifier failed "+str(started))
        cold_attacks=[]
        for path in mutants:
            process,report=cold_checker(source,path,indices,3,
                work/("cold_attacked_"+path.stem+".json"),timeout)
            good=(process["exit"] not in (0,124)
                  and not process["timeout"]
                  and type(report) is dict
                  and report.get("passed") is False
                  and bool(report.get("failures")))
            cold_attacks.append({
                "name":path.stem,"structured_rejection":good,
                "whole_process_wall_seconds":process["seconds"],
                "reason":(report.get("failures") or [{}])[0].get("reason")
                                   if report else None,
            })
        # Warm independent verifier receives the operator's trusted source
        # pin and cohort explicitly. The producer trace never controls them.
        warm_output=work/"warm_independent_session.json"
        warm_cmd=[
            sys.executable,str(Path(__file__).resolve()),"--worker",
            "--processed",str(source),"--trace",str(trace_file),
            "--source-indices",",".join(map(str,indices)),
            "--max-depth","3","--pin",digest,"--repeats",str(repeats),
            "--output",str(warm_output),
        ]
        for path in mutants:warm_cmd.extend(["--mutant",str(path)])
        began=perf_counter()
        try:
            finished=subprocess.run(warm_cmd,cwd=ROOT,capture_output=True,
                text=True,timeout=timeout,
                env={**os.environ,"PYTHONPATH":str(ROOT/"src")+os.pathsep+str(ROOT/"scripts")})
        except subprocess.TimeoutExpired:
            raise ValueError("warm independent verifier subprocess timed out")
        warm_whole_wall=round(perf_counter()-began,6)
        if finished.returncode!=0 or not warm_output.is_file():
            raise ValueError("warm independent checker subprocess failed: "+
                             finished.stderr[-500:])
        warm=json.loads(warm_output.read_text(encoding="utf-8"))
        if not warm["passed"] or warm["trusted_digest_reconstructed"]!=digest:
            raise ValueError("warm repeated replay or tamper rejection did not pass")
        all_ok=all(x["passed"] for x in cold)
        all_attacks=all(x["structured_rejection"] for x in cold_attacks)
        if not all_ok or not all_attacks:
            raise ValueError("cold baseline or attack test failed")
        cold_baseline_sum=sum(x["whole_process_wall_seconds"] for x in cold)
        cold_attacks_sum=sum(x["whole_process_wall_seconds"] for x in cold_attacks)
        cold_sum=cold_baseline_sum+cold_attacks_sum
        warm_query_total=sum(x["elapsed_seconds"] for x in warm["repetitions"])
        return {
            "experiment":"www27_P25_pinned_session_verifier_cold_vs_reused_index_v1",
            "passed":True,
            "trusted_source_sha256":digest,
            "genuine_not_archives":archives,
            "source_inputs":cohort["trusted_fixture_sha256"],
            "batch_query_count":32,
            "positive_real_go":8,
            "authentic_qualified_gaf_not":16,
            "synthetic_unknown_controls":8,
            "repeats":repeats,
            "attacks_per_mode":len(mutants),
            "cold_runs":cold,
            "cold_structured_rejections":cold_attacks,
            "warm_process_wall_seconds":warm_whole_wall,
            "warm":warm,
            "cold_total_wall_seconds":round(cold_sum,6),
            "cold_successful_baseline_wall_seconds":round(cold_baseline_sum,6),
            "cold_attack_rejections_wall_seconds":round(cold_attacks_sum,6),
            "cold_median_per_32_query_batch_seconds":round(
                statistics.median(x["whole_process_wall_seconds"] for x in cold),6),
            "warm_median_per_32_query_batch_seconds":round(
                statistics.median(x["elapsed_seconds"] for x in warm["repetitions"]),6),
            "warm_one_time_snapshot_plus_index_seconds":round(
                warm["trusted_snapshot_load_seconds"]+warm["trusted_index_build_seconds"],6),
            "warm_replay_all_batches_wall_seconds":round(warm_query_total,6),
            "conditional_reuse_amortization_factor":round(
                cold_sum/warm_whole_wall,6),
            "limitations":[
                "Same immutable trusted dataset and same genuine 32-query producer trace verified repeatedly. This is a controlled repeated workload, not 32 novel producer workloads per repetition.",
                "Warm session changes lifecycle, not logical semantics. Source is loaded and indexed once; every batch still independently reruns full frontier and verdict verification.",
                "Cold baseline invokes original verifier in a distinct fresh Python process each time, reloading trusted source for every batch. Warm verifier is a single separate OS process from producer.",
                "Amortization factor compares matching workloads: 3 clean verification requests PLUS 4 malicious verification requests using individual cold process launches versus one warm process invocation (including init and all seven requests). It is not a generic speedup or reasoner benchmark.",
                "Warm pin protects snapshot agreement at initialization under operator-controlled trusted files. External GAF ingestion is trusted operator-side and the verifier host itself is not sandboxed.",
                "Both checkers structurally reject four attacks. Never credit mere subprocess crash or missing structured report.",
                "No original GO processed file or paper .tex is modified.",
            ],
        }


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--worker",action="store_true")
    p.add_argument("--processed",type=Path)
    p.add_argument("--trace",type=Path)
    p.add_argument("--source-indices")
    p.add_argument("--max-depth",type=int,default=3)
    p.add_argument("--pin")
    p.add_argument("--mutant",type=Path,action="append",default=[])
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--repeats",type=int,default=3)
    p.add_argument("--timeout",type=int,default=120)
    args=p.parse_args()
    try:
        if args.repeats<2 or args.repeats>10:
            raise ValueError("require 2..10 same-trace repetitions")
        if args.worker:
            if not args.processed or not args.trace or not args.pin or not args.source_indices:
                raise ValueError("external operator trust inputs missing")
            indices=[int(x) for x in args.source_indices.split(",")]
            result=worker(args.processed,args.trace,indices,
                          args.max_depth,args.pin,args.repeats,args.mutant,args.output)
        else:
            result=run(args.repeats,args.timeout)
    except Exception as error:
        result={
            "experiment":"www27_P25_pinned_session_verifier_cold_vs_reused_index_v1",
            "passed":False,"blocked_reason":f"{type(error).__name__}: {error}",
        }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("WWW27_P25 "+json.dumps({
        "passed":result["passed"],
        "cold_median":result.get("cold_median_per_32_query_batch_seconds"),
        "warm_median":result.get("warm_median_per_32_query_batch_seconds"),
        "amortization_factor":result.get("conditional_reuse_amortization_factor"),
        "blocked_reason":result.get("blocked_reason"),
    }),flush=True)
    return 0 if result["passed"] else 1


if __name__=="__main__":
    raise SystemExit(main())
