"""P2.8 source-authentic tripartite GO/GO-CAM claims, full independent replay.

A single operator-pinned full GO snapshot contains:
 - 8 real GO T1 positives, 8 real GO-CAM T3/T4 native Horn positives;
 - 16 genuine human/mouse GAF NOT qualified direct negatives;
 - 16 real GO-CAM source entity/target nonentailed controls independently
   checked in prior official Nemo/ConFIRM P1.1 (NOT synthetic fake URNs).
All 48 source queries are different. A fresh producer captures the full
ordered frontier; a separate checker rederives all outcomes and certificates.
Six real-trace attacks must be rejected structurally, never via timeout/crash.
Not proof of biological falsity, OWL completeness or trusted GAF provenance.
"""
from __future__ import annotations
import argparse
import copy
import json
import tempfile
from pathlib import Path
from trustkg.certificate_evidence import atom_data
from trustkg.independent_transition_audit import canonical_sha256,trusted_go_snapshot
from evaluate_www2027_gaf_not_real_refutations import sha256_file
from evaluate_www2027_p24_full_go_real_not_mixed import (
    ROOT,GO,MANIFEST,CAPTURE,VERIFY,call,
    PINNED_GO_INPUTS,selected_go_positives,patch_fixture,
    qualified_negative_samples,store_jsonl,
)

NEMO_REPORT=ROOT/"results/www2027/www27_nemo_p11_gocam_t3_t4_balanced_v1.json"
FAMILIES=("GO_T3_gocam_cellular_location",
          "GO_T4_gocam_process_participation")
LABELS=("PROVEN","REFUTED","UNKNOWN")


def pinned_nemo_cases():
    report=json.loads(NEMO_REPORT.read_text(encoding="utf-8"))
    if (
        report.get("passed") is not True
        or report.get("cohort_size")!=32
        or report.get("confirm_certified_matched_count")!=32
        or report.get("nemo_all_process_results_passed")!=3
        or report.get("nmo_version")!="nemo-cli 0.10.1"
        or report.get("source_inputs_sha256")!=PINNED_GO_INPUTS
        or any(not x.get("passed") or x.get("total_matched")!=32
               for x in report.get("nemo_runs",[]))
    ):
        raise ValueError("official Nemo T3/T4 source cohort was not independently validated")
    rows=report["per_query"]
    if len(rows)!=32:raise ValueError("Nemo T3/T4 prior source rows incomplete")
    positives=[]
    controls=[]
    for rule in FAMILIES:
        pos=[x for x in rows if x["rule_id"]==rule and x["expected"] is True]
        neg=[x for x in rows if x["rule_id"]==rule and x["expected"] is False]
        if len(pos)!=8 or len(neg)!=8 or any(x["source_explicit_fact"] for x in pos):
            raise ValueError("GO-CAM source-positive or real nonentailed cohort is not verified")
        if any(x["source_class"]!="real_target_nonentailed_control" for x in neg):
            raise ValueError("GO-CAM controls are not source-linked nonentailed targets")
        if any(x["source_class"]!="source_grounded_nonexplicit" for x in pos):
            raise ValueError("GO-CAM positive queries are not source-grounded novel heads")
        positives.extend(pos[:4])
        controls.extend(neg)
    return positives,controls,sha256_file(NEMO_REPORT)


def actual_gaf_negatives():
    manifest=json.loads(MANIFEST.read_text(encoding="utf-8"))
    by_name={entry["name"]:entry for entry in manifest["sources"]}
    samples=[]
    meta=[]
    for kind in ("human_gaf","mouse_gaf"):
        rows,info=qualified_negative_samples(by_name[kind],8)
        samples.extend(rows)
        meta.append(info)
    return samples,meta


def construct(work):
    for name,expected in PINNED_GO_INPUTS.items():
        if sha256_file(GO/name)!=expected:
            raise ValueError("operator original GO frozen source mismatch "+name)
    original_go=selected_go_positives(8)
    gocam_pos,gocam_unknown,nemo_report_sha=pinned_nemo_cases()
    gaf_neg,archive_meta=actual_gaf_negatives()
    processed,original_source_pin,_=patch_fixture(work,original_go,gaf_neg)
    original_query_file_sha256=sha256_file(processed/"queries.jsonl")
    entries=[]
    categories=[]
    for item in original_go:
        entries.append(item["query"])
        categories.append("real_GO_T1_PROVEN")
    for row in gocam_pos:
        entries.append({"predicate":row["predicate"],"args":row["query"]})
        categories.append("real_GO_CAM_T3_T4_PROVEN")
    for neg in gaf_neg:
        entries.append(atom_data(neg["atom"]))
        categories.append("original_GAF_qualified_NOT_REFUTED")
    for row in gocam_unknown:
        entries.append({"predicate":row["predicate"],"args":row["query"]})
        categories.append("real_GO_CAM_nonentailed_UNKNOWN")
    if len(entries)!=48:
        raise ValueError("expected 48 source-provenance classified query inputs")
    keys=[(q["predicate"],tuple(q["args"])) for q in entries]
    if len(set(keys))!=len(keys):
        raise ValueError("source query set contains duplicates")
    store_jsonl(processed/"queries.jsonl",[{"query":q} for q in entries])
    digest=canonical_sha256(trusted_go_snapshot(processed))
    if digest!=original_source_pin:
        raise ValueError("replacing only the query list unexpectedly changed the pinned facts/rules/negative snapshot")
    query_file_sha256=sha256_file(processed/"queries.jsonl")
    if query_file_sha256==original_query_file_sha256:
        raise ValueError("48-query operator selection did not change the pinned query manifest")
    independently_loaded=[json.loads(line)["query"] for line in
                          (processed/"queries.jsonl").read_text(encoding="utf-8").splitlines()
                          if line.strip()]
    if independently_loaded!=entries:
        raise ValueError("operator 48-query manifest failed source roundtrip")
    return processed,digest,{
        "nemo_go_cam_reference_sha256":nemo_report_sha,
        "original_GO_input_sha256":PINNED_GO_INPUTS,
        "original_GAF_archives":archive_meta,
        "source_queries_sha256":query_file_sha256,
        "previous_32_query_manifest_sha256":original_query_file_sha256,
        "source_negatives_sha256":sha256_file(processed/"negatives.jsonl"),
        "query_categories":categories,
        "real_GO_T1_positive":8,
        "real_GO_CAM_T3_T4_positive":8,
        "genuine_human_mouse_GAF_qualified_negative":16,
        "real_GO_CAM_unknown_controls":16,
    }


def producer_check(trace,source_pin,queries):
    if (
        trace.get("passed_capture_completeness") is not True
        or trace.get("producer_snapshot_sha256")!=source_pin
        or trace.get("source_indices")!=list(range(48))
        or len(trace.get("runs",[]))!=48
        or len(trace.get("queries",[]))!=48
    ):
        raise ValueError("actual producer source contract or search completeness mismatch")
    checked=[]
    for index,(run,qtrace) in enumerate(zip(trace["runs"],trace["queries"])):
        if run.get("complete") is not True:
            raise ValueError("producer bounded search incomplete index "+str(index))
        query=queries[index]
        if qtrace.get("query")!=query:
            raise ValueError("query silently changed in producer index "+str(index))
        decision=run["decision_summary"]
        if index<16:
            good=(
                len(decision)>0
                and any(x[0]==query and x[1]=="PROVEN"
                        and x[2]>=1 for x in decision)
                and "refutation_witness" not in run
            )
            label="PROVEN"
        elif index<32:
            good=(
                decision==[[query,"REFUTED",0,0]]
                and run.get("refutation_witness",{}).get("reason")=="explicit-negative"
            )
            label="REFUTED"
        else:
            good=decision==[] and "refutation_witness" not in run
            label="UNKNOWN"
        if not good:
            raise ValueError("source-authentic producer status differs from "+
                             label+" for query "+str(index))
        checked.append({
            "source_index":index,"expected":label,
            "certificate_counts":run.get("certificates_by_kind",{}),
            "events":len(qtrace["events"]),
            "terminal_proof_count":run.get("terminal_events",0),
        })
    return checked


def independent_verified(work,processed,pin,path,ids,label,timeout):
    output=work/(label+"_verifier_report.json")
    res=call(VERIFY,[
        "--input",path,"--processed",processed,
        "--source-indices",",".join(str(x) for x in ids),
        "--max-depth","3","--max-events","100000",
        "--output",output,
    ],timeout)
    try:
        report=json.loads(output.read_text(encoding="utf-8"))
    except (ValueError,OSError):
        report=None
    correct=(
        res["exit"]==0 and not res["timeout"]
        and type(report) is dict and report.get("passed") is True
        and report.get("independent_verdict_reconstruction_passed") is True
        and report.get("trusted_snapshot_sha256")==pin
        and report.get("source_indices")==ids
        and not report.get("failures")
    )
    return res,report,correct


def attacks(work,trace,processed,pin,timeout):
    actions=[
        ("drop_native_T3_positive_expansion",
         lambda x:x["queries"][8]["events"].pop(0)),
        ("forge_native_T4_final_proven_count",
         lambda x:x["runs"][12]["decision_summary"][0].__setitem__(2,77)),
        ("remove_real_GAF_negative_witness",
         lambda x:x["runs"][16].pop("refutation_witness")),
        ("forge_GAF_negative_relation",
         lambda x:x["runs"][16]["refutation_witness"]["claim"]["args"].__setitem__(
             1,"different_qualification")),
        ("invent_proven_on_real_GO_CAM_unknown",
         lambda x:x["runs"][32].__setitem__(
             "decision_summary",[[x["queries"][32]["query"],"PROVEN",1,0]])),
        ("change_external_source_query_id",
         lambda x:x["source_indices"].__setitem__(0,99999)),
    ]
    output=[]
    for name,change in actions:
        changed=copy.deepcopy(trace)
        change(changed)
        if changed==trace:
            raise ValueError("ineffective deliberate mutation "+name)
        path=work/("modified_"+name+".json")
        path.write_text(json.dumps(changed,separators=(",",":"))+"\n",encoding="utf-8")
        proc,report,accepted=independent_verified(
            work,processed,pin,path,list(range(48)),name,timeout)
        structured=(
            not accepted and proc["exit"] not in (0,124)
            and not proc["timeout"]
            and type(report) is dict and report.get("passed") is False
            and bool(report.get("failures"))
        )
        output.append({
            "mutation":name,
            "structured_rejection":structured,
            "reason":(report.get("failures") or [{}])[0].get("reason")
                       if type(report) is dict else None,
        })
        print("WWW27_P28_MUTATION "+json.dumps(output[-1]),flush=True)
    return output


def run(timeout):
    with tempfile.TemporaryDirectory(prefix="www27_P28_real_GO_cross_family_") as tmp:
        work=Path(tmp)
        processed,pin,cohort=construct(work)
        trace_path=work/"source_authentic_48_query_untrusted_producer.json"
        created=call(CAPTURE,[
            "--processed",processed,"--source-indices",",".join(map(str,range(48))),
            "--max-depth","3","--budget","4000","--max-seconds","35",
            "--output",trace_path,
        ],timeout)
        if created["exit"]!=0 or created["timeout"] or not trace_path.is_file():
            raise ValueError("48-query source producer failed: "+repr(created))
        trace=json.loads(trace_path.read_text(encoding="utf-8"))
        queries=[x["query"] for x in trace["queries"]]
        # Source query objects are locked by operator-owned queries.jsonl;
        # avoid trusting source-query types only because producer said so.
        trusted=[json.loads(line)["query"] for line in
                 (processed/"queries.jsonl").read_text(encoding="utf-8").splitlines()
                 if line.strip()]
        if queries!=trusted:
            raise ValueError("producer queries do not match operator source queries")
        outcomes=producer_check(trace,pin,trusted)
        verified,report,good=independent_verified(
            work,processed,pin,trace_path,list(range(48)),"full",timeout)
        if not good:
            raise ValueError("independent full-frontier verdict replay failed "+
                             repr(verified)+" "+
                             repr((report or {}).get("failures")))
        anomalies=attacks(work,trace,processed,pin,timeout)
        if not all(x["structured_rejection"] for x in anomalies):
            raise ValueError("one forged real-source outcome was accepted by verifier")
        return {
            "experiment":"www27_p28_full_GO_cross_rule_original_GAF_and_real_unknown_v2",
            "passed":True,
            "operator_source_pin_sha256":pin,
            "cohort":cohort,
            "query_count":48,
            "independently_replayed_source_queries":48,
            "producer_real_source_status_counts":{
                "PROVEN":16,"REFUTED":16,"UNKNOWN":16,
            },
            "producer_wall_seconds":created["seconds"],
            "independent_verifier_wall_seconds":verified["seconds"],
            "complete_frontier_events":sum(x["events"] for x in outcomes),
            "independent_pruning_certificates":report.get("certificate_count"),
            "independent_verdict_reconstruction_passed":good,
            "deliberate_real_trace_mutations":len(anomalies),
            "structured_tampering_rejections":sum(x["structured_rejection"] for x in anomalies),
            "mutations":anomalies,"query_rows":outcomes,
            "limitations":[
                "All positive GO T1/T3/T4 claims and real GO-CAM nonentailed UNKNOWN controls are constructed from original GO data and prior independently verified official Nemo T3/T4 results.",
                "The explicit-negative 16 human/mouse GAF NOT statements are source-authentic, but operator-side GAF ingestion/trusted authority is assumed rather than independently signed.",
                "UNKNOWN cases are nonentailed under the finite native source-Horn fragment, not negative biological facts or arbitrary OWL consequences.",
                "Bounded search and source pinning do not establish general open-world completeness, arbitrary malicious source detection, or third-party provenance authority.",
                "Experiment uses one 48-query mixed producer transcript and one full fresh checker process, plus six forged traces. It does not evaluate a production distributed verification service.",
                "The original source files and .tex remain unchanged; only aggregate JSON is published.",
            ],
        }


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--timeout",type=int,default=120)
    args=p.parse_args()
    try:
        if args.timeout<60:raise ValueError("insufficient per-process timeout")
        result=run(args.timeout)
    except Exception as err:
        result={
            "experiment":"www27_p28_full_GO_cross_rule_original_GAF_and_real_unknown_v2",
            "passed":False,"blocked_reason":f"{type(err).__name__}: {err}",
        }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("WWW27_P28 "+json.dumps({
        "passed":result["passed"],
        "queries":result.get("query_count"),
        "tampering_rejections":result.get("structured_tampering_rejections"),
        "blocked_reason":result.get("blocked_reason"),
    }),flush=True)
    return 0 if result["passed"] else 1

if __name__=="__main__":
    raise SystemExit(main())
