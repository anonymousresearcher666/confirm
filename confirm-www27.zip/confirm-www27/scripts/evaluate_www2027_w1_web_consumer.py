"""WWW27 W1: authentic GO/GAF Web KG consumer acceptance experiment.

A source-pinned operator -> untrusted producer -> external full checker ->
separate JSON-IPC consumer, with three deliberately different trust regimes.

Baseline 1: naive producer final verdict (unsafe).
Baseline 2: independently anchored GOLD final decisions; ignores frontiers
            and refutation witnesses (STRONG, unfairly optimistic baseline).
Main:       verifier reconstructs COMPLETE frontier/certificates/decisions
            from trusted operator sources and binds receipt to exact trace.

Actions are simulated Web-URI/GO-CAM annotation-consumption receipts, NOT
a deployed Web service or medically consequential interventions.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import shutil
import statistics
import tempfile
from pathlib import Path
from time import perf_counter

from trustkg.independent_transition_audit import canonical_sha256,trusted_go_snapshot
from evaluate_www2027_p28_real_kg_three_statuses import construct,producer_check
from evaluate_www2027_p24_full_go_real_not_mixed import (
    ROOT,GO,CAPTURE,VERIFY,call,store_jsonl
)
from evaluate_www2027_gaf_not_real_refutations import sha256_file
from www2027_web_consumer_process import MODES

CONSUMER=ROOT/"scripts/www2027_web_consumer_process.py"
SELECTED=[0,1,8,12,16,24,32,40]
CANDIDATE_INDEX=[8]
PROTOCOL="www27_w1_source_pinned_web_consumer_end_to_end_v1"


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=True)


def read_queries(source,indices):
    trusted=[json.loads(line)["query"] for line in
             (source/"queries.jsonl").read_text(encoding="utf-8").splitlines()
             if line.strip()]
    if any(i<0 or i>=len(trusted) for i in indices):
        raise ValueError("operator query index outside pinned manifest")
    return [trusted[i] for i in indices]


def make_candidate_source(work,original):
    candidate=work/"operator_source_T3_rule_candidate"
    candidate.mkdir()
    for name in ("facts.jsonl","schema.json","trusted_rules.jsonl",
                 "queries.jsonl","negatives.jsonl"):
        shutil.copyfile(original/name,candidate/name)
    rules=[json.loads(line) for line in
           (candidate/"trusted_rules.jsonl").read_text(encoding="utf-8").splitlines()
           if line.strip()]
    selected=[x for x in rules if x["rule_id"]=="GO_T3_gocam_cellular_location"]
    if len(selected)!=1 or selected[0].get("status","trusted")!="trusted":
        raise ValueError("the real GO-CAM T3 rule was not operator-curated trusted")
    selected[0]["status"]="candidate"
    store_jsonl(candidate/"trusted_rules.jsonl",rules)
    newpin=canonical_sha256(trusted_go_snapshot(candidate))
    oldpin=canonical_sha256(trusted_go_snapshot(original))
    if newpin==oldpin:
        raise ValueError("trusted-to-candidate rule policy did not change snapshot hash")
    # Crucially, candidate source change is an OPERATOR-authorized
    # counterfactual, NOT arbitrary promotion from producer input.
    return candidate,newpin


def capture(processed,indices,path,timeout):
    run=call(CAPTURE,[
        "--processed",processed,"--source-indices",",".join(map(str,indices)),
        "--max-depth","3","--budget","4000",
        "--max-seconds","35","--output",path,
    ],timeout)
    if run["exit"]!=0 or run["timeout"] or not path.is_file():
        raise ValueError("fresh producer capture failed: "+repr(run))
    obj=json.loads(path.read_text(encoding="utf-8"))
    if (
        obj.get("passed_capture_completeness") is not True
        or obj.get("source_indices")!=indices
        or len(obj.get("runs",[]))!=len(indices)
        or not all(x.get("complete") is True for x in obj["runs"])
    ):
        raise ValueError("producer incomplete or wrong operator query IDs")
    return obj,run


def verifier(work,source,trace_path,indices,tag,timeout):
    out=work/(tag+"_trusted_verifier.json")
    task=call(VERIFY,[
        "--input",trace_path,"--processed",source,
        "--source-indices",",".join(map(str,indices)),
        "--max-depth","3","--max-events","100000",
        "--output",out,
    ],timeout)
    if task["timeout"] or task["exit"]==124 or not out.is_file():
        raise ValueError("independent verifier timed out or wrote no structured outcome "+tag)
    obj=json.loads(out.read_text(encoding="utf-8"))
    if (
        obj.get("trusted_snapshot_sha256")!=canonical_sha256(trusted_go_snapshot(source))
        or obj.get("source_indices")!=indices
    ):
        raise ValueError("independent verifier did not use correct pinned operator source/queries")
    if task["exit"]==0 and obj.get("passed") is not True:
        raise ValueError("checker returned zero but no accepted verdict")
    if task["exit"]!=0 and (obj.get("passed") is not False or not obj.get("failures")):
        raise ValueError("checker rejection lacks structured failure: "+tag)
    # The operator exclusively issues this receipt after independent
    # verifier execution, on a file not controlled by the producer.
    obj["operator_trace_sha256"]=sha256_file(trace_path)
    obj["operator_verified_process_exit"]=task["exit"]
    out.write_text(json.dumps(obj,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    return obj,out,task


def make_attack(original,name,mutator,work):
    trace=copy.deepcopy(original)
    mutator(trace)
    if trace==original:raise ValueError("mutator did not change honest producer trace "+name)
    out=work/(name+"_untrusted_producer.json")
    out.write_text(canonical(trace)+"\n",encoding="utf-8")
    return out


def cases_for_authentic_batch(tr):
    query=tr["queries"]
    return [
        ("forge_unknown_as_proven",
         lambda x:x["runs"][6].__setitem__(
             "decision_summary",[[query[6]["query"],"PROVEN",1,0]])),
        ("forge_original_GAF_NOT_as_proven",
         lambda x:x["runs"][4].__setitem__(
             "decision_summary",[[query[4]["query"],"PROVEN",1,0]])),
        ("delete_go_cam_frontier_event",
         lambda x:x["queries"][2]["events"].pop(0)),
        ("forge_original_GAF_qualification",
         lambda x:x["runs"][4]["refutation_witness"]["claim"]["args"].__setitem__(
             1,"attacker_relabelled_relation")),
        ("remove_original_GAF_refutation_witness",
         lambda x:x["runs"][4].pop("refutation_witness")),
        ("forge_producer_trusted_source_pin",
         lambda x:x.__setitem__("producer_snapshot_sha256","0"*64)),
        ("forge_producer_query_selection",
         lambda x:x["source_indices"].__setitem__(0,999999)),
        ("inflate_GO_CAM_T4_proof_count",
         lambda x:x["runs"][3]["decision_summary"][0].__setitem__(2,999)),
    ]


def read_statuses(trace,expected):
    got=[]
    for row in trace["runs"]:
        d=row["decision_summary"]
        if not d:got.append("UNKNOWN")
        elif len(d)==1:got.append(d[0][1])
        else:raise ValueError("ambiguous producer decision list")
    if got!=expected:
        raise ValueError("real producer did not emit intended source-grounded outcomes: "+repr(got))
    return got


def write_case(work,items,name,fixture_id,trace_path,verifier_path,baseline_path,kind):
    items.append({
        "name":name,"fixture_id":fixture_id,"scenario_kind":kind,
        "producer_untrusted_path":str(trace_path),
        "operator_verifier_report_path":str(verifier_path),
        "operator_baseline_report_path":str(baseline_path),
    })


def invoke_consumer(work,plan,mode,timeout):
    output=work/("consumer_"+mode+".json")
    process=call(CONSUMER,[
        "--operator-plan",plan,"--mode",mode,"--output",output,
    ],timeout)
    if process["timeout"] or process["exit"]!=0 or not output.is_file():
        raise ValueError("separate consumer process failed "+mode+": "+repr(process))
    result=json.loads(output.read_text(encoding="utf-8"))
    if result.get("passed") is not True or result.get("mode")!=mode:
        raise ValueError("consumer did not complete "+mode)
    return result,process


def expectations(rows):
    result={x["scenario"]:x for x in rows}
    def chk(name,accepted,allow,refute,abstain,quarantine):
        item=result[name]
        got=(item["report_accepted"],item["authorized"],item["refuted"],
             item["abstained"],item["quarantined"])
        expected=(accepted,allow,refute,abstain,quarantine)
        if got!=expected:
            raise ValueError(name+" consumer effect mismatch "+
                             repr({"actual":got,"expected":expected}))
    return result,chk


def audit_decisions(out_by_mode):
    na,na_check=expectations(out_by_mode["naive_producer_verdict"]["results"])
    an,an_check=expectations(out_by_mode["anchored_final_only"]["results"])
    fu,fu_check=expectations(out_by_mode["full_independent_replay"]["results"])
    for check in (na_check,an_check,fu_check):
        check("genuine_real_GO_GAF",True,4,2,2,0)
        check("genuine_operator_candidate_rule",True,0,0,1,0)
    # Any modified producer decision can fool the trusting action
    # consumer. Strong final-only reference and full checker reject it.
    for attack in ("forge_unknown_as_proven","forge_original_GAF_NOT_as_proven"):
        na_check(attack,True,5,1 if "NOT" in attack else 2,
                 2 if "NOT" in attack else 1,0)
        an_check(attack,False,0,0,0,8)
        fu_check(attack,False,0,0,0,8)
    na_check("forge_candidate_only_proven",True,1,0,0,0)
    an_check("forge_candidate_only_proven",False,0,0,0,1)
    fu_check("forge_candidate_only_proven",False,0,0,0,1)
    # Frontier omissions / altered GAF witness are not caught by
    # a stronger-than-realistic independently anchored FINAL verdict
    # comparison, as long as final claims are unchanged.
    for attack in (
        "delete_go_cam_frontier_event","forge_original_GAF_qualification",
        "remove_original_GAF_refutation_witness",
        "swap_untrusted_producer_after_clean_verification",
    ):
        na_check(attack,True,4,2,2,0)
        an_check(attack,True,4,2,2,0)
        fu_check(attack,False,0,0,0,8)
    for attack in (
        "forge_producer_trusted_source_pin","forge_producer_query_selection",
        "inflate_GO_CAM_T4_proof_count",
    ):
        na_check(attack,True,4,2,2,0)
        an_check(attack,False,0,0,0,8)
        fu_check(attack,False,0,0,0,8)
    # Full result must also refer to the exact forged bytes for all
    # other attack cases: it is not merely an honest-verdict oracle.
    return {
        "naive_accepts_forged_final_status_claims":3,
        "anchored_final_accepts_forged_untrusted_search_evidence":4,
        "full_rejects_all_forged_or_replaced_transcripts":10,
        "benign_main_source_actions_authorized":4,
        "authentic_negative_actions_denied":2,
        "source_nonentailed_actions_abstained":2,
        "real_GO_CAM_candidate_benign_actions_abstained":1,
    }


def experiment(timeout):
    with tempfile.TemporaryDirectory(prefix="www27_web_consumer_end_to_end_") as t:
        work=Path(t)
        source,pin,cohort=construct(work)
        candidate,candidate_pin=make_candidate_source(work,source)
        trusted_main=read_queries(source,SELECTED)
        trusted_candidate=read_queries(candidate,CANDIDATE_INDEX)
        if pin==candidate_pin:
            raise ValueError("two operator trust source versions unexpectedly identical")
        cases=[]
        metrics=[]
        main_path=work/"real_GO_GAF_untrusted_producer.json"
        genuine_main,producer_run=capture(source,SELECTED,main_path,timeout)
        if genuine_main["producer_snapshot_sha256"]!=pin:
            raise ValueError("source pin mismatch at producer")
        read_statuses(genuine_main,
                      ["PROVEN"]*4+["REFUTED"]*2+["UNKNOWN"]*2)
        honest,main_report,verified_time=verifier(
            work,source,main_path,SELECTED,"honest_main",timeout)
        if (honest.get("passed") is not True
            or honest.get("independent_verdict_reconstruction_passed") is not True
            or len(honest.get("independent_verdict_rows",[]))!=len(SELECTED)):
            raise ValueError("genuine source batch did not pass independently")
        write_case(work,cases,"genuine_real_GO_GAF","main",
                   main_path,main_report,main_report,"real_web_KG_mixed")
        metrics.append({
            "case":"genuine_real_GO_GAF",
            "producer_process_wall_seconds":producer_run["seconds"],
            "verifier_process_wall_seconds":verified_time["seconds"],
            "independent_certificates":honest["certificate_count"],
        })
        for name,mutator in cases_for_authentic_batch(genuine_main):
            mutated=make_attack(genuine_main,name,mutator,work)
            report,path,timing=verifier(work,source,mutated,SELECTED,name,timeout)
            if report.get("passed") is not False or timing["exit"] in (0,124):
                raise ValueError("forged producer transcript not structurally rejected "+name)
            write_case(work,cases,name,"main",mutated,path,main_report,
                       "producer_only_adversarial_mutation")
            metrics.append({
                "case":name,"verifier_process_wall_seconds":timing["seconds"],
                "structured_failure_reason":report["failures"][0]["reason"],
            })
        # Actual operator switch of one ORIGINAL source rule from trusted
        # to candidate, never a producer-demanded rule promotion.
        cpath=work/"real_candidate_untrusted_producer.json"
        candidate_trace,cproducer=capture(
            candidate,CANDIDATE_INDEX,cpath,timeout)
        read_statuses(candidate_trace,["HYPOTHESIZED"])
        cverified,cgood,ctiming=verifier(
            work,candidate,cpath,CANDIDATE_INDEX,"honest_candidate",timeout)
        if not cverified.get("passed") or not cverified.get("independent_verdict_reconstruction_passed"):
            raise ValueError("real GO-CAM candidate-only trace independently failed")
        write_case(work,cases,"genuine_operator_candidate_rule","candidate",
                   cpath,cgood,cgood,"candidate_authority_abstention")
        metrics.append({
            "case":"genuine_operator_candidate_rule",
            "producer_process_wall_seconds":cproducer["seconds"],
            "verifier_process_wall_seconds":ctiming["seconds"],
        })
        forged_candidate=make_attack(
            candidate_trace,"forge_candidate_only_proven",
            lambda x:x["runs"][0].__setitem__(
                "decision_summary",[[x["queries"][0]["query"],"PROVEN",1,0]]
            ),work
        )
        cr,cpathreport,ctiming=verifier(
            work,candidate,forged_candidate,CANDIDATE_INDEX,
            "forged_candidate",timeout)
        if cr.get("passed") is not False or ctiming["exit"] in (0,124):
            raise ValueError("candidate-only producer succeeded in forging PROVEN")
        write_case(work,cases,"forge_candidate_only_proven","candidate",
                   forged_candidate,cpathreport,cgood,"untrusted_promotion")
        metrics.append({
            "case":"forge_candidate_only_proven",
            "verifier_process_wall_seconds":ctiming["seconds"],
            "structured_failure_reason":cr["failures"][0]["reason"],
        })
        # TOCTOU: after an authentic verifier has accepted producer
        # bytes, adversary substitutes a different same-source trace.
        # It must NOT be accepted just by copying a previous honest
        # verifier receipt from the externally trusted channel.
        swap=make_attack(
            genuine_main,"swap_untrusted_producer_after_clean_verification",
            lambda x:x["queries"][2]["events"].pop(0),work
        )
        write_case(work,cases,"swap_untrusted_producer_after_clean_verification",
                   "main",swap,main_report,main_report,
                   "post_verification_transcript_substitution")
        contracts={
            "main":{
                "source_sha256":pin,
                "query_manifest_sha256":sha256_file(source/"queries.jsonl"),
                "source_indices":SELECTED,
                "queries":trusted_main,
            },
            "candidate":{
                "source_sha256":candidate_pin,
                "query_manifest_sha256":sha256_file(candidate/"queries.jsonl"),
                "source_indices":CANDIDATE_INDEX,
                "queries":trusted_candidate,
            }
        }
        operator_plan=work/"operator_issued_trust_and_query_contract.json"
        operator_plan.write_text(
            json.dumps({"operator_trusted_contracts":contracts,
                        "scenarios":cases},indent=2)+"\n",
            encoding="utf-8")
        consumer_results={}
        for mode in sorted(MODES):
            result,time=invoke_consumer(work,operator_plan,mode,timeout)
            if result["request_count"]!=len(cases):
                raise ValueError("consumer ignored or duplicated request")
            consumer_results[mode]=result
            metrics.append({
                "case":"consumer_"+mode,
                "process_wall_seconds":time["seconds"],
                "operator_source_file_hash_checked":True,
            })
        outcome=audit_decisions(consumer_results)
        if len(cases)!=12:
            raise ValueError("expected exact 12 consumer scenarios")
        stripped={}
        for mode,r in consumer_results.items():
            stripped[mode]={
                "consumer_wall_seconds":r["consumer_wall_seconds"],
                "requests":[{
                    "scenario":e["scenario"],"report_accepted":e["report_accepted"],
                    "authorized":e["authorized"],"refuted":e["refuted"],
                    "abstained":e["abstained"],"quarantined":e["quarantined"],
                } for e in r["results"]]
            }
        return {
            "experiment":PROTOCOL,"passed":True,
            "operator_trusted_full_GO_sha256":pin,
            "operator_t3_candidate_source_sha256":candidate_pin,
            "operator_query_manifest_sha256":contracts["main"]["query_manifest_sha256"],
            "genuine_GAF_and_GO_source_cohort":{
                "original_GO_input_sha256":cohort["original_GO_input_sha256"],
                "GAF_human_mouse_source_archives":cohort["original_GAF_archives"],
                "source_query_ids":SELECTED,
                "authentic_positive_GO_T1":2,
                "authentic_positive_GO_CAM_T3_T4":2,
                "authentic_negative_GAF_NOT":2,
                "real_nonentailed_GO_CAM":2,
                "real_GO_CAM_candidate_only":1,
            },
            "consumer_is_separate_OS_process":True,
            "producer_and_independent_verifier_are_separate_OS_processes":True,
            "trusted_verifier_receipts_bound_to_exact_trace_sha256":True,
            "trusted_operator_source_and_query_manifest_are_distinct_from_producer_input":True,
            "consumer_side_effects":"JSON authorization receipts only, no external writes",
            "consumer_requests":len(cases),
            "successful_full_independent_main_query_replays":len(SELECTED),
            "successful_full_independent_candidate_query_replays":len(CANDIDATE_INDEX),
            "source_real_candidate_avoids_automatic_trust_promotion":True,
            "independent_benchmark_attack_checks":9,
            "producer_only_substitution_checks":1,
            "scenario_disposition":stripped,
            "scientific_checks":outcome,
            "separate_process_timings":metrics,
            "limitations":[
                "This is a reproducible real GO/GO-CAM/GAF linked-data action-consumer demonstration over JSON IPC on the same trusted host, NOT a deployed public Web API, hostile-process sandbox or cryptographic signed provenance.",
                "The operator and its verifier-result channel are trusted; a privileged attacker with write access to operator contracts or verifier receipts is out of scope.",
                "Source-authentic positive results express finite-Horn consequences; GAF NOT is relation-qualified, not OWL/general biological negation. UNKNOWN is nonentailment, not falsehood.",
                "The independently anchored final-only baseline is deliberately strong: it compares against an externally preverified honest transcript's terminal decisions, a reference usually unavailable for a new Web query. It intentionally does not inspect search frontiers or direct-negative witnesses.",
                "All untrusted producer attacks are controlled transcript manipulations, NOT independently labelled real malicious Web KG feeds or resolved schema-consistent poisoning.",
                "The customer actions are synthetic local authorization receipts; no clinical side effect, Web agent deployment, signed third-party source validation or measured human utility is implied.",
                "A single corrupted eight-query producer batch is quarantined as a whole, so authorized benign requests in the same batch are also blocked; this is intentionally fail-closed and exposes an availability/utility tradeoff.",
                "The T3 candidate scenario uses an operator-authorized trust-status downgrade of the genuine source rule. It is not an independently vetted mined-rule promotion.",
                "Timing is for the local OS processes in this controlled experiment; don't infer production multi-host end-to-end latency or outperforming Souffle/Nemo.",
                "The original full GO/GAF sources and all paper .tex files are unchanged.",
            ],
        }


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--timeout",type=int,default=120)
    args=p.parse_args()
    try:
        if args.timeout<60:raise ValueError("timeout must be >=60")
        result=experiment(args.timeout)
    except Exception as err:
        result={
            "experiment":PROTOCOL,"passed":False,
            "blocked_reason":f"{type(err).__name__}: {err}",
        }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",
                           encoding="utf-8")
    print("WWW27_W1 "+json.dumps({
        "passed":result["passed"],
        "consumer_requests":result.get("consumer_requests"),
        "checks":result.get("scientific_checks"),
        "blocked_reason":result.get("blocked_reason"),
    }),flush=True)
    return 0 if result["passed"] else 1

if __name__=="__main__":
    raise SystemExit(main())
