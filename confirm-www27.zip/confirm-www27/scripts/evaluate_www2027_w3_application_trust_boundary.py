"""WWW27 W3: per-request safe consumption vs whole-batch quarantine.

Original authentic GO/GO-CAM/GAF source and pinned manifest from W1.
Fresh independently captured and replayed producer transcript PER QUERY.
Two controlled producer attacks tested as paired policies:
  - FALSE_PROVEN on a genuinely local UNKNOWN answer
  - DELETE_FRONTIER on a genuinely PROVEN GO-CAM answer
The ordinary, independently pinned verifier is unchanged. The SAME
separate consumer process as W1 measures actions. No real-world writes.
No old W1/W2 result, source, or manuscript is modified.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import tempfile
from time import perf_counter

from evaluate_www2027_gaf_not_real_refutations import sha256_file
from evaluate_www2027_p28_real_kg_three_statuses import construct
from evaluate_www2027_w1_web_consumer import (
    ROOT, SELECTED, MODES, capture, verifier, read_queries,
    make_attack, read_statuses, invoke_consumer, write_case
)

OUT=ROOT/"results/www2027/www27_w3_web_application_safe_batch_isolation_v1.json"
PROTOCOL="www27_w3_real_web_kg_safe_consumer_query_isolation_v1"
EXPECTED=["PROVEN"]*4+["REFUTED"]*2+["UNKNOWN"]*2
CASES={
    "forged_unknown_proven":{"position":6,"attack":"false_status"},
    "deleted_proven_frontier":{"position":2,"attack":"remove_frontier"},
}


def mutate_trace(obj,attack):
    if attack=="false_status":
        if obj["runs"][0]["decision_summary"]:
            raise ValueError("attack was not applied to genuine UNKNOWN")
        obj["runs"][0]["decision_summary"]=[
            [obj["queries"][0]["query"],"PROVEN",1,0]
        ]
    elif attack=="remove_frontier":
        decisions=obj["runs"][0]["decision_summary"]
        if not decisions or decisions[0][1]!="PROVEN":
            raise ValueError("frontier attack not against source-PROVEN query")
        events=obj["queries"][0].get("events",[])
        if not events:raise ValueError("cannot remove an absent authentic event")
        events.pop(0)
    else:
        raise ValueError("unregistered attack type")


def build_operator_contract(pin,manifest,source,indices):
    return {
        "source_sha256":pin,
        "query_manifest_sha256":manifest,
        "source_indices":list(indices),
        "queries":read_queries(source,indices),
    }


def summarize_consumption(results,name,kind):
    """Summarize actual outcomes of independent CONSUMER subprocess."""
    by_mode={}
    for mode,r in results.items():
        row=next(x for x in r["results"] if x["scenario"]==name)
        by_mode[mode]={
            "authorized":row["authorized"],
            "refuted":row["refuted"],
            "abstained":row["abstained"],
            "quarantined":row["quarantined"],
            "report_accepted":row["report_accepted"],
            "actions":row["actions"],
        }
    return {"scenario":name,"kind":kind,"modes":by_mode}


def verify_single_result(result,expected_status,index):
    if not (result.get("passed") is True
            and result.get("independent_verdict_reconstruction_passed") is True
            and result.get("source_indices")==[index]
            and not result.get("failures")):
        raise ValueError("independently reconstructed single-query result absent")
    rows=result.get("independent_verdict_rows",[])
    if len(rows)!=1 or rows[0].get("source_index")!=index:
        raise ValueError("independent verifier query provenance mismatch")
    verdict=rows[0].get("verdicts",[])
    status="UNKNOWN" if not verdict else verdict[0][1]
    if status!=expected_status:
        raise ValueError(f"genuine source query {index} status {status} != {expected_status}")


def evaluate(timeout):
    begin=perf_counter()
    with tempfile.TemporaryDirectory(prefix="www27_W3_Web_Trust_Boundary_") as t:
        work=Path(t)
        source,pin,cohort=construct(work)
        manifest=sha256_file(source/"queries.jsonl")
        trusted_queries=read_queries(source,SELECTED)
        # ONE fresh independent full batch, plus one fresh producer per
        # original operator query. No transcript fragments or proof borrowing.
        batch_trace_file=work/"genuine_full_batch.json"
        batch_trace,batch_capture=capture(source,SELECTED,batch_trace_file,timeout)
        read_statuses(batch_trace,EXPECTED)
        honest_batch,batch_reference,batch_verification=verifier(
            work,source,batch_trace_file,SELECTED,"honest_batch",timeout)
        if not honest_batch.get("passed"):
            raise ValueError("full original batch did not pass actual checker")
        contracts={"batch":build_operator_contract(
            pin,manifest,source,SELECTED)}
        fresh={}
        capture_stats=[{"label":"full_honest_batch",
                        "source_indices":SELECTED,
                        "capture_seconds":batch_capture["seconds"],
                        "checker_seconds":batch_verification["seconds"]}]
        # Pin and audit eight SEPARATE, fresh producer processes and
        # eight separate checker processes, prior to any mutation.
        for pos,idx in enumerate(SELECTED):
            name=f"query_{pos}"
            path=work/(name+"_fresh_trace.json")
            tr,run=capture(source,[idx],path,timeout)
            read_statuses(tr,[EXPECTED[pos]])
            clean,report,check=verifier(
                work,source,path,[idx],name+"_clean",timeout)
            verify_single_result(clean,EXPECTED[pos],idx)
            if clean.get("trusted_snapshot_sha256")!=pin:
                raise ValueError("individual checker failed source pin")
            fresh[pos]={
                "query_id":idx,"trace":tr,"trace_file":path,
                "verifier_file":report,"capture":run,"checker":check,
            }
            contracts[name]=build_operator_contract(
                pin,manifest,source,[idx])
            capture_stats.append({
                "label":name,"source_indices":[idx],
                "capture_seconds":run["seconds"],
                "checker_seconds":check["seconds"],
            })
            print("WWW27_W3_INDEPENDENT_FRESH",json.dumps({
                "query_index":idx,"position":pos,
                "status":EXPECTED[pos],
                "producer_seconds":run["seconds"],
                "checker_seconds":check["seconds"]
            }),flush=True)

        cases=[]
        attack_timings=[]
        for key,case in CASES.items():
            pos=case["position"]
            kind=case["attack"]
            idx=SELECTED[pos]
            # The *entire* batch contains one mutant, all other original
            # answers as captured in the authentic original batch.
            # Attack same query and mutation kind in separately recaptured
            # ONE-query producer response.
            def mutator(trace):
                single={
                    "runs":[trace["runs"][pos]],
                    "queries":[trace["queries"][pos]]
                }
                mutate_trace(single,kind)
            altered_batch=make_attack(
                batch_trace,key+"_batch",mutator,work)
            reject_batch,failed_batch,bt=verifier(
                work,source,altered_batch,SELECTED,
                key+"_batch_rejected",timeout)
            if (reject_batch.get("passed") is not False
                or not reject_batch.get("failures")):
                raise ValueError("batch attacker trace was not rejected")
            write_case(work,cases,key+"_batch","batch",
                       altered_batch,failed_batch,batch_reference,
                       "one_compromised_full_batch")
            # Per-query procedure: only ONE independently captured
            # single-query response modified, other seven source-pinned
            # individual traces remain pristine and separately verified.
            query= fresh[pos]
            forged_one=make_attack(
                query["trace"],key+"_query_"+str(pos), 
                lambda tr:mutate_trace(tr,kind),work)
            rejection,rjfile,rt=verifier(
                work,source,forged_one,[idx],
                key+"_individual_rejected",timeout)
            if (rejection.get("passed") is not False
                or not rejection.get("failures")):
                raise ValueError("individual attacker trace not rejected")
            attack_timings.append({
                "attack":key,"position":pos,"source_index":idx,
                "batch_rejection_seconds":bt["seconds"],
                "query_rejection_seconds":rt["seconds"],
                "batch_failure_reason":reject_batch["failures"][0]["reason"],
                "individual_failure_reason":rejection["failures"][0]["reason"]
            })
            for p,original_id in enumerate(SELECTED):
                original=fresh[p]
                qname=f"query_{p}"
                name=key+"_isolated_"+str(p)
                is_bad=(p==pos)
                write_case(
                    work,cases,name,qname,
                    forged_one if is_bad else original["trace_file"],
                    rjfile if is_bad else original["verifier_file"],
                    original["verifier_file"],
                    "fresh_verified_per_query_or_one_forged"
                )
        plan=work/"operator_pinned_W3_web_consumer_plan.json"
        plan.write_text(json.dumps({
            "operator_trusted_contracts":contracts,
            "scenarios":cases,
        },indent=2)+"\n",encoding="utf-8")
        consumers={}
        for mode in sorted(MODES):
            response,process=invoke_consumer(
                work,plan,mode,timeout)
            if response["request_count"]!=len(cases):
                raise ValueError("downstream consumer dropped cases")
            consumers[mode]=response
        summaries={}
        for key,case in CASES.items():
            batch_rows=summarize_consumption(
                consumers,key+"_batch","whole_batch")
            group=[summarize_consumption(
                consumers,key+"_isolated_"+str(p),"independent_query")
                for p in range(len(SELECTED))]
            aggregated={}
            for mode in sorted(MODES):
                b=batch_rows["modes"][mode]
                agg={k:sum(x["modes"][mode][k] for x in group)
                     for k in ("authorized","refuted","abstained",
                               "quarantined")}
                aggregated[mode]={
                    "whole_batch":{k:b[k] for k in agg},
                    "independently_replayed_individuals":agg,
                    "attacked_query_authorized":(
                        group[case["position"]]["modes"][mode]["authorized"]>0
                    ),
                }
            full=aggregated["full_independent_replay"]
            # Exact, source-grounded paired utility expectations.
            expected_benign=4-int(EXPECTED[case["position"]]=="PROVEN")
            if (full["whole_batch"]["authorized"]!=0
                or full["whole_batch"]["quarantined"]!=8
                or full["independently_replayed_individuals"]["authorized"]
                    !=expected_benign
                or full["independently_replayed_individuals"]["quarantined"]!=1
                or full["attacked_query_authorized"]):
                raise ValueError("W3 unsafe action or expected isolation failed: "+key)
            # A naive consumer must be vulnerable to a forged UNKNOWN status.
            if key=="forged_unknown_proven":
                if not aggregated["naive_producer_verdict"]["attacked_query_authorized"]:
                    raise ValueError("naive consumer did not exhibit controlled unsafe promotion")
                if aggregated["anchored_final_only"]["attacked_query_authorized"]:
                    raise ValueError("anchored final-only accepted modified terminal decision")
            # A deliberately privileged final-only verifier cannot
            # recognize a deleted frontier event when terminal answer
            # remains identical.
            if key=="deleted_proven_frontier":
                if not aggregated["anchored_final_only"]["attacked_query_authorized"]:
                    raise ValueError("strong final-only baseline should miss frontier deletion")
            summaries[key]={
                "target_source_query_index":SELECTED[case["position"]],
                "target_clean_status":EXPECTED[case["position"]],
                "attack_kind":case["attack"],
                "paired_operator_query_ids":SELECTED,
                "full_independent_mitigations":full,
                "consumer_policy_comparison":aggregated,
                "correct_authorizations_recovered_vs_batch":
                    expected_benign,
                "fresh_individual_producer_captures_reused_across_cases":True,
            }
            print("WWW27_W3_APPLICATION_RESULT",json.dumps({
                "attack":key,"recovered_actions":expected_benign,
                "full_independent_false_authorizations":int(
                    full["attacked_query_authorized"]),
                "whole_batch_quarantines":full["whole_batch"]["quarantined"],
                "per_query_quarantines":full[
                    "independently_replayed_individuals"]["quarantined"]
            }),flush=True)
        result={
            "experiment":PROTOCOL,"passed":True,
            "application_focus":"trusted downstream Web-KG action boundary, not new logical calculus",
            "operator_source_sha256":pin,
            "operator_query_manifest_sha256":manifest,
            "original_source":cohort,
            "original_operator_query_indices":SELECTED,
            "clean_query_statuses":EXPECTED,
            "actual_fresh_producer_captures":len(SELECTED)+1,
            "distinct_operator_ground_queries":len(SELECTED),
            "fresh_single_query_verifier_replays":len(SELECTED),
            "separate_attacker_verifier_rejections":2*len(CASES),
            "reused_clean_query_evidence_in_second_case":True,
            "consumer_is_separate_OS_process":True,
            "consumer_scenarios":len(cases),
            "consumer_modes":sorted(MODES),
            "attacks":summaries,
            "fresh_producer_and_checker_timings":capture_stats,
            "forgery_rejection_timings":attack_timings,
            "total_protocol_wall_seconds":round(perf_counter()-begin,5),
            "measured_paired_proven_authorizations_recovered":
                sum(x["correct_authorizations_recovered_vs_batch"]
                    for x in summaries.values()),
            "attack_scenarios":len(CASES),
            "true_side_effects":"JSON authorization receipts only; no external actions",
            "important_limits":[
                "No public Web app deployment; OS subprocesses and local JSON receipts on one trusted host.",
                "One original eight-query cohort; only two controlled mutations; not representative Web-wide or independent events.",
                "One fresh honest full batch and eight fresh per-query captures. Clean per-query checks REUSED in two attack comparisons.",
                "Oracle-quality final-only baseline derives from separately verified clean traces; not available to ordinary live consumer.",
                "Per-query verification requires independent complete producer execution and independent source-pinned replay, not slicing an untrusted batch.",
                "A producer/host controlling privileged operator source, pinned query contract or verifier receipt remains out of threat model.",
                "Original GAF NOT is qualified evidence; operational UNKNOWN is neither falsehood nor biological denial.",
                "Tampered positive frontier can produce an authorization for an originally PROVEN claim but unverified transcript: count as compromised evidence integrity.",
                "Measurements are single paired source-manifest cohorts; latency is NOT a population tail latency or randomized clinical utility.",
                "Prior source, W1/W2/R1/R2/S1/J1/J2 experiment reports, and ALL manuscript LaTeX are unchanged."
            ],
        }
        return result


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output",type=Path,default=OUT)
    p.add_argument("--timeout",type=int,default=180)
    args=p.parse_args()
    try:
        if not 90<=args.timeout<=900:
            raise ValueError("timeout must be 90-900 seconds")
        result=evaluate(args.timeout)
    except Exception as exc:
        result={"experiment":PROTOCOL,"passed":False,
                "blocked_reason":type(exc).__name__+": "+str(exc)}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(
        result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("WWW27_W3_FINAL",json.dumps({
        "passed":result["passed"],
        "paired_benign_authorizations_recovered":
            result.get("measured_paired_proven_authorizations_recovered"),
        "blocked_reason":result.get("blocked_reason")
    }),flush=True)
    return 0 if result["passed"] else 1


if __name__=="__main__":
    raise SystemExit(main())
