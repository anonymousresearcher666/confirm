"""W4: amortized INDEPENDENT replay for safely isolated Web KG requests.

Primary question: can the source/operator-pinned warm session preserve W3's
application ACTION safety while avoiding repeated cold index initialization?
Real GO/GO-CAM/GAF inputs; eight FRESH producer captures; no toy source
in measured workload; no .tex or earlier result changes.

Warm verifier runs as a SEPARATE OS process with trusted source and query
manifest; loads/indexes trusted KG only once, but independently reconstructs
complete search & verdict for EACH clean/mutant transcript, producing per-
request operator-only receipts pinned to exact trace bytes. The separate
W1 consumer policy evaluates all receipts, not a simulation of decisions.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from time import perf_counter

from trustkg.independent_transition_audit import (
    TrustedGOIndex,canonical_sha256,trusted_go_snapshot
)
from evaluate_www2027_p25_pinned_verifier_session import verify_one,trusted_query_list
from evaluate_www2027_w1_web_consumer import (
    ROOT,SELECTED,MODES,capture,verifier,read_queries,read_statuses,
    invoke_consumer,write_case
)
from evaluate_www2027_p28_real_kg_three_statuses import construct
from evaluate_www2027_gaf_not_real_refutations import sha256_file
from evaluate_www2027_w3_application_trust_boundary import (
    EXPECTED,mutate_trace,build_operator_contract
)

OUT=ROOT/"results/www2027/www27_w4_warm_checker_web_application_boundary_v2.json"
PROTOCOL="www27_w4_source_pinned_warm_checker_safe_web_consumer_v2"
ATTACKS={
    "unknown_falsely_proven":{"position":6,"kind":"false_status"},
    "proven_frontier_event_removed":{"position":2,"kind":"remove_frontier"},
    "proven_source_pin_spoofed":{"position":3,"kind":"source_pin"},
}


def no_reused_decision(tr,kind):
    """Alter a fresh genuine single-query producer output, not trusted EDB."""
    altered=copy.deepcopy(tr)
    if kind=="source_pin":
        old=altered["producer_snapshot_sha256"]
        if old=="0"*64:raise ValueError("source pin already zero")
        altered["producer_snapshot_sha256"]="0"*64
    else:
        mutate_trace(altered,kind)
    if altered==tr:raise ValueError("attack changed no evidence")
    return altered


def save_json(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n",
                    encoding="utf-8")


def sha_bytes(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()


def warm_worker(source,pin,manifest,out):
    """A separate independent verifier process, never a producer callback."""
    start=perf_counter()
    step=perf_counter()
    frozen=trusted_go_snapshot(source)
    fresh_pin=canonical_sha256(frozen)
    load=perf_counter()-step
    if fresh_pin!=pin:
        raise ValueError("operator source pin does not match warm loaded input")
    step=perf_counter()
    index=TrustedGOIndex(frozen)
    prepared=perf_counter()-step
    tasks=json.loads(manifest.read_text(encoding="utf-8"))
    if not isinstance(tasks,list) or len(tasks)!=11:
        raise ValueError("warm manifest must specify 8 clean + 3 attacked requests")
    records=[]
    for req in tasks:
        idx=req["query_id"]
        if type(idx) is not int or idx<0:raise ValueError("bad operator query ID")
        trace_path=Path(req["trace_file"])
        receipt=Path(req["receipt_file"])
        expected_queries=trusted_query_list(source,[idx])
        begin=perf_counter()
        loaded=json.loads(trace_path.read_text(encoding="utf-8"))
        judgment=verify_one(loaded,expected_queries,index,pin,[idx],3)
        # This receipt is written by the trusted verifier on an operator-owned
        # destination; producer never supplies or modifies its contents.
        report={
            "passed":judgment["passed"],
            "independent_verdict_reconstruction_passed":judgment["passed"],
            "trusted_snapshot_sha256":pin,
            "source_indices":[idx],
            "independent_verdict_rows":judgment.get("independent_verdict_rows") or [],
            "certificate_count":judgment.get("certificate_count"),
            "failures":judgment.get("failures") or [],
            "operator_trace_sha256":sha_bytes(trace_path),
            "operator_verified_process_exit":0 if judgment["passed"] else 1,
        }
        save_json(receipt,report)
        elapsed=perf_counter()-begin
        accepted=judgment["passed"] is True
        if accepted!=req["expect_accept"]:
            raise ValueError("warm verifier did not match expected honest/tamper evidence: "+req["name"])
        if not accepted and not report["failures"]:
            raise ValueError("warm verifier failed without structured denial")
        records.append({
            "name":req["name"],"source_query_id":idx,
            "expect_accept":req["expect_accept"],
            "observed_accept":accepted,
            "failure_reason":report["failures"][0]["reason"] if report["failures"] else None,
            "full_replay_wall_seconds":round(elapsed,6),
            "transition_replay_seconds":judgment.get("transition_replay_seconds"),
            "certificate_count":judgment.get("certificate_count"),
            "verified_raw_trace_bytes":trace_path.stat().st_size,
            "receipt_trace_digest":report["operator_trace_sha256"],
        })
    summary={
        "passed":True,"operator_source_sha256":fresh_pin,
        "source_loaded_once":True,"index_built_once":True,
        "every_frontier_and_verdict_replayed":True,
        "snapshot_load_seconds":round(load,6),
        "index_prepare_seconds":round(prepared,6),
        "full_replay_requests":len(records),
        "clean_acceptances":sum(x["observed_accept"] for x in records),
        "structured_attacker_rejections":sum(not x["observed_accept"] for x in records),
        "requests":records,
        "entire_warm_worker_inside_process_seconds":round(perf_counter()-start,6),
    }
    save_json(out,summary)
    return summary


def warm_os_process(source,pin,manifest,output,timeout):
    command=[
        sys.executable,str(Path(__file__).resolve()),"--worker",
        "--processed",str(source),"--pin",pin,
        "--manifest",str(manifest),"--output",str(output)
    ]
    start=perf_counter()
    try:
        r=subprocess.run(
            command, cwd=ROOT, capture_output=True,text=True,
            timeout=timeout,env={
                **os.environ,"PYTHONPATH":
                str(ROOT/"src")+os.pathsep+str(ROOT/"scripts")}
        )
    except subprocess.TimeoutExpired as ex:
        raise ValueError("warm verifier separate process timed out") from ex
    wall=round(perf_counter()-start,6)
    if r.returncode!=0 or not output.is_file():
        raise ValueError("warm independent verifier failed: "+
                         r.stderr[-1300:]+r.stdout[-400:])
    result=json.loads(output.read_text(encoding="utf-8"))
    if not result.get("passed") or result.get("operator_source_sha256")!=pin:
        raise ValueError("warm OS verifier pin or success mismatch")
    return result,wall


def collect_consumer(consumers,key,kind):
    row_by_mode={}
    for mode,r in consumers.items():
        if mode!="full_independent_replay":continue
        rows=[x for x in r["results"] if x["scenario"].startswith(key+"_")]
        if len(rows)!=8:raise ValueError("missing eight consumer query effects for "+key)
        agg={k:sum(x[k] for x in rows)
             for k in ("authorized","refuted","abstained","quarantined")}
        bad=[x for x in rows if x["scenario"]==key+"_q"+str(ATTACKS[kind]["position"])]
        if len(bad)!=1:raise ValueError("attacked query not found in consumer outputs")
        agg["attacked_query_quarantined"]=bad[0]["quarantined"]==1
        agg["attacked_query_authorized"]=bad[0]["authorized"]>0
        row_by_mode[mode]=agg
    return row_by_mode["full_independent_replay"]


def bound_attack_source_index(config, recorded, operator_indices):
    """Bind application report to the ORIGINAL operator query ID."""
    position=config["position"]
    original_id=operator_indices[position]
    if recorded.get("source_index")!=original_id:
        raise ValueError("W4 selected attack source index differs from pinned operator query")
    return original_id


def experiment(timeout):
    started=perf_counter()
    with tempfile.TemporaryDirectory(prefix="www27_W4_Web_Checker_Session_") as temp:
        work=Path(temp)
        original,pin,cohort=construct(work)
        query_manifest_hash=sha256_file(original/"queries.jsonl")
        captures={}
        cold_rows=[]
        requests=[]
        per_query=[]
        # Capture and CHECK all eight ORIGINAL operator queries with
        # independent producer and checker OS processes, not slices.
        for pos,idx in enumerate(SELECTED):
            trace_path=work/f"fresh_query_{pos}.json"
            tr,prod=capture(original,[idx],trace_path,timeout)
            read_statuses(tr,[EXPECTED[pos]])
            cold,receipt,cproc=verifier(
                work,original,trace_path,[idx],f"cold_fresh_q{pos}",timeout)
            if not (cold.get("passed") is True and
                    cold.get("independent_verdict_reconstruction_passed") is True):
                raise ValueError("cold replay failed on true query "+str(idx))
            if cold.get("trusted_snapshot_sha256")!=pin:
                raise ValueError("cold source pin mismatch")
            captures[pos]={"trace":tr,"path":trace_path,
                           "cold_receipt":receipt}
            per_query.append({
                "source_index":idx,"original_status":EXPECTED[pos],
                "fresh_producer_process_seconds":prod["seconds"],
                "cold_verifier_process_seconds":cproc["seconds"]
            })
            cold_rows.append({
                "name":f"fresh_q{pos}","verified":True,"source_index":idx,
                "whole_process_seconds":cproc["seconds"],
                "failure_reason":None
            })
            requests.append({
                "name":f"fresh_q{pos}","query_id":idx,
                "trace_file":str(trace_path),"expect_accept":True,
                "receipt_file":str(work/f"warm_receipt_clean_{pos}.json")
            })
            print("WWW27_W4_SOURCE",json.dumps({
                "index":idx,"status":EXPECTED[pos],
                "cold_seconds":cproc["seconds"]
            }),flush=True)
        attacks={}
        for key,meta in ATTACKS.items():
            pos=meta["position"]
            idx=SELECTED[pos]
            altered=no_reused_decision(captures[pos]["trace"],meta["kind"])
            file=work/(key+"_untrusted.json")
            save_json(file,altered)
            cold_result,cold_receipt,cproc=verifier(
                work,original,file,[idx],key+"_cold_attack",timeout)
            if (cold_result.get("passed") is not False
                or not cold_result.get("failures")
                or cproc["exit"] in (0,124) or cproc["timeout"]):
                raise ValueError("cold verifier failed to structurally reject "+key)
            attacks[key]={
                "position":pos,"source_index":idx,
                "forged_trace":file,"cold_receipt":cold_receipt,
                "cold_rejection_reason":cold_result["failures"][0]["reason"]
            }
            cold_rows.append({
                "name":key,"verified":False,"source_index":idx,
                "whole_process_seconds":cproc["seconds"],
                "failure_reason":cold_result["failures"][0]["reason"]
            })
            requests.append({
                "name":key,"query_id":idx,"trace_file":str(file),
                "expect_accept":False,
                "receipt_file":str(work/(key+"_warm_rejection.json"))
            })
        manifest=work/"operator_issued_verification_manifest.json"
        save_json(manifest,requests)
        warm,whole_warm_wall=warm_os_process(
            original,pin,manifest,work/"warm_worker_report.json",timeout)
        record={x["name"]:x for x in warm["requests"]}
        # Comparison requires SAME exact bytes, source pin, query
        # IDs and acceptance for every cold/warm request.
        for cold in cold_rows:
            z=record[cold["name"]]
            if (z["observed_accept"]!=cold["verified"] or
                z["source_query_id"]!=cold["source_index"] or
                z["failure_reason"]!=cold["failure_reason"]):
                raise ValueError("cold/warm independent replay difference: "+cold["name"])
        # In addition to checker parity, invoke the EXACT separate W1
        # downstream action consumer on cold and warm receipts.
        contracts={}
        scenarios=[]
        for pos,idx in enumerate(SELECTED):
            contracts[f"q{pos}"]={
                "source_sha256":pin,
                "query_manifest_sha256":query_manifest_hash,
                "source_indices":[idx],
                "queries":read_queries(original,[idx]),
            }
        for key,meta in ATTACKS.items():
            bad_pos=meta["position"]
            for pos,idx in enumerate(SELECTED):
                attacked=pos==bad_pos
                trace=attacks[key]["forged_trace"] if attacked else captures[pos]["path"]
                cold_receipt=(attacks[key]["cold_receipt"] if attacked
                              else captures[pos]["cold_receipt"])
                warm_receipt=(work/(key+"_warm_rejection.json") if attacked
                              else work/f"warm_receipt_clean_{pos}.json")
                for lifecycle,path in (("cold",cold_receipt),("warm",warm_receipt)):
                    write_case(
                        work,scenarios,
                        lifecycle+"_"+key+"_q"+str(pos),
                        f"q{pos}",trace,path,cold_receipt,
                        "operator_verified_per_query_"+lifecycle
                    )
        plan=work/"operator_pinned_consumer_workflow.json"
        save_json(plan,{"operator_trusted_contracts":contracts,
                        "scenarios":scenarios})
        # Only independent replay is needed to compare session lifecycle.
        consumer,consumer_proc=invoke_consumer(
            work,plan,"full_independent_replay",timeout)
        if consumer["request_count"]!=len(scenarios):
            raise ValueError("consumer did not process cold+warm scenario manifest")
        views={}
        for key,attack in ATTACKS.items():
            cold=collect_consumer(
                {"full_independent_replay":consumer},"cold_"+key,key)
            hot=collect_consumer(
                {"full_independent_replay":consumer},"warm_"+key,key)
            clean_valid=4-int(EXPECTED[attack["position"]]=="PROVEN")
            for x in (cold,hot):
                if (x["authorized"]!=clean_valid or
                    x["quarantined"]!=1 or
                    not x["attacked_query_quarantined"] or
                    x["attacked_query_authorized"]):
                    raise ValueError("W4 consumer authorization or isolation failed "+key)
            if cold!=hot:
                raise ValueError("warm lifecycle changed downstream consumer effects "+key)
            views[key]={
                "attacked_operator_query_id":bound_attack_source_index(attack,attacks[key],SELECTED),
                "original_status":EXPECTED[attack["position"]],
                "cold_and_warm_consumer_effects_match":True,
                "safety_utility_by_lifecycle":{"cold":cold,"warm":hot},
                "benign_authorizations_recovered_against_whole_batch":clean_valid
            }
        cold_seconds=sum(r["whole_process_seconds"] for r in cold_rows)
        clean_cold=sum(r["whole_process_seconds"] for r in cold_rows
                       if r["verified"])
        clean_warm=sum(r["full_replay_wall_seconds"] for r in warm["requests"]
                       if r["observed_accept"])
        report={
            "experiment":PROTOCOL,"passed":True,
            "thesis":"ConFIRM establishes an independently verifiable trust boundary between untrusted Web knowledge-graph reasoning services and downstream semantic applications.",
            "source_sha256":pin,
            "trusted_query_manifest_sha256":query_manifest_hash,
            "original_web_source_cohort":cohort,
            "genuine_fresh_producer_captures":len(captures),
            "distinct_original_queries":len(SELECTED),
            "same_11_requests_run_under_both_lifecycles":True,
            "warm_index_reused_without_verdict_reuse":True,
            "all_honest_replays_complete":True,
            "original_query_indices":SELECTED,
            "cold_requests":cold_rows,
            "warm_worker":warm,
            "application_consumer_comparison":views,
            "total_clean_authorizations_across_paired_scenarios":
                sum(v["benign_authorizations_recovered_against_whole_batch"]
                    for v in views.values()),
            "attack_count":len(ATTACKS),
            "actual_attacks_rejected_in_each_lifecycle":len(ATTACKS),
            "cold_verifier_all_11_whole_process_seconds":round(cold_seconds,6),
            "warm_verifier_all_11_whole_process_seconds":whole_warm_wall,
            "cold_verifier_clean_8_whole_process_seconds":round(clean_cold,6),
            "warm_clean_8_replay_only_seconds_excludes_init":round(clean_warm,6),
            "matched_verifier_amortization_factor":
                round(cold_seconds/whole_warm_wall,5) if whole_warm_wall else None,
            "fresh_producer_process_seconds_total":
                round(sum(q["fresh_producer_process_seconds"] for q in per_query),6),
            "consumer_process_seconds":consumer_proc["seconds"],
            "entire_experiment_seconds":round(perf_counter()-started,6),
            "important_limits":[
                "One authentic GO/GO-CAM/GAF cohort of 8 source-grounded queries and three controlled trace mutations; no statistical population inference.",
                "Producer/checker/consumer separate OS processes but still ONE trusted host; no public Web deployment or independent publisher authentication.",
                "Per-query producer and cold verifier captured once each; exact identical traces are processed by same-source warm verifier (paired measurement, not multiple independent KG trials).",
                "Cold per-query verifier processes reload identical original source and rebuild indices; warm verifier uses one source snapshot/index but independently replays every full frontier and verdict.",
                "All latency comparisons include 8 clean and 3 invalid verification requests in BOTH modes. Warm includes initialization and OS startup.",
                "Report cold/warm verifier timings only; fresh producer/consumer process costs are separately provided. Not an end-to-end full distributed Web latency.",
                "Queries that are REFUTED use authentic GAF relation-qualified NOT; local UNKNOWN is not a biological falsehood.",
                "A poisoned but source-consistent trusted operator snapshot, compromised operator/host secret, and general semantic misinterpretation are out of scope.",
                "Clean traces are REUSED across three attack scenarios in the consumer comparison; recovered actions are repeated observations, not 10 independent actions.",
                "W1/W2/W3 results, original Web KG source files and every LaTeX file remain unchanged."
            ],
        }
        return report


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--worker",action="store_true")
    p.add_argument("--processed",type=Path)
    p.add_argument("--pin")
    p.add_argument("--manifest",type=Path)
    p.add_argument("--timeout",type=int,default=180)
    p.add_argument("--output",type=Path,default=OUT)
    args=p.parse_args()
    try:
        if args.worker:
            if not args.processed or not args.pin or not args.manifest:
                raise ValueError("trusted warm source pin, manifest and path required")
            result=warm_worker(args.processed,args.pin,args.manifest,args.output)
        else:
            if not 90<=args.timeout<=900:raise ValueError("timeout outside 90-900 bounds")
            result=experiment(args.timeout)
    except Exception as exc:
        result={"experiment":PROTOCOL,"passed":False,
                "blocked_reason":type(exc).__name__+": "+str(exc)}
    save_json(args.output,result)
    print("WWW27_W4",json.dumps({
        "passed":result["passed"],
        "amortization":result.get("matched_verifier_amortization_factor"),
        "benign_authorizations":result.get("total_clean_authorizations_across_paired_scenarios"),
        "blocked_reason":result.get("blocked_reason")
    }),flush=True)
    return 0 if result["passed"] else 1


if __name__=="__main__":
    raise SystemExit(main())
