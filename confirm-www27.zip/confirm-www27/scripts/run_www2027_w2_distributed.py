"""W2: real Docker Compose + Toxiproxy GO/GAF distributed verifier experiment.

Source and trust contracts are prepared by the frozen P2.8 source builder;
fresh P2.8-derived producer runs and independently source-pinned audit runs
execute in different Docker containers. Every result is explicitly checked.
"""
from __future__ import annotations
import argparse
import copy
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
import urllib.error
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
COMPOSE=ROOT/"experiments/www27/w2/compose.yaml"
OUTPUT=ROOT/"results/www2027/www27_w2_distributed_faults_v1.json"
IDS=[0,8,16,32]
PORTS={"admin":18474,"producer":18661,"verifier":18662,"consumer":18663}
PROXIES={
    "producer":{"name":"w2_producer","listen":"0.0.0.0:18661","upstream":"producer:8080","enabled":True},
    "verifier":{"name":"w2_verifier","listen":"0.0.0.0:18662","upstream":"verifier:8080","enabled":True},
    "consumer":{"name":"w2_consumer","listen":"0.0.0.0:18663","upstream":"consumer:8080","enabled":True},
}


def api(url,data=None,timeout=10):
    begun=time.perf_counter()
    try:
        body=None if data is None else json.dumps(data,separators=(",",":")).encode()
        req=urllib.request.Request(
            url,data=body,headers={"Content-Type":"application/json"} if body is not None else {}
        )
        with urllib.request.urlopen(req,timeout=timeout) as response:
            payload=response.read(24*1024*1024+1)
            if len(payload)>24*1024*1024:raise ValueError("oversized HTTP response")
            # Toxiproxy POST /reset may return HTTP 204 with an empty body.
            value=json.loads(payload) if payload.strip() else {}
        return value,round(time.perf_counter()-begun,6),None
    except (OSError,ValueError,urllib.error.HTTPError,urllib.error.URLError) as err:
        return None,round(time.perf_counter()-begun,6),type(err).__name__+": "+str(err)[:180]


def url(role,endpoint="work"):
    return f"http://127.0.0.1:{PORTS[role]}/{endpoint}"


def toxic(endpoint,data):
    r,_,error=api(url("admin",endpoint),data)
    if error or r is None:raise RuntimeError("Toxiproxy "+endpoint+": "+str(error))
    return r


def latency(ms):
    toxic("reset",{})
    if ms:
        for role in ("verifier","consumer"):
            for stream in ("upstream","downstream"):
                toxic("proxies/"+PROXIES[role]["name"]+"/toxics",{
                    "name":role+"_"+stream+"_latency",
                    "type":"latency","stream":stream,"toxicity":1,
                    "attributes":{"latency":ms,"jitter":0},
                })


def bandwidth(kbs):
    toxic("reset",{})
    toxic("proxies/w2_verifier/toxics",{
        "name":"verifier_upstream_limit","type":"bandwidth",
        "stream":"upstream","toxicity":1,
        "attributes":{"rate":kbs},
    })


def enable(role,on):
    toxic("proxies/"+PROXIES[role]["name"],{"enabled":on})


def compose(args,env,timeout=420):
    return subprocess.run(
        ["docker","compose","-p",env["W2_PROJECT"],"-f",str(COMPOSE),*args],
        cwd=ROOT,env=env,text=True,capture_output=True,timeout=timeout
    )


def await_services():
    deadline=time.monotonic()+110
    detail=""
    while time.monotonic()<deadline:
        status,_,err=api(url("admin","proxies"),timeout=3)
        if err is None and status is not None:
            try:
                toxic("populate",list(PROXIES.values()))
                checks=[]
                for role in ("producer","verifier","consumer"):
                    answer,_,error=api(url(role,"health"),timeout=3)
                    checks.append(error is None and answer and answer.get("ok") is True)
                if all(checks):return
            except RuntimeError as exc:
                detail=str(exc)
        else:detail=str(err)
        time.sleep(2)
    raise RuntimeError("Docker/Toxiproxy services not ready: "+detail)


def stage_sources(stage):
    from evaluate_www2027_p28_real_kg_three_statuses import construct
    from evaluate_www2027_w1_web_consumer import make_candidate_source
    from trustkg.independent_transition_audit import canonical_sha256,trusted_go_snapshot
    from evaluate_www2027_gaf_not_real_refutations import sha256_file
    build=stage/"build"
    build.mkdir()
    old,pin1,source_meta=construct(build)
    sources=stage/"sources"
    sources.mkdir()
    v1=sources/"v1"
    shutil.move(str(old),str(v1))
    newer,pin2=make_candidate_source(build,v1)
    shutil.move(str(newer),str(sources/"v2"))
    if pin1!=canonical_sha256(trusted_go_snapshot(v1)):
        raise ValueError("original trusted source digest mismatch")
    if pin2!=canonical_sha256(trusted_go_snapshot(sources/"v2")):
        raise ValueError("candidate trusted source digest mismatch")
    allqueries=[json.loads(x)["query"] for x in (v1/"queries.jsonl").read_text().splitlines() if x.strip()]
    subset=[allqueries[i] for i in IDS]
    manifest=sha256_file(v1/"queries.jsonl")
    if manifest!=sha256_file(sources/"v2"/"queries.jsonl"):
        raise ValueError("source rotation changed the trusted query list")
    operator=stage/"operator"
    operator.mkdir()
    (operator/"receipt.key").write_bytes(os.urandom(32))
    os.chmod(operator/"receipt.key",0o600)
    def activate(revision):
        obj={"revision":revision,"source_pin":pin1 if revision=="v1" else pin2,
             "query_manifest_sha256":manifest,"indices":IDS,"queries":subset}
        staged=operator/".pending"
        staged.write_text(json.dumps(obj,sort_keys=True)+"\n")
        os.replace(staged,operator/"active.json")
    activate("v1")
    return {"v1":pin1,"v2":pin2,"query_manifest_sha256":manifest,
            "genuine_source_census":source_meta},activate


def send(role,request,timeout=75):
    return api(url(role),request,timeout=timeout)


def capture(revision):
    answer,wall,error=send("producer",{
        "query_indices":IDS,"producer_version":revision
    },95)
    if error or not answer or not answer.get("ok"):
        raise ValueError("real producer failed "+str(error or answer))
    return answer["trace"],wall,answer["producer_wall_seconds"]


def roundtrip(scenario,trace,expected_authorized,verifier_ok=True,consumer_ok=True):
    nonce=uuid.uuid4().hex
    begun=time.perf_counter()
    verdict,vtime,error=send("verifier",{"trace":trace,"nonce":nonce})
    trusted=error is None and verdict and verdict.get("ok") is True
    if bool(trusted)!=verifier_ok:
        raise ValueError("verifier disagreed on "+scenario+" "+str(error or verdict))
    # A semantic falsification MUST be rejected with a concrete structured
    # full-verifier failure. Transport timeout/crash counts ONLY for
    # the separately designated network partition.
    if not verifier_ok and scenario!="verifier_link_partition":
        if error or not isinstance(verdict,dict) or verdict.get("structured_rejection") is not True:
            raise ValueError("attack counted as rejected without structured checker verdict "+scenario)
    receipt=verdict if trusted else None
    action,ctime,consumer_error=send("consumer",{
        "trace":trace,"nonce":nonce,"signed_verifier_receipt":receipt
    },20)
    if consumer_error or not action or action.get("ok") is not True:
        raise ValueError("consumer did not respond "+scenario+" "+str(consumer_error))
    if (action.get("verified_receipt")!=consumer_ok
        or action.get("authorized")!=expected_authorized
        or (not consumer_ok and action.get("quarantined")!=4)):
        raise ValueError("consumer incorrectly authorized "+scenario+" "+str(action))
    return {
        "scenario":scenario,"full_replay_accepted":bool(trusted),
        "reason":"PASSED" if trusted else str((verdict or {}).get("reason",error)),
        "authorized":action["authorized"],
        "denied_negative":action.get("denied_negative"),
        "abstained":action.get("abstained"),
        "quarantined":action.get("quarantined"),
        "verifier_network_and_execution_seconds":vtime,
        "consumer_network_and_action_seconds":ctime,
        "end_to_end_verification_and_action_seconds":round(time.perf_counter()-begun,6),
    }


def forge(trace,kind):
    item=copy.deepcopy(trace)
    if kind=="forged_UNKNOWN_as_PROVEN":
        q=item["queries"][3]["query"]
        item["runs"][3]["decision_summary"]=[[q,"PROVEN",1,0]]
    elif kind=="forged_GAF_NOT_as_PROVEN":
        q=item["queries"][2]["query"]
        item["runs"][2]["decision_summary"]=[[q,"PROVEN",1,0]]
    elif kind=="removed_real_frontier_event":
        item["queries"][1]["events"].pop(0)
    elif kind=="forged_GAF_not_witness":
        item["runs"][2]["refutation_witness"]["reason"]="attacker_edit"
    elif kind=="forged_source_pin":
        item["producer_snapshot_sha256"]="0"*64
    elif kind=="forged_candidate_PROVEN":
        q=item["queries"][1]["query"]
        item["runs"][1]["decision_summary"]=[[q,"PROVEN",1,0]]
    else:raise ValueError("unsupported attack "+kind)
    if item==trace:raise ValueError("ineffective malicious trace mutation")
    return item


def metric_percentile(values,p):
    if not values:return None
    ordered=sorted(values)
    k=(len(ordered)-1)*p/100
    low=int(k)
    high=min(low+1,len(ordered)-1)
    return round(ordered[low]*(1-(k-low))+ordered[high]*(k-low),6)


def campaign(repetitions):
    if not 2<=repetitions<=6:raise ValueError("repetitions must be 2-6")
    # SECURITY: staging MUST be OUTSIDE the repository root, because the
    # producer mounts the complete repository at /app:ro. Otherwise the
    # producer can read /app/.w2_runtime/.../operator/receipt.key even
    # without an explicit /operator bind mount and forge HMAC receipts.
    # /tmp is shared by default with Docker Desktop and Linux Docker.
    parent=Path(os.environ.get("W2_RUNTIME_PARENT","/tmp"))
    parent.mkdir(parents=True,exist_ok=True)
    if parent.resolve()==ROOT.resolve() or ROOT.resolve() in parent.resolve().parents:
        raise ValueError("W2 runtime staging must be outside the repository producer mount")
    stage=Path(tempfile.mkdtemp(prefix="www27_w2_",dir=str(parent)))
    env={**os.environ,"W2_REPO":str(ROOT),"W2_STAGE":str(stage),
         "W2_PROJECT":"www27w2"+uuid.uuid4().hex[:10]}
    started=False
    rows=[]
    try:
        source,activate=stage_sources(stage)
        started=True
        boot=compose(["up","-d","--build"],env)
        if boot.returncode!=0:
            raise RuntimeError("Docker Compose startup failed "+boot.stderr[-1800:])
        await_services()
        latency(0)
        honest_v1,pwall1,producer1=capture("v1")
        for condition,ms in (("baseline",0),("symmetric_latency_50ms",50),
                              ("symmetric_latency_200ms",200)):
            latency(ms)
            for i in range(repetitions):
                r=roundtrip(condition,honest_v1,2)
                r.update({"repetition":i,"configured_latency_ms_each_direction":ms})
                rows.append(r)
                print("WWW27_W2_PROGRESS",json.dumps({
                    "scenario":condition,"rep":i,
                    "seconds":r["end_to_end_verification_and_action_seconds"]
                }),flush=True)
        bandwidth(32)
        for i in range(repetitions):
            r=roundtrip("verifier_uplink_bandwidth_32KiBps",honest_v1,2)
            r["repetition"]=i
            rows.append(r)
        latency(0)
        enable("verifier",False)
        rows.append(roundtrip("verifier_link_partition",honest_v1,0,False,False))
        enable("verifier",True)
        for i in range(repetitions):
            rows.append(roundtrip("post_partition_recovery",honest_v1,2))
        enable("producer",False)
        got,_,err=send("producer",{"query_indices":IDS,"producer_version":"v1"},3)
        if err is None or got is not None:
            raise ValueError("producer link remained reachable while disabled")
        enable("producer",True)
        rows.append({"scenario":"producer_link_partition",
                     "producer_request_succeeded":False,
                     "authorization_not_attempted_without_new_producer":True})
        for kind in ("forged_UNKNOWN_as_PROVEN","forged_GAF_NOT_as_PROVEN",
                     "removed_real_frontier_event","forged_GAF_not_witness",
                     "forged_source_pin"):
            rows.append(roundtrip(kind,forge(honest_v1,kind),0,False,False))
        # Full verifier receipt generated with unique request nonce; post-
        # verification byte changes and second-use receipts MUST be blocked.
        nonce=uuid.uuid4().hex
        packet,_,err=send("verifier",{"trace":honest_v1,"nonce":nonce})
        if err or not packet or packet.get("ok") is not True:
            raise ValueError("genuine receipt was not issued")
        modified=forge(honest_v1,"removed_real_frontier_event")
        action,_,err=send("consumer",{"trace":modified,"nonce":nonce,
                                    "signed_verifier_receipt":packet})
        if err or not action or action.get("authorized")!=0 or action.get("quarantined")!=4:
            raise ValueError("post-verification byte substitution authorized an action")
        rows.append({"scenario":"post_verification_bytes_swapped",
                     "authorized":0,"quarantined":4})
        action,_,err=send("consumer",{"trace":honest_v1,"nonce":nonce,
                                    "signed_verifier_receipt":packet})
        if err or not action or action.get("authorized")!=2:
            raise ValueError("first unique legitimate receipt was not accepted")
        again,_,err=send("consumer",{"trace":honest_v1,"nonce":nonce,
                                   "signed_verifier_receipt":packet})
        if err or not again or again.get("authorized")!=0 or again.get("quarantined")!=4:
            raise ValueError("replayed verifier receipt authorized second action")
        rows.append({"scenario":"reused_signed_receipt",
                     "authorized":0,"quarantined":4})
        forged={"receipt":{"statuses":["PROVEN"]*4},"mac":"0"*64}
        action,_,err=send("consumer",{"trace":honest_v1,"nonce":uuid.uuid4().hex,
                                    "signed_verifier_receipt":forged})
        if err or not action or action.get("authorized")!=0 or action.get("quarantined")!=4:
            raise ValueError("unsigned/forged verifier receipt authorized an action")
        rows.append({"scenario":"producer_forged_verifier_MAC",
                     "authorized":0,"quarantined":4})
        # Operator-controlled source rotation: real T3 switches to candidate.
        activate("v2")
        rows.append(roundtrip("old_source_evidence_after_rotation",honest_v1,0,False,False))
        honest_v2,pwall2,producer2=capture("v2")
        for i in range(repetitions):
            r=roundtrip("current_v2_T3_candidate_policy",honest_v2,1)
            r["repetition"]=i
            rows.append(r)
        rows.append(roundtrip("forged_candidate_PROVEN",
                              forge(honest_v2,"forged_candidate_PROVEN"),0,False,False))
        activate("v1")
        rows.append(roundtrip("stale_candidate_source_after_reversion",
                              honest_v2,0,False,False))
        out={
            "experiment":"www27_w2_distributed_real_services_toxiproxy_v1",
            "passed":True,
            "mode":"Real three-container GO/GAF replay and action receipts over Docker TCP + Toxiproxy",
            "source_sha256":{"trusted_v1":source["v1"],"candidate_v2":source["v2"]},
            "query_manifest_sha256":source["query_manifest_sha256"],
            "selected_source_query_indices":IDS,
            "source_data_provenance":source["genuine_source_census"],
            "fresh_authentic_producer_captures":2,
            "v1_producer_wall_seconds":producer1,
            "v2_producer_wall_seconds":producer2,
            "repetitions_per_nonfailure_condition":repetitions,
            "false_authorized_actions":0,
            "operator_hmac_receipt_key_not_mounted_to_producer":True,
            "replay_protection_nonce_and_trace_hash":True,
            "full_frontier_transcripts_replayed":sum(x.get("full_replay_accepted") is True for x in rows),
            "structured_false_trace_rejections":sum(
                x.get("full_replay_accepted") is False
                and x.get("quarantined")==4
                and x.get("scenario")!="verifier_link_partition"
                for x in rows
            ),
            "latency_summary":{},
            "case_results":rows,
            "limitations":[
                "Original 85,350-fact GO/GO-CAM, original human and mouse GAF NOT and GO query cohorts are reused under independent source hashes. No claim of signed original Web source authenticity.",
                "Two genuine fresh complete producer captures (source v1, operator-downgraded T3 source v2); transport and checker repeat experiments REUSE frozen genuine producer traces, not distinct real producer runs.",
                "The consumer authorizes local JSON action receipts only. It is not a deployed Web platform, independently curated biomedical truth oracle or clinical action.",
                "Docker Compose services share a trusted Linux host and Docker bridge: HMAC is effective only under operator secret custody, not against a compromised privileged host.",
                "Delay, bandwidth and partition injected by Toxiproxy are controlled network faults. A blocked connection is availability failure, NOT a semantic attack detection.",
                "Whole-batch quarantine sacrifices legitimate same-batch authorizations when evidence is incomplete or the verifier is unreachable.",
                "C-SUBSUME finite source-Horn fragment is not full OWL equality, negative GO absence is UNKNOWN, and GAF NOT is relation qualified.",
                "Operator-controlled T3 rule status downgrade is NOT automatic promotion of a learned rule. Schema-consistent semantic poisoning remains an unaddressed review limitation.",
                "Repeated end-to-end latencies include independent checker execution and network round-trips, NOT a fair comparison against Datalog-only materialization throughput.",
                "Original datasets, frozen result JSON and all manuscript LaTeX are unchanged."
            ],
        }
        for condition in ("baseline","symmetric_latency_50ms",
                          "symmetric_latency_200ms","verifier_uplink_bandwidth_32KiBps",
                          "post_partition_recovery","current_v2_T3_candidate_policy"):
            vals=[r["end_to_end_verification_and_action_seconds"] for r in rows
                  if r.get("scenario")==condition]
            out["latency_summary"][condition]={
                "n":len(vals),"p50_seconds":metric_percentile(vals,50),
                "p95_seconds":metric_percentile(vals,95)
            }
        return out
    finally:
        if started:
            try:compose(["down","-v","--remove-orphans"],env,timeout=100)
            except Exception:pass
        shutil.rmtree(stage,ignore_errors=True)
        if os.environ.get("W2_RUNTIME_PARENT"):
            try:parent.rmdir()
            except OSError:pass
        # No temporary operator secrets ever appear inside repo:/app.


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--output",type=Path,default=OUTPUT)
    p.add_argument("--repetitions",type=int,default=3)
    a=p.parse_args()
    try:
        report=campaign(a.repetitions)
    except Exception as exc:
        report={"experiment":"www27_w2_distributed_real_services_toxiproxy_v1",
                "passed":False,"blocked_reason":type(exc).__name__+": "+str(exc)}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
    print("WWW27_W2",json.dumps({
        "passed":report["passed"],"cases":len(report.get("case_results",[])),
        "blocked_reason":report.get("blocked_reason")
    }),flush=True)
    return 0 if report["passed"] else 1


if __name__=="__main__":
    sys.exit(main())
