"""Independent process verifier for v2 GO search transition audit.

IMPORTANT: processed GO files and requested query indices are TRUSTED CLI
inputs, not imported from the trace. Full rule bodies and all facts are
reloaded separately. The audit fails closed on incomplete/reordered/
omitted/forged children, terminals, states and certificates.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from time import perf_counter

from trustkg.independent_transition_audit import (
    TrustedGOIndex, atom, canonical_sha256, replay_trace, trusted_go_snapshot,
)
from trustkg.independent_verdict_audit import compare_decisions


def _read_queries(processed, indices):
    lines = []
    with (processed / "queries.jsonl").open(encoding="utf-8") as stream:
        for raw in stream:
            if raw.strip():
                lines.append(json.loads(raw))
    if any(i < 0 or i >= len(lines) for i in indices):
        raise ValueError("trusted source query index is out of range")
    return [
        atom(lines[i]["query"]["predicate"], lines[i]["query"]["args"])
        for i in indices
    ]


def audit_file(*, input_path, processed, source_indices, max_depth,
               output_path, max_events=100000):
    trace = json.loads(Path(input_path).read_text(encoding="utf-8"))
    begin = perf_counter()
    trusted_snapshot = trusted_go_snapshot(processed)
    trusted_digest = canonical_sha256(trusted_snapshot)
    expected_queries = _read_queries(processed, source_indices)
    loaded_seconds = perf_counter() - begin
    index_begin = perf_counter()
    index = TrustedGOIndex(trusted_snapshot)
    prepared_seconds = perf_counter() - index_begin
    metadata_agrees = (
        trace.get("protocol") == "independent_go_transition_audit_v2"
        and trace.get("source_indices") == source_indices
        and trace.get("max_depth") == max_depth
        and trace.get("producer_snapshot_sha256") == trusted_digest
        and trace.get("passed_capture_completeness") is True
        and trace.get("facts_loaded") == len(trusted_snapshot["facts"])
    )
    if metadata_agrees:
        result = replay_trace(
            trace, expected_queries, index,
            max_depth=max_depth, max_events=max_events,
        )
    else:
        result = {
            "passed": False,
            "failures": [{"reason": "mismatching_trusted_metadata_or_snapshot"}],
            "queries": len(expected_queries),
            "results": [], "certificate_count": 0,
            "elapsed_seconds": 0,
        }
    if result["passed"]:
        verdicts = compare_decisions(trace, index, source_indices)
    else:
        verdicts = {"passed": False, "failures": [
            {"reason": "verdict_check_skipped_failed_transition_replay"}
        ], "rows": []}
    report = {
        "experiment": "www27_independent_search_transition_replay_v2",
        "protocol": "v2_reconstruct_untrusted_events_from_trusted_GO_files",
        "source_indices": source_indices,
        "facts_loaded": len(trusted_snapshot["facts"]),
        "rules_loaded": len(trusted_snapshot["rules"]),
        "trusted_snapshot_sha256": trusted_digest,
        "producer_digest_matches_trusted_snapshot": (
            trace.get("producer_snapshot_sha256") == trusted_digest
        ),
        "snapshot_load_seconds": round(loaded_seconds, 6),
        "trusted_index_prepare_seconds": round(prepared_seconds, 6),
        "transition_replay_seconds": result["elapsed_seconds"],
        "certificate_count": result["certificate_count"],
        "independent_verdict_reconstruction_passed": verdicts["passed"],
        "independent_verdict_rows": verdicts["rows"],
        "failures": result["failures"] + verdicts["failures"],
        "results": result["results"],
        "passed": result["passed"] and verdicts["passed"],
        "trust_boundary": (
            "The verifier imports no producer reasoner/unifier code, "
            "loads trusted GO files and external query indices separately, "
            "and recomputes all expansion children, priority-pop order, "
            "terminal checks, prior expansion history, proof identities, "
            "and aggregate PROVEN/HYPOTHESIZED/REFUTED verdicts. It does "
            "NOT cryptographically attest the external GO files or "
            "independently establish the correctness of their logical axioms."
        ),
    }
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path(
        "results/www2027/audit_v2_full_trace.json"
    ))
    parser.add_argument("--processed", type=Path,
                        default=Path("data/go_case_study/processed"))
    parser.add_argument("--source-indices", default="0,1")
    parser.add_argument("--max-depth", type=int, default=3)
    parser.add_argument("--max-events", type=int, default=100000)
    parser.add_argument("--output", type=Path, default=Path(
        "results/www2027/audit_v2_independent_replay.json"
    ))
    args = parser.parse_args()
    try:
        indices = [int(x.strip()) for x in args.source_indices.split(",")]
    except ValueError:
        parser.error("--source-indices should be comma-separated integers")
    if not indices or args.max_depth < 0 or args.max_events < 1:
        parser.error("invalid indices/max-depth/max-events")
    report = audit_file(
        input_path=args.input, processed=args.processed,
        source_indices=indices, max_depth=args.max_depth,
        max_events=args.max_events, output_path=args.output,
    )
    print(json.dumps({
        k: v for k, v in report.items()
        if k not in ("results", "trust_boundary")
    }, indent=2), flush=True)
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
