"""WWW27 W1: a SEPARATE, fail-closed, source-contract Web KG action consumer.

Receives an operator-owned JSON test plan on a trusted IPC file/channel.
The producer trace is UNTRUSTED. For 'full', the operator supplies a
separately generated trusted-verifier report, never a producer assertion.
There is no network side effect: actions are recorded in JSON. This is
not a hostile-OS sandbox, cryptographic signing, or clinical adjudication.
"""
from __future__ import annotations
import argparse
import json
import hashlib
from pathlib import Path
from time import perf_counter


MODES={"naive_producer_verdict","anchored_final_only","full_independent_replay"}
DECISIONS={"PROVEN","HYPOTHESIZED","REFUTED","UNKNOWN"}


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=True)


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def valid_decision(rows,query):
    """Read one untrusted producer/verifier decision for one ground claim.

    Any missing or ambiguous decision is UNKNOWN; never AUTHORIZE a
    candidate proof, direct refutation, malformed claim or empty trace.
    """
    if not isinstance(rows,list) or not rows:
        return "UNKNOWN",0,0
    if len(rows)!=1 or not isinstance(rows[0],list) or len(rows[0])!=4:
        return "INVALID",0,0
    claim,status,trusted,candidate=rows[0]
    if (claim!=query or status not in DECISIONS
        or type(trusted) is not int or type(candidate) is not int
        or trusted<0 or candidate<0):
        return "INVALID",0,0
    if (status=="PROVEN" and trusted<1
        or status=="HYPOTHESIZED" and (trusted!=0 or candidate<1)
        or status=="REFUTED" and (trusted!=0 or candidate!=0)):
        return "INVALID",0,0
    return status,trusted,candidate


def validated_anchored_reference(ref,contract):
    if (
        type(ref) is not dict
        or ref.get("passed") is not True
        or ref.get("independent_verdict_reconstruction_passed") is not True
        or ref.get("trusted_snapshot_sha256")!=contract["source_sha256"]
        or ref.get("source_indices")!=contract["source_indices"]
        or not isinstance(ref.get("independent_verdict_rows"),list)
        or len(ref["independent_verdict_rows"])!=len(contract["queries"])
        or ref.get("failures")
    ):
        raise ValueError("external anchored reference lacks valid full-verifier origin")
    for i,row in enumerate(ref["independent_verdict_rows"]):
        if row.get("source_index")!=contract["source_indices"][i] or row.get("equal") is not True:
            raise ValueError("invalid anchored reference result rows")
        status,_,_=valid_decision(row.get("verdicts"),contract["queries"][i])
        if status=="INVALID":raise ValueError("invalid authoritative baseline decision")
    return [r["verdicts"] for r in ref["independent_verdict_rows"]]


def read_statuses_from_full(ref,contract):
    expected=validated_anchored_reference(ref,contract)
    return [valid_decision(row,query)[0] for row,query in zip(expected,contract["queries"])]


def check_operator_contract(contract):
    required={"source_sha256","query_manifest_sha256","source_indices","queries"}
    if not required.issubset(contract):raise ValueError("operator contract incomplete")
    if any(type(contract[k]) is not list for k in ("source_indices","queries")):
        raise ValueError("operator indices/queries not properly typed")
    if not contract["queries"] or len(contract["source_indices"])!=len(contract["queries"]):
        raise ValueError("operator query-index cardinality mismatch")
    if len(set(contract["source_indices"]))!=len(contract["source_indices"]):
        raise ValueError("operator query indices repeated")
    if any(type(i) is not int or i<0 for i in contract["source_indices"]):
        raise ValueError("operator query indices invalid")


def request_rows(mode,scenario,contract):
    """Return authorized/rejected/abstained rows and receipt source status."""
    # The orchestrator has exclusive control over this file, which must
    # not be writable by an untrusted producer. We do not claim that
    # this simulation technically enforces multi-user OS ACLs.
    trace=json.loads(Path(scenario["producer_untrusted_path"]).read_text(encoding="utf-8"))
    indices=contract["source_indices"]
    queries=contract["queries"]
    n=len(indices)
    raw=trace.get("runs",[])
    expected_meta=(
        trace.get("source_indices")==indices
        and trace.get("producer_snapshot_sha256")==contract["source_sha256"]
        and isinstance(raw,list) and len(raw)==n
        and isinstance(trace.get("queries"),list) and len(trace["queries"])==n
        and all(
            trace["queries"][i].get("source_index")==indices[i]
            and trace["queries"][i].get("query")==queries[i]
            and raw[i].get("source_index")==indices[i]
            for i in range(n)
        )
    )
    if mode=="naive_producer_verdict":
        # This is deliberately NOT source authenticating or checking
        # the producer metadata. It is an illustrative unsafe policy.
        if not isinstance(raw,list) or len(raw)!=n:
            statuses=["INVALID"]*n
        else:
            statuses=[valid_decision(row.get("decision_summary"),queries[i])[0]
                      for i,row in enumerate(raw)]
        report_accepted=True
    elif mode=="anchored_final_only":
        baseline=json.loads(Path(scenario["operator_baseline_report_path"]).read_text(encoding="utf-8"))
        trusted_baseline=validated_anchored_reference(baseline,contract)
        report_accepted=bool(expected_meta and trace.get("passed_capture_completeness") is True
                             and all(
                                 raw[i].get("complete") is True and
                                 raw[i].get("decision_summary")==trusted_baseline[i]
                                 for i in range(n)
                             ))
        statuses=[valid_decision(row,queries[i])[0] for i,row in
                  enumerate(trusted_baseline)] if report_accepted else ["INVALID"]*n
    elif mode=="full_independent_replay":
        verifier=json.loads(Path(scenario["operator_verifier_report_path"]).read_text(encoding="utf-8"))
        try:
            statuses=read_statuses_from_full(verifier,contract)
            # Prevent a producer from substituting a DIFFERENT trace after
            # verification, even if its query IDs and source pin are the same.
            # The receipt hash is inserted by the trusted orchestrator after
            # the full independent verifier's subprocess completes.
            report_accepted=bool(
                expected_meta
                and verifier.get("operator_trace_sha256")==
                    sha256_file(scenario["producer_untrusted_path"])
                and verifier.get("passed") is True
                and verifier.get("independent_verdict_reconstruction_passed") is True
                and trace.get("passed_capture_completeness") is True
            )
        except ValueError:
            report_accepted=False
            statuses=["INVALID"]*n
        if not report_accepted:
            statuses=["INVALID"]*n
    else:
        raise ValueError("unknown consumer mode")
    actions=[]
    for i,(query,status) in enumerate(zip(queries,statuses)):
        if not report_accepted or status=="INVALID":
            action="QUARANTINE_UNVERIFIED"
        elif status=="PROVEN":
            action="AUTHORIZE_SOURCE_GROUNDED_CONSUMPTION"
        elif status=="REFUTED":
            action="DENY_EXPLICIT_NEGATIVE"
        else:
            action="ABSTAIN_UNPROVEN"
        actions.append({
            "source_query_index":indices[i],
            "query_sha256":hashlib.sha256(canonical(query).encode()).hexdigest(),
            "observed_status":status,"action":action,
        })
    return {
        "scenario":scenario["name"],"fixture_id":scenario["fixture_id"],
        "mode":mode,"operator_source_sha256":contract["source_sha256"],
        "operator_query_manifest_sha256":contract["query_manifest_sha256"],
        "report_accepted":report_accepted,
        "authorized":sum(x["action"]=="AUTHORIZE_SOURCE_GROUNDED_CONSUMPTION" for x in actions),
        "refuted":sum(x["action"]=="DENY_EXPLICIT_NEGATIVE" for x in actions),
        "abstained":sum(x["action"]=="ABSTAIN_UNPROVEN" for x in actions),
        "quarantined":sum(x["action"]=="QUARANTINE_UNVERIFIED" for x in actions),
        "actions":actions,
    }


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--operator-plan",type=Path,required=True)
    p.add_argument("--mode",required=True,choices=sorted(MODES))
    p.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    start=perf_counter()
    data=json.loads(a.operator_plan.read_text(encoding="utf-8"))
    contracts=data["operator_trusted_contracts"]
    for v in contracts.values():check_operator_contract(v)
    out=[]
    for scenario in data["scenarios"]:
        contract=contracts[scenario["fixture_id"]]
        out.append(request_rows(a.mode,scenario,contract))
    result={
        "experiment":"www27_w1_separate_web_consumer_policy_v1",
        "mode":a.mode,"passed":True,
        "operator_plan_sha256":sha256_file(a.operator_plan),
        "request_count":len(out),
        "consumer_wall_seconds":round(perf_counter()-start,6),
        "results":out,
        "side_effects":"JSON authorization receipts only; no network writes",
    }
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print("WWW27_WEB_CONSUMER "+json.dumps({
        "mode":a.mode,"requests":len(out),"passed":True,
    }),flush=True)


if __name__=="__main__":
    main()
