from __future__ import annotations

import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List

from .kb import Atom, KnowledgeBase, Rule


@dataclass(frozen=True)
class BenchmarkQuery:
    query: Atom
    expected: bool
    family: str
    difficulty: int
    split: str = "train"
    metadata: Dict = field(default_factory=dict)


@dataclass(frozen=True)
class SyntheticBenchmark:
    kb: KnowledgeBase
    queries: List[BenchmarkQuery]
    metadata: Dict = field(default_factory=dict)


def _atom_to_dict(atom: Atom) -> Dict:
    return {"predicate": atom.predicate, "args": list(atom.args)}


def _atom_from_dict(payload: Dict) -> Atom:
    return Atom(predicate=payload["predicate"], args=tuple(payload["args"]))


def _rule_to_dict(rule: Rule) -> Dict:
    return {
        "name": rule.name,
        "head": _atom_to_dict(rule.head),
        "body": [_atom_to_dict(atom) for atom in rule.body],
        "confidence": rule.confidence,
    }


def _rule_from_dict(payload: Dict) -> Rule:
    return Rule(
        name=payload["name"],
        head=_atom_from_dict(payload["head"]),
        body=tuple(_atom_from_dict(atom) for atom in payload["body"]),
        confidence=float(payload.get("confidence", 1.0)),
    )


def benchmark_to_dict(benchmark: SyntheticBenchmark) -> Dict:
    return {
        "facts": [_atom_to_dict(atom) for atom in benchmark.kb.facts],
        "rules": [_rule_to_dict(rule) for rule in benchmark.kb.rules],
        "queries": [
            {
                "query": _atom_to_dict(item.query),
                "expected": item.expected,
                "family": item.family,
                "difficulty": item.difficulty,
                "split": item.split,
                "metadata": item.metadata,
            }
            for item in benchmark.queries
        ],
        "metadata": benchmark.metadata,
    }


def benchmark_from_dict(payload: Dict) -> SyntheticBenchmark:
    kb = KnowledgeBase(
        facts=[_atom_from_dict(atom) for atom in payload["facts"]],
        rules=[_rule_from_dict(rule) for rule in payload["rules"]],
    )
    queries = [
        BenchmarkQuery(
            query=_atom_from_dict(item["query"]),
            expected=bool(item["expected"]),
            family=str(item["family"]),
            difficulty=int(item["difficulty"]),
            split=str(item.get("split", "train")),
            metadata=dict(item.get("metadata", {})),
        )
        for item in payload["queries"]
    ]
    return SyntheticBenchmark(kb=kb, queries=queries, metadata=dict(payload.get("metadata", {})))


def write_benchmark(path: str | Path, benchmark: SyntheticBenchmark) -> None:
    with Path(path).open("w", encoding="utf-8") as handle:
        json.dump(benchmark_to_dict(benchmark), handle, indent=2, sort_keys=True)


def read_benchmark(path: str | Path) -> SyntheticBenchmark:
    with Path(path).open("r", encoding="utf-8") as handle:
        return benchmark_from_dict(json.load(handle))


def build_synthetic_benchmark(
    *,
    seed: int = 7,
    num_instances: int = 12,
    chain_length: int = 4,
    distractors_per_step: int = 2,
    include_pathway_proofs: bool = True,
    negatives_per_instance: int = 1,
) -> SyntheticBenchmark:
    rng = random.Random(seed)

    facts: List[Atom] = []
    queries: List[BenchmarkQuery] = []
    rules = [
        Rule(
            name="risk_from_cause",
            head=Atom("risk", ("?D", "?S")),
            body=(Atom("causes", ("?D", "?S")),),
            confidence=0.95,
        ),
        Rule(
            name="risk_from_similarity",
            head=Atom("risk", ("?D", "?S")),
            body=(Atom("chemicallySimilarTo", ("?D", "?D2")), Atom("risk", ("?D2", "?S"))),
            confidence=0.85,
        ),
        Rule(
            name="risk_from_pathway",
            head=Atom("risk", ("?D", "?S")),
            body=(
                Atom("inhibits", ("?D", "?P")),
                Atom("participatesIn", ("?P", "?Path")),
                Atom("associatedWith", ("?Path", "?S")),
            ),
            confidence=0.8,
        ),
        Rule(
            name="risk_from_interaction",
            head=Atom("risk", ("?D", "?S")),
            body=(Atom("interactsWith", ("?D", "?X")), Atom("risk", ("?X", "?S"))),
            confidence=0.75,
        ),
        Rule(
            name="risk_from_bridge_chain",
            head=Atom("risk", ("?D", "?S")),
            body=(
                Atom("interactsWith", ("?D", "?X")),
                Atom("chemicallySimilarTo", ("?X", "?Y")),
                Atom("causes", ("?Y", "?S")),
            ),
            confidence=0.7,
        ),
    ]

    def split_for_index(index: int) -> str:
        ratio = index / max(1, num_instances)
        if ratio < 0.6:
            return "train"
        if ratio < 0.8:
            return "validation"
        return "test"

    def add_fact(atom: Atom) -> None:
        if atom not in facts:
            facts.append(atom)

    for i in range(num_instances):
        split = split_for_index(i)
        base_drug = f"Drug{i}_0"
        local_chain_length = chain_length + rng.randint(0, 2)
        chain_nodes = [f"Drug{i}_{step}" for step in range(local_chain_length + 1)]
        chain_syndrome = f"ChainSyndrome{i}"
        pathway_syndrome = f"PathwaySyndrome{i}"
        bridge_syndrome = f"BridgeSyndrome{i}"
        bridge_drug = f"BridgeDrug{i}"
        helper_drug = f"HelperDrug{i}"
        pathway_protein = f"Protein{i}"
        pathway = f"Pathway{i}"

        for left, right in zip(chain_nodes, chain_nodes[1:]):
            add_fact(Atom("chemicallySimilarTo", (left, right)))
            add_fact(Atom("metabolizes", (left, f"Metabolite{i}_{right.split('_')[-1]}")))

        leaf = chain_nodes[-1]
        add_fact(Atom("causes", (leaf, chain_syndrome)))

        if include_pathway_proofs:
            add_fact(Atom("inhibits", (base_drug, pathway_protein)))
            add_fact(Atom("participatesIn", (pathway_protein, pathway)))
            add_fact(Atom("associatedWith", (pathway, pathway_syndrome)))

        add_fact(Atom("interactsWith", (base_drug, bridge_drug)))
        add_fact(Atom("chemicallySimilarTo", (bridge_drug, helper_drug)))
        add_fact(Atom("causes", (helper_drug, bridge_syndrome)))

        for step, node in enumerate(chain_nodes[:-1]):
            for d in range(distractors_per_step):
                distractor = f"Distractor{i}_{step}_{d}"
                add_fact(Atom("chemicallySimilarTo", (node, distractor)))
                add_fact(Atom("bindsTo", (node, f"Target{i}_{d}")))
                add_fact(Atom("coadministeredWith", (node, f"Coadministered{i}_{d}")))
                if d % 2 == 0:
                    add_fact(Atom("contraindicatedWith", (node, f"Contra{i}_{d}")))

        queries.append(
            BenchmarkQuery(
                query=Atom("risk", (base_drug, chain_syndrome)),
                expected=True,
                family="positive_chain",
                split=split,
                difficulty=local_chain_length,
                metadata={
                    "instance": i,
                    "proof_family": "chain",
                    "chain_length": local_chain_length,
                },
            )
        )

        if include_pathway_proofs:
            queries.append(
                BenchmarkQuery(
                    query=Atom("risk", (base_drug, pathway_syndrome)),
                    expected=True,
                    family="positive_pathway",
                    split=split,
                    difficulty=3,
                    metadata={"instance": i, "proof_family": "pathway"},
                )
            )

        queries.append(
            BenchmarkQuery(
                query=Atom("risk", (base_drug, bridge_syndrome)),
                expected=True,
                family="positive_bridge",
                split=split,
                difficulty=3,
                metadata={"instance": i, "proof_family": "bridge"},
            )
        )

        for n in range(negatives_per_instance):
            negative_target = f"NegativeSyndrome{i}_{n}"
            queries.append(
                BenchmarkQuery(
                    query=Atom("risk", (base_drug, negative_target)),
                    expected=False,
                    family="negative_query",
                    split=split,
                    difficulty=local_chain_length + 1,
                    metadata={"instance": i, "slot": n, "proof_family": "negative"},
                )
            )

    kb = KnowledgeBase(facts=facts, rules=rules)
    split_counts = {"train": 0, "validation": 0, "test": 0}
    family_counts: Dict[str, int] = {}
    for query in queries:
        split_counts[query.split] = split_counts.get(query.split, 0) + 1
        family_counts[query.family] = family_counts.get(query.family, 0) + 1
    metadata = {
        "seed": seed,
        "num_instances": num_instances,
        "chain_length": chain_length,
        "distractors_per_step": distractors_per_step,
        "include_pathway_proofs": include_pathway_proofs,
        "negatives_per_instance": negatives_per_instance,
        "split_counts": split_counts,
        "family_counts": family_counts,
    }
    return SyntheticBenchmark(kb=kb, queries=queries, metadata=metadata)
