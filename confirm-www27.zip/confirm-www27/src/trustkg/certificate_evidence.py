"""Adapter exporting ConFIRM states and protected KB snapshots as plain JSON data.

This adapter is NOT the verifier. The verifier must receive the independently
trusted snapshot/digest, not trust arbitrary input carried in the certificate.
"""
from __future__ import annotations
import hashlib
import json
from .kb import Atom
from .trust import TrustContext, TrustState

def atom_data(atom: Atom) -> dict:
    return {"predicate": atom.predicate, "args": list(atom.args)}

def snapshot_data(context: TrustContext) -> dict:
    """Serialize unordered schema/negative sets in a deterministic order."""
    schema = context.schema
    data = {
        "facts": [atom_data(a) for a in context.kb.facts],
        "rules": [{"name": r.name, "head": atom_data(r.head),
                   "status": context.status_of(r.name)} for r in context.kb.rules],
        "negatives": [atom_data(a) for a in sorted(context.negatives, key=lambda a: (a.predicate, a.args))],
        "schema": {
            "types": {k: sorted(v) for k, v in schema.types.items()},
            "domain": dict(schema.domain), "range": dict(schema.range_),
            "disjoint": sorted(sorted(v) for v in schema.disjoint),
            "functional": sorted(schema.functional),
            "irreflexive": sorted(schema.irreflexive),
        },
    }
    return data

def canonical_bytes(data: dict) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()

def snapshot_digest(data: dict) -> str:
    return hashlib.sha256(canonical_bytes(data)).hexdigest()

def evidence_data(context: TrustContext, state: TrustState, kind: str,
                  *, max_depth: int, witness: object = None) -> dict:
    return {
        "version": 1, "kind": kind,
        "snapshot_sha256": snapshot_digest(snapshot_data(context)),
        "state": {"goals": [atom_data(g) for g in state.normalized_goals()],
                  "depth": state.depth},
        "max_depth": max_depth,
        "witness": witness,
    }


def subsumption_state_data(state: TrustState) -> dict:
    """Full proof-sensitive state required for exact C-SUBSUME verification.

    The engine key includes normalized query, ordered normalized goals,
    ordered normalized proof, and raw substitution pairs. No compression
    of proof evidence is permitted here.
    """
    from .unify import apply_substitution
    return {
        "query": atom_data(apply_substitution(state.query, state.substitution_dict())),
        "goals": [atom_data(a) for a in state.normalized_goals()],
        "proof": [
            {"rule": name, "atom": atom_data(a)}
            for name, a in state.normalized_proof()
        ],
        "substitution": [[k, v] for k, v in state.substitution],
        "depth": state.depth,
    }


def subsumption_evidence_data(
    context: TrustContext, state: TrustState, *,
    max_depth: int, seen_index: int,
) -> dict:
    """Produce v2 evidence; seen_index addresses EXTERNAL trusted history.

    The producer is deliberately not permitted to embed a trusted history.
    Its claim must be checked against a separately supplied prior-state log.
    """
    return {
        "version": 2,
        "kind": "C-SUBSUME",
        "snapshot_sha256": snapshot_digest(snapshot_data(context)),
        "state": subsumption_state_data(state),
        "max_depth": max_depth,
        "witness": {"seen_index": seen_index},
    }


def full_snapshot_data(context: TrustContext) -> dict:
    """NEW audit-only snapshot: include rule bodies for transition replay.

    Keep snapshot_data() and its historical digest unchanged. The new
    checker rejects a trace whose full snapshot digest does not match
    the independently loaded trusted GO inputs.
    """
    data = snapshot_data(context)
    data["rules"] = [
        {
            **row,
            "body": [atom_data(a) for a in rule.body],
        }
        for row, rule in zip(data["rules"], context.kb.rules)
    ]
    return data


def full_state_data(state: TrustState) -> dict:
    """Unnormalized state for independent unification/transition checking."""
    return {
        "query": atom_data(state.query),
        "goals": [atom_data(g) for g in state.goals],
        "proof": [
            {"rule": rule, "atom": atom_data(a)}
            for rule, a in state.proof
        ],
        "substitution": [[k, v] for k, v in state.substitution],
        "depth": state.depth,
    }
