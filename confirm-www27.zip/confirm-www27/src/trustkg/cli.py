from __future__ import annotations

import argparse
import json
from pathlib import Path

from . import __version__
from .benchmark import build_synthetic_benchmark, read_benchmark, write_benchmark
from .datasets import (
    build_benchmark_from_dataset_files,
    build_benchmark_from_single_edge_file,
    discover_dataset_files,
)
from .demo import build_demo_kb
from .heuristics import rule_confidence_heuristic
from .kb import Atom
from .reasoner import SearchStrategy, SymbolicReasoner
from .rules import (
    audit_rules,
    filter_rules,
    generate_starter_rules_from_benchmark,
    import_anyburl_rules,
    write_rule_summary,
    write_rules_json,
)
from .search import search_query
from .trace_tools import load_and_replay_trace_file, load_and_validate_trace_file
from .traces import read_trace_records, write_trace_records
from .trust import CertifiedReasoner, Schema, TrustContext, audit_answers, inject_attack


def cmd_demo(_: argparse.Namespace) -> None:
    kb = build_demo_kb()
    reasoner = SymbolicReasoner(kb, max_depth=10, max_expansions=1000)
    query = Atom("risk", ("DrugA", "Arrhythmia"))
    results = reasoner.search(
        query, strategy=SearchStrategy.BEST_FIRST, heuristic=rule_confidence_heuristic, top_k=3
    )
    for idx, result in enumerate(results, start=1):
        print(
            json.dumps(
                {
                    "rank": idx,
                    "success": result.success,
                    "expanded": result.expanded_states,
                    "generated": result.generated_states,
                    "visited": result.visited_states,
                    "proof_length": len(result.proof_steps),
                },
                indent=2,
            )
        )


def cmd_confirm_demo(args: argparse.Namespace) -> None:
    """Runnable Paper 3 smoke workflow using the release package types."""
    kb = build_demo_kb()
    context = TrustContext(
        kb=kb,
        schema=Schema(
            types={"DrugA": frozenset({"Drug"}), "Arrhythmia": frozenset({"Condition"})},
            domain={"risk": "Drug"},
            range_={"risk": "Condition"},
        ),
        rule_status={rule.name: "trusted" for rule in kb.rules},
    )
    if args.attack:
        context = inject_attack(context, args.attack, count=args.attack_count, seed=args.seed)
    reasoner = CertifiedReasoner(context, max_depth=args.max_depth, enforce=not args.monitor)
    answers, stats = reasoner.search(
        Atom(args.predicate, tuple(args.args)),
        certified=not args.no_certified_pruning,
    )
    records = audit_answers(answers)
    print(
        json.dumps(
            {
                "mode": "monitoring" if args.monitor else "deployment",
                "answers": [
                    {
                        "claim": {
                            "predicate": record.answer.claim.predicate,
                            "args": record.answer.claim.args,
                        },
                        "status": record.answer.status,
                        "refutation": record.answer.refutation,
                        "rules_used": record.answer.rules_used,
                        "risk_summary": record.risk_summary,
                    }
                    for record in records
                ],
                "search": {
                    "expanded": stats.expanded,
                    "generated": stats.generated,
                    "pruned": stats.pruned,
                    "exhausted_budget": stats.exhausted_budget,
                    "exhausted_state_budget": stats.exhausted_state_budget,
                    "exhausted_time_budget": stats.exhausted_time_budget,
                },
                "injected_rules": sorted(context.injected_rules),
            },
            indent=2,
        )
    )


def cmd_run_experiment(args: argparse.Namespace) -> None:
    from .experiments import load_config, run_experiment

    config = load_config(args.config)
    if args.seed is not None:
        if args.paper != "paper3":
            raise ValueError(
                "--seed override is currently supported only for the Paper 3 real-data protocol"
            )
        if not config.get("datasets"):
            raise ValueError("--seed override requires a Paper 3 real-data configuration")
        protocol = dict(config.get("protocol", {}))
        protocol["seeds"] = [args.seed]
        config["protocol"] = protocol
    run_path = run_experiment(
        args.paper,
        config,
        results_root=args.results_root,
        name=args.name,
    )
    print(json.dumps({"paper": args.paper, "run_dir": str(run_path)}, indent=2))


def cmd_collect_paper3(args: argparse.Namespace) -> None:
    from .experiments import collect_paper3_runs

    output = collect_paper3_runs(args.runs, args.output)
    print(json.dumps({"paper": "paper3", "collection_dir": str(output)}, indent=2))


def cmd_trace(args: argparse.Namespace) -> None:
    kb = build_demo_kb()
    query = Atom(args.predicate, tuple(args.args))
    run = search_query(
        kb,
        query,
        strategy=SearchStrategy(args.strategy),
        heuristic_name=args.heuristic,
        max_depth=args.max_depth,
        max_expansions=args.max_expansions,
        top_k=args.top_k,
        collect_trace=True,
        utility_mode=args.utility_mode,
        utility_decay=args.utility_decay,
    )
    if run.trace is None:
        raise RuntimeError("Trace collection failed.")
    write_trace_records(args.output, run.trace)
    print(json.dumps({"trace_records": len(run.trace), "output": args.output}, indent=2))


def cmd_search(args: argparse.Namespace) -> None:
    kb = build_demo_kb()
    query = Atom(args.predicate, tuple(args.args))
    run = search_query(
        kb,
        query,
        strategy=SearchStrategy(args.strategy),
        heuristic_name=args.heuristic,
        max_depth=args.max_depth,
        max_expansions=args.max_expansions,
        top_k=args.top_k,
    )
    print(
        json.dumps(
            [
                {
                    "success": r.success,
                    "expanded": r.expanded_states,
                    "generated": r.generated_states,
                    "visited": r.visited_states,
                    "proof_length": len(r.proof_steps),
                }
                for r in run.results
            ],
            indent=2,
        )
    )


def cmd_train(args: argparse.Namespace) -> None:
    from time import perf_counter

    from .graph import SymbolGraphBuilder
    from .train import (
        TrainingConfig,
        build_model,
        save_model_checkpoint,
        train_from_traces_with_metrics,
    )

    kb = build_demo_kb()
    builder = SymbolGraphBuilder(kb)
    records = read_trace_records(args.trace_file)
    if args.max_trace_records and len(records) > args.max_trace_records:
        records = records[: args.max_trace_records]
    model = build_model(
        builder, hidden_dim=args.hidden_dim, num_layers=args.num_layers, dropout=args.dropout
    )
    start = perf_counter()
    report = train_from_traces_with_metrics(
        model,
        builder,
        records,
        TrainingConfig(
            epochs=args.epochs,
            learning_rate=args.lr,
            device=args.device,
            margin=args.margin,
            ranking_metric=args.ranking_metric,
            aux_risk_weight=args.aux_risk_weight,
            aux_prune_weight=args.aux_prune_weight,
            aux_contradiction_weight=args.aux_contradiction_weight,
        ),
    )
    report["branch_ranking"] = report.get("pairwise_ranking")
    report["training_wall_clock_seconds"] = perf_counter() - start
    print(json.dumps(report, indent=2))
    if args.output_model:
        save_model_checkpoint(
            args.output_model,
            model,
            hidden_dim=args.hidden_dim,
            num_layers=args.num_layers,
            dropout=args.dropout,
            metadata={
                "source_trace_file": args.trace_file,
                "epochs": args.epochs,
                "margin": args.margin,
                "ranking_metric": args.ranking_metric,
                "aux_risk_weight": args.aux_risk_weight,
                "aux_prune_weight": args.aux_prune_weight,
                "aux_contradiction_weight": args.aux_contradiction_weight,
                "utility_mode": args.utility_mode,
                "utility_decay": args.utility_decay,
                "pairwise_ranking": report.get("pairwise_ranking", {}),
                "branch_ranking": report.get("branch_ranking", {}),
            },
        )


def cmd_generate_benchmark(args: argparse.Namespace) -> None:
    benchmark = build_synthetic_benchmark(
        seed=args.seed,
        num_instances=args.num_instances,
        chain_length=args.chain_length,
        distractors_per_step=args.distractors_per_step,
        include_pathway_proofs=not args.no_pathway_proofs,
        negatives_per_instance=args.negatives_per_instance,
    )
    write_benchmark(args.output, benchmark)
    print(json.dumps({"output": args.output, "queries": len(benchmark.queries)}, indent=2))


def cmd_evaluate(args: argparse.Namespace) -> None:
    from time import perf_counter

    from .evaluation import (
        evaluate_benchmark,
        write_evaluation_summary_csv,
        write_evaluation_summary_markdown,
        write_experiment_result_bundle,
    )

    benchmark = (
        read_benchmark(args.benchmark)
        if args.benchmark
        else build_synthetic_benchmark(
            seed=args.seed,
            num_instances=args.num_instances,
            chain_length=args.chain_length,
            distractors_per_step=args.distractors_per_step,
            include_pathway_proofs=not args.no_pathway_proofs,
            negatives_per_instance=args.negatives_per_instance,
        )
    )
    start = perf_counter()
    report = evaluate_benchmark(
        benchmark,
        strategies=args.strategies,
        max_depth=args.max_depth,
        max_expansions=args.max_expansions,
        top_k=args.top_k,
        device=args.device,
        model_checkpoint=args.model_checkpoint,
        bootstrap_train=not args.no_bootstrap_train,
        bootstrap_strategy=args.bootstrap_strategy,
        training_epochs=args.training_epochs,
        training_lr=args.training_lr,
        training_margin=args.training_margin,
        training_ranking_metric=args.training_ranking_metric,
        aux_risk_weight=args.aux_risk_weight,
        aux_prune_weight=args.aux_prune_weight,
        aux_contradiction_weight=args.aux_contradiction_weight,
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        dropout=args.dropout,
        trace_utility_mode=args.utility_mode,
        trace_utility_decay=args.utility_decay,
        baseline_strategy=args.baseline_strategy,
        include_cost_analysis=args.report_mode == "payback",
    )
    report["evaluation_wall_clock_seconds"] = perf_counter() - start
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2, sort_keys=True)
    if args.summary_csv:
        write_evaluation_summary_csv(report, args.summary_csv)
    if args.summary_md:
        write_evaluation_summary_markdown(report, args.summary_md)
    if args.results_root:
        dataset_name = args.results_name
        if not dataset_name and isinstance(benchmark.metadata, dict):
            dataset_name = benchmark.metadata.get("dataset_name")
        if not dataset_name and args.benchmark:
            dataset_name = Path(args.benchmark).stem
        if not dataset_name:
            dataset_name = "benchmark"
        write_experiment_result_bundle(
            args.results_root,
            str(dataset_name),
            report,
            benchmark=benchmark,
            trace_file=args.trace_file,
            model_file=args.model_checkpoint,
        )
    print(json.dumps(report["summaries"], indent=2))


def cmd_import_dataset(args: argparse.Namespace) -> None:
    if args.root:
        files = discover_dataset_files(args.root)
        train_path = files.train
        valid_path = files.valid
        test_path = files.test
        rules_path = args.rules or files.rules
    else:
        train_path = args.train
        valid_path = args.valid
        test_path = args.test
        rules_path = args.rules

    benchmark = build_benchmark_from_dataset_files(
        train_path=train_path,
        valid_path=valid_path,
        test_path=test_path,
        rules_path=rules_path,
        dataset_name=args.dataset_name,
        seed=args.seed,
        negatives_per_positive=args.negatives_per_positive,
        include_validation_facts=not args.no_validation_facts,
    )
    write_benchmark(args.output, benchmark)
    print(
        json.dumps(
            {
                "output": args.output,
                "queries": len(benchmark.queries),
                "dataset": args.dataset_name,
            },
            indent=2,
        )
    )


def cmd_import_hetionet(args: argparse.Namespace) -> None:
    if args.edge_path:
        benchmark = build_benchmark_from_single_edge_file(
            edge_path=args.edge_path,
            dataset_name=args.dataset_name,
            seed=args.seed,
            negatives_per_positive=args.negatives_per_positive,
            train_ratio=args.train_ratio,
            valid_ratio=args.valid_ratio,
            rules_path=args.rules,
            include_validation_facts=not args.no_validation_facts,
        )
    else:
        benchmark = None
        if not args.root:
            raise ValueError("Provide --root or --edge-path.")
        files = discover_dataset_files(args.root)
        train_path = files.train
        valid_path = files.valid
        test_path = files.test
        rules_path = args.rules or files.rules
        benchmark = build_benchmark_from_dataset_files(
            train_path=train_path,
            valid_path=valid_path,
            test_path=test_path,
            rules_path=rules_path,
            dataset_name=args.dataset_name,
            seed=args.seed,
            negatives_per_positive=args.negatives_per_positive,
            include_validation_facts=not args.no_validation_facts,
        )
    write_benchmark(args.output, benchmark)
    print(
        json.dumps(
            {
                "output": args.output,
                "queries": len(benchmark.queries),
                "dataset": args.dataset_name,
            },
            indent=2,
        )
    )


def cmd_compare_benchmarks(args: argparse.Namespace) -> None:
    from .evaluation import (
        evaluate_benchmark_suite,
        write_experiment_result_bundle,
        write_suite_summary_csv,
        write_suite_summary_markdown,
    )

    benchmarks = {}
    for item in args.benchmarks:
        if "=" in item:
            dataset_name, benchmark_path = item.split("=", 1)
        else:
            benchmark_path = item
            dataset_name = Path(benchmark_path).stem
        benchmarks[dataset_name] = read_benchmark(benchmark_path)

    report = evaluate_benchmark_suite(
        benchmarks,
        strategies=args.strategies,
        max_depth=args.max_depth,
        max_expansions=args.max_expansions,
        top_k=args.top_k,
        device=args.device,
        model_checkpoint=args.model_checkpoint,
        bootstrap_train=not args.no_bootstrap_train,
        bootstrap_strategy=args.bootstrap_strategy,
        training_epochs=args.training_epochs,
        training_lr=args.training_lr,
        training_margin=args.training_margin,
        training_ranking_metric=args.training_ranking_metric,
        aux_risk_weight=args.aux_risk_weight,
        aux_prune_weight=args.aux_prune_weight,
        aux_contradiction_weight=args.aux_contradiction_weight,
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        dropout=args.dropout,
        trace_utility_mode=args.utility_mode,
        trace_utility_decay=args.utility_decay,
        baseline_strategy=args.baseline_strategy,
        include_cost_analysis=args.report_mode == "payback",
    )

    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2, sort_keys=True)
    if args.summary_csv:
        write_suite_summary_csv(report, args.summary_csv)
    if args.summary_md:
        write_suite_summary_markdown(report, args.summary_md)
    if args.results_root:
        for dataset_name, benchmark in benchmarks.items():
            dataset_report = report["benchmarks"][dataset_name]
            write_experiment_result_bundle(
                args.results_root,
                dataset_name,
                dataset_report,
                benchmark=benchmark,
                model_file=args.model_checkpoint,
            )
    print(json.dumps(report["summaries"], indent=2))


def cmd_trace_benchmark(args: argparse.Namespace) -> None:
    from .benchmark import read_benchmark
    from .reasoner import SearchStrategy, SymbolicReasoner
    from .traces import write_trace_records

    benchmark = read_benchmark(args.benchmark)
    reasoner = SymbolicReasoner(
        benchmark.kb, max_depth=args.max_depth, max_expansions=args.max_expansions
    )
    trace_records = []
    for benchmark_query in benchmark.queries:
        bundle = reasoner.search(
            benchmark_query.query,
            strategy=SearchStrategy(args.strategy),
            heuristic=None,
            top_k=args.top_k,
            collect_trace=True,
            utility_mode=args.utility_mode,
            utility_decay=args.utility_decay,
        )
        if bundle.trace is not None:
            trace_records.extend(bundle.trace)
    write_trace_records(args.output, trace_records)
    print(
        json.dumps(
            {
                "output": args.output,
                "trace_records": len(trace_records),
                "benchmark": args.benchmark,
            },
            indent=2,
        )
    )


def cmd_make_starter_rules(args: argparse.Namespace) -> None:
    benchmark = read_benchmark(args.benchmark)
    rules = generate_starter_rules_from_benchmark(
        benchmark,
        include_inverse=not args.no_inverse,
        include_chain=not args.no_chain,
        chain_max_rules=args.chain_max_rules,
    )
    write_rules_json(args.output, rules)
    print(
        json.dumps(
            {"output": args.output, "rules": len(rules), "benchmark": args.benchmark}, indent=2
        )
    )


def cmd_mine_rules(args: argparse.Namespace) -> None:
    from .rules import mine_rules_from_benchmark

    benchmark = read_benchmark(args.benchmark)
    rules = mine_rules_from_benchmark(
        benchmark,
        min_inverse_support=args.min_inverse_support,
        min_inverse_confidence=args.min_inverse_confidence,
        min_chain_support=args.min_chain_support,
        min_chain_confidence=args.min_chain_confidence,
        max_inverse_rules=args.max_inverse_rules,
        max_chain_rules=args.max_chain_rules,
        algorithm=args.algorithm,
    )
    write_rules_json(args.output, rules)
    print(
        json.dumps(
            {"output": args.output, "rules": len(rules), "benchmark": args.benchmark}, indent=2
        )
    )


def cmd_import_rules(args: argparse.Namespace) -> None:
    rules = import_anyburl_rules(args.source, args.output, limit=args.limit)
    print(json.dumps({"output": args.output, "source": args.source, "rules": len(rules)}, indent=2))


def cmd_summarize_rules(args: argparse.Namespace) -> None:
    benchmark = read_benchmark(args.benchmark) if args.benchmark else None
    if args.rules:
        from .datasets import read_rule_file

        rules = read_rule_file(args.rules)
    elif benchmark is not None:
        rules = benchmark.kb.rules
    else:
        raise ValueError("Provide either --rules or --benchmark.")
    if args.output:
        write_rule_summary(args.output, rules, top_k=args.top_k)
    else:
        ordered = sorted(
            rules,
            key=lambda rule: (-float(rule.confidence), len(rule.body), rule.name),
        )[: args.top_k]
        print("name\tconfidence\thead\tbody")
        for rule in ordered:
            body = " , ".join(f"{atom.predicate}({', '.join(atom.args)})" for atom in rule.body)
            print(
                "\t".join(
                    [
                        rule.name,
                        f"{float(rule.confidence):.6f}",
                        f"{rule.head.predicate}({', '.join(rule.head.args)})",
                        body,
                    ]
                )
            )
    print(
        json.dumps(
            {"output": args.output or "stdout", "rules": len(rules), "top_k": args.top_k}, indent=2
        )
    )


def cmd_audit_rules(args: argparse.Namespace) -> None:
    if args.rules:
        from .datasets import read_rule_file

        rules = read_rule_file(args.rules)
    elif args.benchmark:
        benchmark = read_benchmark(args.benchmark)
        rules = benchmark.kb.rules
    else:
        raise ValueError("Provide either --rules or --benchmark.")

    report = audit_rules(
        rules,
        min_confidence=args.min_confidence,
        min_body_length=args.min_body_length,
        exclude_trivial_inverse=args.exclude_trivial_inverse,
    )
    if args.filtered_output:
        filtered = filter_rules(
            rules,
            min_confidence=args.min_confidence,
            min_body_length=args.min_body_length,
            exclude_trivial_inverse=args.exclude_trivial_inverse,
        )
        write_rules_json(args.filtered_output, filtered)
        report["filtered_output"] = args.filtered_output
        report["filtered_rule_count"] = len(filtered)
    if args.output:
        Path(args.output).write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
    print(json.dumps(report, indent=2, sort_keys=True))


def cmd_validate_trace(args: argparse.Namespace) -> None:
    benchmark = read_benchmark(args.benchmark) if args.benchmark else None
    report = load_and_validate_trace_file(args.trace_file, kb=benchmark.kb if benchmark else None)
    print(json.dumps(report.__dict__, indent=2))


def cmd_replay_trace(args: argparse.Namespace) -> None:
    report = load_and_replay_trace_file(args.trace_file)
    print(json.dumps(report.__dict__, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="trustkg")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    demo = sub.add_parser("demo")
    demo.set_defaults(func=cmd_demo)

    confirm_demo = sub.add_parser(
        "confirm-demo", help="Run the ConFIRM certified-search and audit workflow"
    )
    confirm_demo.add_argument("--predicate", default="risk")
    confirm_demo.add_argument("--args", nargs="+", default=["DrugA", "Arrhythmia"])
    confirm_demo.add_argument("--max-depth", type=int, default=6)
    confirm_demo.add_argument(
        "--monitor", action="store_true", help="Allow refuted claims for monitor evaluation"
    )
    confirm_demo.add_argument("--no-certified-pruning", action="store_true")
    confirm_demo.add_argument("--attack", choices=["A1", "A2", "A3", "A4", "A5"])
    confirm_demo.add_argument("--attack-count", type=int, default=1)
    confirm_demo.add_argument("--seed", type=int, default=7)
    confirm_demo.set_defaults(func=cmd_confirm_demo)

    run_experiment = sub.add_parser("run", help="Run a reproducible Paper 1, 2, or 3 experiment")
    run_experiment.add_argument("paper", choices=["paper1", "paper2", "paper3"])
    run_experiment.add_argument(
        "--config", required=True, help="Paper-scoped JSON experiment config"
    )
    run_experiment.add_argument("--results-root", default="results")
    run_experiment.add_argument("--name", help="Optional run-name override")
    run_experiment.add_argument(
        "--seed", type=int, help="Run one Paper 3 real-data protocol replica with this seed"
    )
    run_experiment.set_defaults(func=cmd_run_experiment)

    collect_paper3 = sub.add_parser(
        "collect-paper3", help="Collect completed Paper 3 real-data replicas"
    )
    collect_paper3.add_argument(
        "--runs", nargs="+", required=True, help="Completed Paper 3 real-data run directories"
    )
    collect_paper3.add_argument(
        "--output", required=True, help="New directory for immutable aggregate artifacts"
    )
    collect_paper3.set_defaults(func=cmd_collect_paper3)

    trace = sub.add_parser("trace")
    trace.add_argument("--strategy", default="bfs", choices=[s.value for s in SearchStrategy])
    trace.add_argument(
        "--heuristic",
        default="rule_confidence",
        choices=["shortest_path", "rule_confidence", "random"],
    )
    trace.add_argument("--predicate", default="risk")
    trace.add_argument("--args", nargs="+", default=["DrugA", "Arrhythmia"])
    trace.add_argument("--output", required=True)
    trace.add_argument("--max-depth", type=int, default=20)
    trace.add_argument("--max-expansions", type=int, default=20_000)
    trace.add_argument("--top-k", type=int, default=3)
    trace.add_argument(
        "--utility-mode",
        default="proof_distance",
        choices=["proof_distance", "exponential", "depth", "binary", "semantic"],
    )
    trace.add_argument("--utility-decay", type=float, default=1.0)
    trace.set_defaults(func=cmd_trace)

    generate = sub.add_parser("generate-benchmark")
    generate.add_argument("--output", required=True)
    generate.add_argument("--seed", type=int, default=7)
    generate.add_argument("--num-instances", type=int, default=12)
    generate.add_argument("--chain-length", type=int, default=4)
    generate.add_argument("--distractors-per-step", type=int, default=2)
    generate.add_argument("--negatives-per-instance", type=int, default=1)
    generate.add_argument("--no-pathway-proofs", action="store_true")
    generate.set_defaults(func=cmd_generate_benchmark)

    import_dataset = sub.add_parser("import-dataset")
    import_dataset.add_argument("--output", required=True)
    import_dataset.add_argument("--root")
    import_dataset.add_argument("--train")
    import_dataset.add_argument("--valid")
    import_dataset.add_argument("--test")
    import_dataset.add_argument("--rules")
    import_dataset.add_argument("--dataset-name", default="dataset")
    import_dataset.add_argument("--seed", type=int, default=7)
    import_dataset.add_argument("--negatives-per-positive", type=int, default=1)
    import_dataset.add_argument("--no-validation-facts", action="store_true")
    import_dataset.set_defaults(func=cmd_import_dataset)

    import_hetionet = sub.add_parser("import-hetionet")
    import_hetionet.add_argument("--output", required=True)
    import_hetionet.add_argument("--root")
    import_hetionet.add_argument(
        "--edge-path", help="Single Hetionet edge file such as edges.tsv or edges.sif.gz"
    )
    import_hetionet.add_argument("--rules")
    import_hetionet.add_argument("--dataset-name", default="hetionet")
    import_hetionet.add_argument("--seed", type=int, default=7)
    import_hetionet.add_argument("--negatives-per-positive", type=int, default=1)
    import_hetionet.add_argument("--train-ratio", type=float, default=0.8)
    import_hetionet.add_argument("--valid-ratio", type=float, default=0.1)
    import_hetionet.add_argument("--no-validation-facts", action="store_true")
    import_hetionet.set_defaults(func=cmd_import_hetionet)

    evaluate = sub.add_parser("evaluate")
    evaluate.add_argument("--benchmark")
    evaluate.add_argument("--output")
    evaluate.add_argument("--model-checkpoint")
    evaluate.add_argument(
        "--bootstrap-strategy",
        default="rule_confidence",
        choices=["bfs", "dfs", "random", "shortest_path", "rule_confidence"],
    )
    evaluate.add_argument("--no-bootstrap-train", action="store_true")
    evaluate.add_argument("--training-epochs", type=int, default=4)
    evaluate.add_argument("--training-lr", type=float, default=1e-3)
    evaluate.add_argument("--training-margin", type=float, default=0.2)
    evaluate.add_argument(
        "--training-ranking-metric", default="pairwise_accuracy", choices=["pairwise_accuracy"]
    )
    evaluate.add_argument("--aux-risk-weight", type=float, default=0.1)
    evaluate.add_argument("--aux-prune-weight", type=float, default=0.1)
    evaluate.add_argument("--aux-contradiction-weight", type=float, default=0.1)
    evaluate.add_argument(
        "--baseline-strategy",
        default=None,
        choices=["bfs", "dfs", "random", "shortest_path", "rule_confidence"],
    )
    evaluate.add_argument("--device")
    evaluate.add_argument("--hidden-dim", type=int, default=128)
    evaluate.add_argument("--num-layers", type=int, default=2)
    evaluate.add_argument("--dropout", type=float, default=0.1)
    evaluate.add_argument("--seed", type=int, default=7)
    evaluate.add_argument("--num-instances", type=int, default=12)
    evaluate.add_argument("--chain-length", type=int, default=4)
    evaluate.add_argument("--distractors-per-step", type=int, default=2)
    evaluate.add_argument("--negatives-per-instance", type=int, default=1)
    evaluate.add_argument("--no-pathway-proofs", action="store_true")
    evaluate.add_argument("--max-depth", type=int, default=20)
    evaluate.add_argument("--max-expansions", type=int, default=20_000)
    evaluate.add_argument("--top-k", type=int, default=1)
    evaluate.add_argument(
        "--utility-mode",
        default="proof_distance",
        choices=["proof_distance", "exponential", "depth", "binary", "semantic"],
    )
    evaluate.add_argument("--utility-decay", type=float, default=1.0)
    evaluate.add_argument("--summary-csv")
    evaluate.add_argument("--summary-md")
    evaluate.add_argument("--results-root")
    evaluate.add_argument("--results-name")
    evaluate.add_argument("--trace-file")
    evaluate.add_argument("--report-mode", default="guidance", choices=["guidance", "payback"])
    evaluate.add_argument(
        "--strategies",
        nargs="+",
        default=["bfs", "dfs", "random", "shortest_path", "rule_confidence", "gnn"],
    )
    evaluate.set_defaults(func=cmd_evaluate)

    compare = sub.add_parser("compare-benchmarks")
    compare.add_argument("--benchmarks", nargs="+", required=True)
    compare.add_argument("--output")
    compare.add_argument("--summary-csv")
    compare.add_argument("--summary-md")
    compare.add_argument("--results-root")
    compare.add_argument("--model-checkpoint")
    compare.add_argument("--trace-file")
    compare.add_argument(
        "--bootstrap-strategy",
        default="rule_confidence",
        choices=["bfs", "dfs", "random", "shortest_path", "rule_confidence"],
    )
    compare.add_argument("--no-bootstrap-train", action="store_true")
    compare.add_argument("--training-epochs", type=int, default=4)
    compare.add_argument("--training-lr", type=float, default=1e-3)
    compare.add_argument("--training-margin", type=float, default=0.2)
    compare.add_argument(
        "--training-ranking-metric", default="pairwise_accuracy", choices=["pairwise_accuracy"]
    )
    compare.add_argument("--aux-risk-weight", type=float, default=0.1)
    compare.add_argument("--aux-prune-weight", type=float, default=0.1)
    compare.add_argument("--aux-contradiction-weight", type=float, default=0.1)
    compare.add_argument(
        "--baseline-strategy",
        default=None,
        choices=["bfs", "dfs", "random", "shortest_path", "rule_confidence"],
    )
    compare.add_argument("--device")
    compare.add_argument("--hidden-dim", type=int, default=128)
    compare.add_argument("--num-layers", type=int, default=2)
    compare.add_argument("--dropout", type=float, default=0.1)
    compare.add_argument("--max-depth", type=int, default=20)
    compare.add_argument("--max-expansions", type=int, default=20_000)
    compare.add_argument("--top-k", type=int, default=1)
    compare.add_argument(
        "--utility-mode",
        default="proof_distance",
        choices=["proof_distance", "exponential", "depth", "binary", "semantic"],
    )
    compare.add_argument("--utility-decay", type=float, default=1.0)
    compare.add_argument("--report-mode", default="guidance", choices=["guidance", "payback"])
    compare.add_argument(
        "--strategies",
        nargs="+",
        default=["bfs", "dfs", "random", "shortest_path", "rule_confidence", "gnn"],
    )
    compare.set_defaults(func=cmd_compare_benchmarks)

    trace_benchmark = sub.add_parser("trace-benchmark")
    trace_benchmark.add_argument("--benchmark", required=True)
    trace_benchmark.add_argument("--output", required=True)
    trace_benchmark.add_argument(
        "--strategy", default="bfs", choices=[s.value for s in SearchStrategy]
    )
    trace_benchmark.add_argument("--max-depth", type=int, default=20)
    trace_benchmark.add_argument("--max-expansions", type=int, default=20_000)
    trace_benchmark.add_argument("--top-k", type=int, default=1)
    trace_benchmark.add_argument(
        "--utility-mode",
        default="proof_distance",
        choices=["proof_distance", "exponential", "depth", "binary", "semantic"],
    )
    trace_benchmark.add_argument("--utility-decay", type=float, default=1.0)
    trace_benchmark.set_defaults(func=cmd_trace_benchmark)

    make_rules = sub.add_parser("make-starter-rules")
    make_rules.add_argument("--benchmark", required=True)
    make_rules.add_argument("--output", required=True)
    make_rules.add_argument("--no-inverse", action="store_true")
    make_rules.add_argument("--no-chain", action="store_true")
    make_rules.add_argument("--chain-max-rules", type=int, default=24)
    make_rules.set_defaults(func=cmd_make_starter_rules)

    mine_rules = sub.add_parser("mine-rules")
    mine_rules.add_argument("--benchmark", required=True)
    mine_rules.add_argument("--output", required=True)
    mine_rules.add_argument("--min-inverse-support", type=int, default=3)
    mine_rules.add_argument("--min-inverse-confidence", type=float, default=0.5)
    mine_rules.add_argument("--min-chain-support", type=int, default=5)
    mine_rules.add_argument("--min-chain-confidence", type=float, default=0.3)
    mine_rules.add_argument("--max-inverse-rules", type=int, default=50)
    mine_rules.add_argument("--max-chain-rules", type=int, default=100)
    mine_rules.add_argument("--algorithm", default="basic", choices=["basic", "amie"])
    mine_rules.set_defaults(func=cmd_mine_rules)

    import_rules = sub.add_parser("import-rules")
    import_rules.add_argument("--source", required=True, help="AnyBURL rule file or zip archive")
    import_rules.add_argument("--output", required=True, help="Destination rules.json file")
    import_rules.add_argument(
        "--limit", type=int, help="Optional maximum number of rules to import"
    )
    import_rules.set_defaults(func=cmd_import_rules)

    summarize_rules = sub.add_parser("summarize-rules")
    summarize_rules.add_argument("--rules", help="rules.json or rules.jsonl file")
    summarize_rules.add_argument("--benchmark", help="Benchmark file containing rules")
    summarize_rules.add_argument("--output", help="Output TSV file; defaults to stdout")
    summarize_rules.add_argument("--top-k", type=int, default=50)
    summarize_rules.set_defaults(func=cmd_summarize_rules)

    audit_rules_parser = sub.add_parser("audit-rules")
    audit_rules_parser.add_argument("--rules", help="rules.json or rules.jsonl file")
    audit_rules_parser.add_argument("--benchmark", help="Benchmark file containing rules")
    audit_rules_parser.add_argument("--output", help="Write a JSON audit report to this file")
    audit_rules_parser.add_argument(
        "--filtered-output", help="Write filtered rules to this JSON file"
    )
    audit_rules_parser.add_argument("--min-confidence", type=float, default=0.0)
    audit_rules_parser.add_argument("--min-body-length", type=int, default=0)
    audit_rules_parser.add_argument("--exclude-trivial-inverse", action="store_true")
    audit_rules_parser.set_defaults(func=cmd_audit_rules)

    validate = sub.add_parser("validate-trace")
    validate.add_argument("--trace-file", required=True)
    validate.add_argument("--benchmark")
    validate.set_defaults(func=cmd_validate_trace)

    replay = sub.add_parser("replay-trace")
    replay.add_argument("--trace-file", required=True)
    replay.set_defaults(func=cmd_replay_trace)

    search = sub.add_parser("search")
    search.add_argument(
        "--strategy", default="best_first", choices=[s.value for s in SearchStrategy]
    )
    search.add_argument(
        "--heuristic",
        default="shortest_path",
        choices=["shortest_path", "rule_confidence", "random"],
    )
    search.add_argument("--predicate", default="risk")
    search.add_argument("--args", nargs="+", default=["DrugA", "Arrhythmia"])
    search.add_argument("--max-depth", type=int, default=20)
    search.add_argument("--max-expansions", type=int, default=20_000)
    search.add_argument("--top-k", type=int, default=3)
    search.set_defaults(func=cmd_search)

    train = sub.add_parser("train")
    train.add_argument("--trace-file", required=True)
    train.add_argument("--output-model")
    train.add_argument("--epochs", type=int, default=10)
    train.add_argument("--lr", type=float, default=1e-3)
    train.add_argument("--margin", type=float, default=0.2)
    train.add_argument("--device")
    train.add_argument("--hidden-dim", type=int, default=128)
    train.add_argument("--num-layers", type=int, default=2)
    train.add_argument("--dropout", type=float, default=0.1)
    train.add_argument("--max-trace-records", type=int)
    train.add_argument(
        "--ranking-metric", default="pairwise_accuracy", choices=["pairwise_accuracy"]
    )
    train.add_argument("--aux-risk-weight", type=float, default=0.1)
    train.add_argument("--aux-prune-weight", type=float, default=0.1)
    train.add_argument("--aux-contradiction-weight", type=float, default=0.1)
    train.add_argument(
        "--utility-mode",
        default="proof_distance",
        choices=["proof_distance", "exponential", "depth", "binary", "semantic"],
    )
    train.add_argument("--utility-decay", type=float, default=1.0)
    train.set_defaults(func=cmd_train)

    iterate = sub.add_parser("iterate")
    iterate.add_argument("--iterations", type=int, default=2)
    iterate.add_argument("--device")
    iterate.add_argument("--epochs", type=int, default=5)
    iterate.add_argument("--lr", type=float, default=1e-3)
    iterate.add_argument("--margin", type=float, default=0.2)
    iterate.add_argument("--hidden-dim", type=int, default=128)
    iterate.add_argument("--num-layers", type=int, default=2)
    iterate.add_argument("--dropout", type=float, default=0.1)
    iterate.add_argument(
        "--ranking-metric", default="pairwise_accuracy", choices=["pairwise_accuracy"]
    )
    iterate.add_argument("--aux-risk-weight", type=float, default=0.1)
    iterate.add_argument("--aux-prune-weight", type=float, default=0.1)
    iterate.add_argument("--aux-contradiction-weight", type=float, default=0.1)
    iterate.add_argument(
        "--utility-mode",
        default="proof_distance",
        choices=["proof_distance", "exponential", "depth", "binary", "semantic"],
    )
    iterate.add_argument("--utility-decay", type=float, default=1.0)
    iterate.set_defaults(func=cmd_iterate)

    return parser


def cmd_iterate(args: argparse.Namespace) -> None:
    from .graph import SymbolGraphBuilder
    from .train import TrainingConfig, build_model, iterative_trace_guided_learning

    kb = build_demo_kb()
    query = Atom("risk", ("DrugA", "Arrhythmia"))
    builder = SymbolGraphBuilder(kb)
    model = build_model(
        builder, hidden_dim=args.hidden_dim, num_layers=args.num_layers, dropout=args.dropout
    )
    history = iterative_trace_guided_learning(
        kb,
        query,
        builder,
        model,
        iterations=args.iterations,
        config=TrainingConfig(
            epochs=args.epochs,
            learning_rate=args.lr,
            device=args.device,
            margin=args.margin,
            ranking_metric=args.ranking_metric,
            aux_risk_weight=args.aux_risk_weight,
            aux_prune_weight=args.aux_prune_weight,
            aux_contradiction_weight=args.aux_contradiction_weight,
        ),
        trace_utility_mode=args.utility_mode,
        trace_utility_decay=args.utility_decay,
    )
    print(
        json.dumps(
            [
                {
                    "iteration": item["iteration"],
                    "trace_size": item["trace_size"],
                    "losses": item["losses"],
                }
                for item in history
            ],
            indent=2,
        )
    )


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
