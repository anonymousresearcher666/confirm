from __future__ import annotations

import gzip
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Sequence

from .benchmark import BenchmarkQuery, SyntheticBenchmark
from .kb import Atom, KnowledgeBase, Rule


@dataclass(frozen=True)
class DatasetFiles:
    train: Path
    valid: Path | None = None
    test: Path | None = None
    rules: Path | None = None


def _parse_triple_line(line: str) -> Atom:
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        raise ValueError("Empty or comment line")
    if "\t" in stripped:
        parts = [part.strip() for part in stripped.split("\t") if part.strip()]
    else:
        parts = [part.strip() for part in stripped.split() if part.strip()]
    if len(parts) != 3:
        raise ValueError(f"Expected 3 columns in triple line, got {len(parts)}: {line!r}")
    head, relation, tail = parts
    return Atom(relation, (head, tail))


def read_triple_file(path: str | Path) -> List[Atom]:
    triples: List[Atom] = []
    source = Path(path)
    opener = gzip.open if source.suffix == ".gz" else Path.open
    with opener(source, "rt", encoding="utf-8") as handle:
        for raw_line in handle:
            stripped = raw_line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            triples.append(_parse_triple_line(stripped))
    return triples


def split_triples(
    triples: Sequence[Atom],
    *,
    seed: int = 7,
    train_ratio: float = 0.8,
    valid_ratio: float = 0.1,
) -> Dict[str, List[Atom]]:
    if train_ratio <= 0 or valid_ratio < 0 or train_ratio + valid_ratio >= 1.0:
        raise ValueError("Invalid split ratios")
    shuffled = list(triples)
    rng = random.Random(seed)
    rng.shuffle(shuffled)
    total = len(shuffled)
    train_end = int(total * train_ratio)
    valid_end = int(total * (train_ratio + valid_ratio))
    return {
        "train": shuffled[:train_end],
        "valid": shuffled[train_end:valid_end],
        "test": shuffled[valid_end:],
    }


def _atom_from_payload(payload: Dict) -> Atom:
    return Atom(predicate=payload["predicate"], args=tuple(payload["args"]))


def read_rule_file(path: str | Path) -> List[Rule]:
    payload = Path(path).read_text(encoding="utf-8").strip()
    if not payload:
        return []
    if payload.startswith("["):
        data = json.loads(payload)
    else:
        data = [json.loads(line) for line in payload.splitlines() if line.strip()]
    rules: List[Rule] = []
    for item in data:
        rules.append(
            Rule(
                name=item["name"],
                head=_atom_from_payload(item["head"]),
                body=tuple(_atom_from_payload(atom) for atom in item.get("body", [])),
                confidence=float(item.get("confidence", 1.0)),
            )
        )
    return rules


def _safe_entity_name(index: int, atom: Atom, sample: int) -> str:
    return f"{atom.args[0]}__neg{index}_{sample}"


def build_benchmark_from_triple_sets(
    *,
    train_triples: Sequence[Atom],
    valid_triples: Sequence[Atom] | None = None,
    test_triples: Sequence[Atom] | None = None,
    rules: Sequence[Rule] | None = None,
    dataset_name: str = "dataset",
    seed: int = 7,
    negatives_per_positive: int = 1,
    include_validation_facts: bool = True,
) -> SyntheticBenchmark:
    valid_triples = list(valid_triples or [])
    test_triples = list(test_triples or [])
    rules = list(rules or [])

    facts = list(train_triples)
    if include_validation_facts:
        seen_facts = set(facts)
        for atom in valid_triples:
            if atom in seen_facts:
                continue
            facts.append(atom)
            seen_facts.add(atom)

    kb = KnowledgeBase(facts=facts, rules=rules)
    rng = random.Random(seed)
    entities = kb.entities
    queries: List[BenchmarkQuery] = []

    for index, triple in enumerate(test_triples):
        queries.append(
            BenchmarkQuery(
                query=triple,
                expected=True,
                family=f"{dataset_name}_test_positive",
                split="test",
                difficulty=1,
                metadata={"source": "test_split", "index": index},
            )
        )
        if not entities:
            continue
        for neg_idx in range(negatives_per_positive):
            corrupt_subject = rng.random() < 0.5
            if corrupt_subject:
                corrupted = Atom(
                    triple.predicate,
                    (_safe_entity_name(index, triple, neg_idx), triple.args[1]),
                )
            else:
                corrupted = Atom(
                    triple.predicate,
                    (triple.args[0], _safe_entity_name(index, triple, neg_idx)),
                )
            queries.append(
                BenchmarkQuery(
                    query=corrupted,
                    expected=False,
                    family=f"{dataset_name}_test_negative",
                    split="test",
                    difficulty=1,
                    metadata={"source": "negative_corruption", "index": index, "slot": neg_idx},
                )
            )

    metadata = {
        "dataset_name": dataset_name,
        "train_triples": len(train_triples),
        "valid_triples": len(valid_triples),
        "test_triples": len(test_triples),
        "rule_count": len(rules),
        "negatives_per_positive": negatives_per_positive,
        "include_validation_facts": include_validation_facts,
    }
    return SyntheticBenchmark(kb=kb, queries=queries, metadata=metadata)


def build_benchmark_from_dataset_files(
    *,
    train_path: str | Path,
    valid_path: str | Path | None = None,
    test_path: str | Path | None = None,
    rules_path: str | Path | None = None,
    dataset_name: str = "dataset",
    seed: int = 7,
    negatives_per_positive: int = 1,
    include_validation_facts: bool = True,
) -> SyntheticBenchmark:
    train_triples = read_triple_file(train_path)
    valid_triples = read_triple_file(valid_path) if valid_path else []
    test_triples = read_triple_file(test_path) if test_path else []
    rules = read_rule_file(rules_path) if rules_path else []
    return build_benchmark_from_triple_sets(
        train_triples=train_triples,
        valid_triples=valid_triples,
        test_triples=test_triples,
        rules=rules,
        dataset_name=dataset_name,
        seed=seed,
        negatives_per_positive=negatives_per_positive,
        include_validation_facts=include_validation_facts,
    )


def build_benchmark_from_single_edge_file(
    *,
    edge_path: str | Path,
    dataset_name: str = "dataset",
    seed: int = 7,
    negatives_per_positive: int = 1,
    train_ratio: float = 0.8,
    valid_ratio: float = 0.1,
    rules_path: str | Path | None = None,
    include_validation_facts: bool = True,
) -> SyntheticBenchmark:
    triples = read_triple_file(edge_path)
    splits = split_triples(triples, seed=seed, train_ratio=train_ratio, valid_ratio=valid_ratio)
    rules = read_rule_file(rules_path) if rules_path else []
    return build_benchmark_from_triple_sets(
        train_triples=splits["train"],
        valid_triples=splits["valid"],
        test_triples=splits["test"],
        rules=rules,
        dataset_name=dataset_name,
        seed=seed,
        negatives_per_positive=negatives_per_positive,
        include_validation_facts=include_validation_facts,
    )


def discover_dataset_files(root: str | Path) -> DatasetFiles:
    root_path = Path(root)
    train_candidates = ["train.txt", "train.tsv", "train.nt"]
    valid_candidates = ["valid.txt", "valid.tsv", "dev.txt", "dev.tsv", "valid.nt"]
    test_candidates = ["test.txt", "test.tsv", "test.nt"]
    rules_candidates = ["rules.json", "rules.jsonl", "manual_rules.json", "manual_rules.jsonl"]

    def first_existing(names: Sequence[str]) -> Path | None:
        for name in names:
            candidate = root_path / name
            if candidate.exists():
                return candidate
        return None

    train = first_existing(train_candidates)
    if train is None:
        raise FileNotFoundError(f"Could not find a train file in {root_path}")
    valid = first_existing(valid_candidates)
    test = first_existing(test_candidates)
    rules = first_existing(rules_candidates)
    return DatasetFiles(train=train, valid=valid, test=test, rules=rules)
