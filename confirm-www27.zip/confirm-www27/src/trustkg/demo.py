from __future__ import annotations

from .kb import Atom, KnowledgeBase, Rule


def build_demo_kb() -> KnowledgeBase:
    facts = [
        Atom("chemicallySimilarTo", ("DrugA", "DrugB")),
        Atom("treats", ("DrugB", "ConditionX")),
        Atom("causes", ("DrugB", "Arrhythmia")),
        Atom("causes", ("DrugC", "Nausea")),
        Atom("interactsWith", ("DrugA", "DrugC")),
    ]
    rules = [
        Rule(
            name="risk_by_similarity",
            head=Atom("risk", ("?D", "?S")),
            body=(Atom("chemicallySimilarTo", ("?D", "?D2")), Atom("risk", ("?D2", "?S"))),
            confidence=0.95,
        ),
        Rule(
            name="risk_from_cause",
            head=Atom("risk", ("?D", "?S")),
            body=(Atom("causes", ("?D", "?S")),),
            confidence=0.9,
        ),
        Rule(
            name="risk_from_interaction",
            head=Atom("risk", ("?D", "?S")),
            body=(Atom("interactsWith", ("?D", "?X")), Atom("risk", ("?X", "?S"))),
            confidence=0.7,
        ),
    ]
    return KnowledgeBase(facts=facts, rules=rules)
