from __future__ import annotations

from .runtime import TORCH_AVAILABLE, require_torch, torch


def get_device(preferred: str | None = None) -> torch.device:
    if not TORCH_AVAILABLE:
        require_torch("Device selection")
    if preferred:
        preferred = preferred.lower()
        if preferred == "cuda" and torch.cuda.is_available():
            return torch.device("cuda")
        if preferred == "mps" and torch.backends.mps.is_available():
            return torch.device("mps")
        if preferred == "cpu":
            return torch.device("cpu")
        raise ValueError(f"Requested device '{preferred}' is not available.")

    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")
