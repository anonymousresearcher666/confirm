"""Boundary-first downstream authorization for certified KG reasoning.

NO machine-learning score participates in the authorization decision.
The verifier and pinned provenance of trusted inputs must come from the
trusted execution boundary, never from a producer-provided JSON field.

This module is intentionally small and independent of the reasoner.
It consumes trusted verifier output, not an untrusted status string
passed directly by a proposer.

Safety contract (conditional on an honest local verifier and the pinned
trusted source): candidate-only / unknown / unverified evidence cannot
authorize side-effecting actions; HYPOTHESIZED can be quarantined for
display with an explicit non-authoritative label.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Consumption(str, Enum):
    EXECUTE = "execute"
    QUARANTINE = "quarantine"
    REJECT = "reject"


class Intent(str, Enum):
    SIDE_EFFECT = "side_effect"
    RESEARCH_DISPLAY = "research_display"


@dataclass(frozen=True)
class IndependentProof:
    # Must be constructed from a trusted verifier's result and local
    # externally pinned snapshot. Do not deserialize these fields from
    # the potentially hostile search producer.
    claim_status: str
    search_replayed: bool
    verdict_rederived: bool
    proof_is_complete: bool
    full_rule_snapshot_sha256: str
    pinned_snapshot_sha256: str
    trusted_source_provenance_ok: bool


@dataclass(frozen=True)
class Admission:
    decision: Consumption
    reason: str
    authorizes_side_effect: bool
    informational_only: bool


def authorize(proof: IndependentProof, *, intent: Intent,
              candidate_risk_score: float | None = None) -> Admission:
    """Fail-closed downstream trust contract.

    The candidate score is deliberately ignored. It may be shown as
    exploratory metadata but must never upgrade HYPOTHESIZED or a failed
    verifier into authorization.
    """
    if not isinstance(intent, Intent):
        raise ValueError("unknown downstream intent")
    if proof.claim_status not in {"PROVEN", "HYPOTHESIZED", "REFUTED"}:
        return Admission(Consumption.REJECT, "invalid_status", False, False)
    if proof.claim_status == "REFUTED":
        return Admission(Consumption.REJECT, "independently_refuted", False, False)
    if not (
        proof.search_replayed and proof.verdict_rederived and
        proof.proof_is_complete and proof.full_rule_snapshot_sha256
        and proof.pinned_snapshot_sha256 and
        proof.full_rule_snapshot_sha256 == proof.pinned_snapshot_sha256
    ):
        return Admission(Consumption.QUARANTINE, "missing_independent_attestation",
                         False, False)
    if proof.claim_status == "PROVEN":
        if not proof.trusted_source_provenance_ok:
            return Admission(Consumption.QUARANTINE, "unattested_trusted_provenance",
                             False, False)
        if intent is Intent.RESEARCH_DISPLAY:
            return Admission(Consumption.QUARANTINE, "verified_trusted_read_only",
                             False, True)
        return Admission(Consumption.EXECUTE, "verified_trusted_proof", True, False)
    # Every HYPOTHESIZED contains an untrusted-rule proof. A score cannot
    # change its authorization class even if score=0.0.
    if intent is Intent.RESEARCH_DISPLAY:
        return Admission(Consumption.QUARANTINE, "non_authoritative_candidate_display",
                         False, True)
    return Admission(Consumption.QUARANTINE, "candidate_requires_independent_promotion",
                     False, False)


def unsafe_accept_all(status: str) -> bool:
    """Explicitly unsafe reference consumer, for comparative measurement."""
    return status in {"PROVEN", "HYPOTHESIZED"}
