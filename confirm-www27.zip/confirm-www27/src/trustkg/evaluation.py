from __future__ import annotations

import csv
import json
import math
import shutil
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from statistics import mean
from time import perf_counter
from typing import Dict, List, Sequence

from .benchmark import BenchmarkQuery, SyntheticBenchmark
from .graph import SymbolGraphBuilder
from .heuristics import rule_confidence_heuristic, shortest_path_heuristic
from .kb import Atom
from .reasoner import SearchBundle, SearchStrategy, SymbolicReasoner
from .runtime import TORCH_AVAILABLE

BASELINE_STRATEGIES = ("bfs", "dfs", "random", "shortest_path", "rule_confidence")

SUMMARY_COLUMNS = [
    "dataset",
    "strategy",
    "queries",
    "proofs_found",
    "false_positives",
    "verified_precision",
    "proof_recall",
    "mean_time_to_first_proof",
    "mean_expanded_states",
    "mean_generated_states",
    "mean_failed_branches",
    "mean_depth_reached",
    "success_rate",
    "branch_ranking_accuracy",
    "branch_ranking_pairs",
    "branch_ranking_frontiers",
    "warning",
]


@dataclass
class QueryEvaluationRow:
    strategy: str
    query_index: int
    query: Dict
    expected: bool
    success: bool
    time_seconds: float
    expanded_states: int
    generated_states: int
    visited_states: int
    proof_length: int
    failed_branches: int
    max_depth_reached: int
    verified: bool


def _strategy_to_run(strategy: str):
    if strategy in ("bfs", "dfs", "random"):
        return SearchStrategy(strategy), None
    if strategy == "shortest_path":
        return SearchStrategy.BEST_FIRST, shortest_path_heuristic
    if strategy == "rule_confidence":
        return SearchStrategy.BEST_FIRST, rule_confidence_heuristic
    if strategy == "gnn":
        return SearchStrategy.BEST_FIRST, None
    raise ValueError(f"Unknown strategy '{strategy}'")


def _serialize_atom(atom: Atom) -> Dict:
    return {"predicate": atom.predicate, "args": list(atom.args)}


def _format_summary_value(value) -> str:
    if isinstance(value, float):
        return f"{value:.4f}"
    return str(value)


def _summary_rows(report: Dict) -> List[Dict]:
    return list(report.get("summaries", []))


def compute_cost_analysis(
    report: Dict,
    *,
    upfront_cost_seconds: float = 0.0,
    baseline_strategy: str | None = None,
) -> Dict:
    summaries = list(report.get("summaries", []))
    query_count = int(report.get("query_count", 0))
    gnn_summary = next((row for row in summaries if row.get("strategy") == "gnn"), None)
    baseline_summaries = [
        row for row in summaries if row.get("strategy") != "gnn" and row.get("queries", 0)
    ]
    selected_baseline = None
    if baseline_strategy is not None:
        selected_baseline = next(
            (row for row in baseline_summaries if row.get("strategy") == baseline_strategy), None
        )
    if selected_baseline is None and baseline_summaries:
        selected_baseline = min(
            baseline_summaries,
            key=lambda row: (
                float(row.get("mean_time_to_first_proof", float("inf"))),
                -float(row.get("proof_recall", 0.0)),
                row.get("strategy", ""),
            ),
        )

    if selected_baseline is None or gnn_summary is None:
        return {
            "baseline_strategy": baseline_strategy,
            "selected_baseline": selected_baseline,
            "gnn_summary": gnn_summary,
            "upfront_cost_seconds": upfront_cost_seconds,
            "break_even_queries": None,
        }

    baseline_time = float(selected_baseline.get("mean_time_to_first_proof", 0.0))
    gnn_time = float(gnn_summary.get("mean_time_to_first_proof", 0.0))
    per_query_savings = baseline_time - gnn_time
    if per_query_savings <= 0:
        break_even_queries = None
    else:
        break_even_queries = (
            math.ceil(upfront_cost_seconds / per_query_savings) if upfront_cost_seconds > 0 else 0
        )

    classical_total = baseline_time * query_count
    gnn_total = upfront_cost_seconds + (gnn_time * query_count)
    amortized_gnn_per_query = (gnn_total / query_count) if query_count > 0 else None
    amortized_classical_per_query = baseline_time

    return {
        "baseline_strategy": selected_baseline.get("strategy"),
        "baseline_mean_time_to_first_proof_seconds": baseline_time,
        "gnn_mean_time_to_first_proof_seconds": gnn_time,
        "per_query_savings_seconds": per_query_savings,
        "query_count": query_count,
        "upfront_cost_seconds": upfront_cost_seconds,
        "classical_total_time_seconds": classical_total,
        "gnn_total_time_seconds": gnn_total,
        "amortized_classical_time_per_query_seconds": amortized_classical_per_query,
        "amortized_gnn_time_per_query_seconds": amortized_gnn_per_query,
        "break_even_queries": break_even_queries,
        "selected_baseline": selected_baseline,
        "gnn_summary": gnn_summary,
    }


def _attach_branch_ranking_metrics(
    strategy_summaries: List[Dict], training_metrics: Dict | None
) -> None:
    if not training_metrics:
        return
    for row in strategy_summaries:
        if row.get("strategy") != "gnn":
            continue
        row["branch_ranking_accuracy"] = training_metrics.get("accuracy", 0.0)
        row["branch_ranking_pairs"] = training_metrics.get("pair_count", 0)
        row["branch_ranking_frontiers"] = training_metrics.get("frontier_count", 0)


def result_directory(root: str | Path, dataset_name: str, current_date: str | None = None) -> Path:
    stamp = current_date or date.today().isoformat()
    return Path(root) / f"{dataset_name}-{stamp}"


def write_experiment_result_bundle(
    root: str | Path,
    dataset_name: str,
    report: Dict,
    *,
    benchmark: SyntheticBenchmark | None = None,
    trace_file: str | Path | None = None,
    model_file: str | Path | None = None,
    current_date: str | None = None,
) -> Path:
    result_dir = result_directory(root, dataset_name, current_date=current_date)
    result_dir.mkdir(parents=True, exist_ok=True)
    (result_dir / "results.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    if benchmark is not None:
        from .benchmark import _rule_to_dict, benchmark_to_dict

        (result_dir / "benchmark.json").write_text(
            json.dumps(benchmark_to_dict(benchmark), indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        (result_dir / "rules.json").write_text(
            json.dumps(
                [_rule_to_dict(rule) for rule in benchmark.kb.rules], indent=2, sort_keys=True
            )
            + "\n",
            encoding="utf-8",
        )
    if trace_file is not None:
        shutil.copy2(str(trace_file), result_dir / "traces.jsonl")
    if model_file is not None:
        shutil.copy2(str(model_file), result_dir / Path(model_file).name)
    write_evaluation_summary_csv(report, result_dir / "summary.csv")
    write_evaluation_summary_markdown(report, result_dir / "summary.md")
    return result_dir


def evaluate_benchmark_suite(
    benchmarks: Dict[str, SyntheticBenchmark],
    *,
    strategies: Sequence[str] = BASELINE_STRATEGIES + ("gnn",),
    max_depth: int = 20,
    max_expansions: int = 20_000,
    top_k: int = 1,
    device: str | None = None,
    model_checkpoint: str | None = None,
    bootstrap_train: bool = True,
    bootstrap_strategy: str = "rule_confidence",
    training_epochs: int = 4,
    training_lr: float = 1e-3,
    training_margin: float = 0.2,
    training_ranking_metric: str = "pairwise_accuracy",
    aux_risk_weight: float = 0.1,
    aux_prune_weight: float = 0.1,
    aux_contradiction_weight: float = 0.1,
    hidden_dim: int = 128,
    num_layers: int = 2,
    dropout: float = 0.1,
    trace_utility_mode: str = "proof_distance",
    trace_utility_decay: float = 1.0,
    baseline_strategy: str | None = None,
    include_cost_analysis: bool = False,
    upfront_cost_seconds: float | None = None,
) -> Dict:
    suite_reports: Dict[str, Dict] = {}
    suite_summaries: List[Dict] = []
    suite_rows: List[Dict] = []

    for dataset_name, benchmark in benchmarks.items():
        report = evaluate_benchmark(
            benchmark,
            strategies=strategies,
            max_depth=max_depth,
            max_expansions=max_expansions,
            top_k=top_k,
            device=device,
            model_checkpoint=model_checkpoint,
            bootstrap_train=bootstrap_train,
            bootstrap_strategy=bootstrap_strategy,
            training_epochs=training_epochs,
            training_lr=training_lr,
            training_margin=training_margin,
            training_ranking_metric=training_ranking_metric,
            aux_risk_weight=aux_risk_weight,
            aux_prune_weight=aux_prune_weight,
            aux_contradiction_weight=aux_contradiction_weight,
            hidden_dim=hidden_dim,
            num_layers=num_layers,
            dropout=dropout,
            trace_utility_mode=trace_utility_mode,
            trace_utility_decay=trace_utility_decay,
            baseline_strategy=baseline_strategy,
            include_cost_analysis=include_cost_analysis,
            upfront_cost_seconds=upfront_cost_seconds,
        )
        suite_reports[dataset_name] = report
        suite_rows.extend([dict(row, dataset=dataset_name) for row in report.get("rows", [])])
        suite_summaries.extend(
            [dict(summary, dataset=dataset_name) for summary in report.get("summaries", [])]
        )

    return {
        "benchmarks": suite_reports,
        "query_count": sum(report.get("query_count", 0) for report in suite_reports.values()),
        "rows": suite_rows,
        "summaries": suite_summaries,
    }


def write_evaluation_summary_csv(report: Dict, path: str | Path) -> None:
    rows = _summary_rows(report)
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=SUMMARY_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in SUMMARY_COLUMNS})


def write_evaluation_summary_markdown(report: Dict, path: str | Path) -> None:
    rows = _summary_rows(report)
    lines = []
    lines.append("| " + " | ".join(SUMMARY_COLUMNS) + " |")
    lines.append("| " + " | ".join(["---"] * len(SUMMARY_COLUMNS)) + " |")
    for row in rows:
        lines.append(
            "| "
            + " | ".join(_format_summary_value(row.get(column, "")) for column in SUMMARY_COLUMNS)
            + " |"
        )
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_suite_summary_csv(report: Dict, path: str | Path) -> None:
    rows = _summary_rows(report)
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=SUMMARY_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in SUMMARY_COLUMNS})


def write_suite_summary_markdown(report: Dict, path: str | Path) -> None:
    rows = _summary_rows(report)
    lines = []
    lines.append("| " + " | ".join(SUMMARY_COLUMNS) + " |")
    lines.append("| " + " | ".join(["---"] * len(SUMMARY_COLUMNS)) + " |")
    for row in rows:
        lines.append(
            "| "
            + " | ".join(_format_summary_value(row.get(column, "")) for column in SUMMARY_COLUMNS)
            + " |"
        )
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def _row_from_bundle(
    strategy: str,
    query_index: int,
    benchmark_query: BenchmarkQuery,
    bundle: SearchBundle,
    elapsed: float,
) -> QueryEvaluationRow:
    result = bundle.results[0]
    failed_branches = sum(1 for record in bundle.trace if record.outcome in {"dead_end", "timeout"})
    max_depth_reached = max((record.depth for record in bundle.trace), default=0)
    return QueryEvaluationRow(
        strategy=strategy,
        query_index=query_index,
        query=_serialize_atom(benchmark_query.query),
        expected=benchmark_query.expected,
        success=result.success,
        time_seconds=elapsed,
        expanded_states=result.expanded_states,
        generated_states=result.generated_states,
        visited_states=result.visited_states,
        proof_length=len(result.proof_steps),
        failed_branches=failed_branches,
        max_depth_reached=max_depth_reached,
        verified=result.success,
    )


def evaluate_benchmark(
    benchmark: SyntheticBenchmark,
    *,
    strategies: Sequence[str] = BASELINE_STRATEGIES + ("gnn",),
    max_depth: int = 20,
    max_expansions: int = 20_000,
    top_k: int = 1,
    device: str | None = None,
    model_checkpoint: str | None = None,
    bootstrap_train: bool = True,
    bootstrap_strategy: str = "rule_confidence",
    training_epochs: int = 4,
    training_lr: float = 1e-3,
    training_margin: float = 0.2,
    training_ranking_metric: str = "pairwise_accuracy",
    aux_risk_weight: float = 0.1,
    aux_prune_weight: float = 0.1,
    aux_contradiction_weight: float = 0.1,
    hidden_dim: int = 128,
    num_layers: int = 2,
    dropout: float = 0.1,
    trace_utility_mode: str = "proof_distance",
    trace_utility_decay: float = 1.0,
    baseline_strategy: str | None = None,
    include_cost_analysis: bool = False,
    upfront_cost_seconds: float | None = None,
) -> Dict:
    kb = benchmark.kb
    reasoner = SymbolicReasoner(kb, max_depth=max_depth, max_expansions=max_expansions)
    builder = SymbolGraphBuilder(kb)
    rows: List[QueryEvaluationRow] = []
    strategy_summaries: List[Dict] = []
    gnn_training_metrics = None

    gnn_heuristic = None
    if "gnn" in strategies:
        if not TORCH_AVAILABLE:
            gnn_heuristic = None
        else:
            from .device import get_device
            from .train import (
                TrainingConfig,
                build_model,
                load_model_checkpoint,
                make_model_heuristic,
                train_from_traces_with_metrics,
            )

            if model_checkpoint is not None:
                model, metadata = load_model_checkpoint(
                    model_checkpoint, map_location=get_device(device)
                )
                gnn_training_metrics = metadata.get("branch_ranking") or metadata.get(
                    "pairwise_ranking"
                )
                gnn_heuristic = make_model_heuristic(model, builder, device=device)
            elif bootstrap_train:
                bootstrap_records = []
                bootstrap_search_strategy, bootstrap_heuristic = _strategy_to_run(
                    bootstrap_strategy
                )
                for benchmark_query in benchmark.queries:
                    bundle = reasoner.search(
                        benchmark_query.query,
                        strategy=bootstrap_search_strategy,
                        heuristic=bootstrap_heuristic,
                        top_k=top_k,
                        collect_trace=True,
                        utility_mode=trace_utility_mode,
                        utility_decay=trace_utility_decay,
                    )
                    assert isinstance(bundle, SearchBundle)
                    bootstrap_records.extend(bundle.trace)
                model = build_model(
                    builder, hidden_dim=hidden_dim, num_layers=num_layers, dropout=dropout
                )
                training_report = train_from_traces_with_metrics(
                    model,
                    builder,
                    bootstrap_records,
                    TrainingConfig(
                        epochs=training_epochs,
                        learning_rate=training_lr,
                        margin=training_margin,
                        device=device,
                        ranking_metric=training_ranking_metric,
                        aux_risk_weight=aux_risk_weight,
                        aux_prune_weight=aux_prune_weight,
                        aux_contradiction_weight=aux_contradiction_weight,
                    ),
                )
                gnn_training_metrics = training_report.get("pairwise_ranking")
                gnn_heuristic = make_model_heuristic(model, builder, device=device)
            else:
                raise RuntimeError(
                    "GNN evaluation requested but no checkpoint provided and bootstrap_train is disabled."
                )
        if gnn_heuristic is None and TORCH_AVAILABLE:
            raise RuntimeError("Failed to construct GNN heuristic.")

    for strategy in strategies:
        if strategy == "gnn":
            continue
        search_strategy, heuristic = _strategy_to_run(strategy)
        for query_index, benchmark_query in enumerate(benchmark.queries):
            start = perf_counter()
            bundle = reasoner.search(
                benchmark_query.query,
                strategy=search_strategy,
                heuristic=heuristic,
                top_k=top_k,
                collect_trace=True,
                utility_mode=trace_utility_mode,
                utility_decay=trace_utility_decay,
            )
            elapsed = perf_counter() - start
            assert isinstance(bundle, SearchBundle)
            rows.append(_row_from_bundle(strategy, query_index, benchmark_query, bundle, elapsed))

    if "gnn" in strategies and TORCH_AVAILABLE:
        if gnn_heuristic is None:
            strategy_summaries.append(
                {
                    "strategy": "gnn",
                    "queries": len(benchmark.queries),
                    "proofs_found": 0,
                    "false_positives": 0,
                    "verified_precision": 0.0,
                    "proof_recall": 0.0,
                    "mean_time_to_first_proof": 0.0,
                    "mean_expanded_states": 0.0,
                    "mean_generated_states": 0.0,
                    "mean_failed_branches": 0.0,
                    "mean_depth_reached": 0.0,
                    "success_rate": 0.0,
                    "warning": "skipped because no checkpoint or bootstrap training produced a model",
                }
            )
            return {
                "benchmark_metadata": benchmark.metadata,
                "query_count": len(benchmark.queries),
                "rows": [row.__dict__ for row in rows],
                "summaries": strategy_summaries,
                "training_metrics": None,
                "branch_ranking": None,
                "report_mode": "guidance",
            }
        for query_index, benchmark_query in enumerate(benchmark.queries):
            start = perf_counter()
            bundle = reasoner.search(
                benchmark_query.query,
                strategy=SearchStrategy.BEST_FIRST,
                heuristic=gnn_heuristic,
                top_k=top_k,
                collect_trace=True,
                utility_mode=trace_utility_mode,
                utility_decay=trace_utility_decay,
            )
            elapsed = perf_counter() - start
            assert isinstance(bundle, SearchBundle)
            rows.append(_row_from_bundle("gnn", query_index, benchmark_query, bundle, elapsed))

    for strategy in strategies:
        strategy_rows = [row for row in rows if row.strategy == strategy]
        if not strategy_rows:
            continue
        successful_rows = [row for row in strategy_rows if row.success]
        correct_successes = [row for row in strategy_rows if row.success and row.expected]
        false_positives = [row for row in strategy_rows if row.success and not row.expected]
        positives = [row for row in strategy_rows if row.expected]
        precision = len(correct_successes) / max(1, len(successful_rows))
        recall = len(correct_successes) / max(1, len(positives))
        strategy_summaries.append(
            {
                "strategy": strategy,
                "queries": len(strategy_rows),
                "proofs_found": len(correct_successes),
                "false_positives": len(false_positives),
                "verified_precision": precision,
                "proof_recall": recall,
                "mean_time_to_first_proof": mean([row.time_seconds for row in successful_rows])
                if successful_rows
                else 0.0,
                "mean_expanded_states": mean([row.expanded_states for row in strategy_rows]),
                "mean_generated_states": mean([row.generated_states for row in strategy_rows]),
                "mean_failed_branches": mean([row.failed_branches for row in strategy_rows]),
                "mean_depth_reached": mean([row.max_depth_reached for row in strategy_rows]),
                "success_rate": len(successful_rows) / max(1, len(strategy_rows)),
            }
        )

    if "gnn" in strategies and not TORCH_AVAILABLE:
        strategy_summaries.append(
            {
                "strategy": "gnn",
                "queries": len(benchmark.queries),
                "proofs_found": 0,
                "false_positives": 0,
                "verified_precision": 0.0,
                "proof_recall": 0.0,
                "mean_time_to_first_proof": 0.0,
                "mean_expanded_states": 0.0,
                "mean_generated_states": 0.0,
                "mean_failed_branches": 0.0,
                "mean_depth_reached": 0.0,
                "success_rate": 0.0,
                "warning": "skipped because torch is not installed",
            }
        )

    _attach_branch_ranking_metrics(strategy_summaries, gnn_training_metrics)

    report_mode = "payback" if include_cost_analysis else "guidance"
    report: Dict = {
        "benchmark_metadata": benchmark.metadata,
        "query_count": len(benchmark.queries),
        "rows": [row.__dict__ for row in rows],
        "summaries": strategy_summaries,
        "training_metrics": gnn_training_metrics,
        "branch_ranking": gnn_training_metrics,
        "trace_utility_mode": trace_utility_mode,
        "trace_utility_decay": trace_utility_decay,
        "baseline_strategy": baseline_strategy,
        "report_mode": report_mode,
    }
    if include_cost_analysis and upfront_cost_seconds is not None:
        report["cost_analysis"] = compute_cost_analysis(
            report,
            upfront_cost_seconds=upfront_cost_seconds,
            baseline_strategy=baseline_strategy,
        )
    return {
        **report,
    }
