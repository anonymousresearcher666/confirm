"""Reproducible experiment runners for the three-paper release."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import platform
import random
import sys
from collections import Counter
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any, Callable

import numpy as np

from .benchmark import SyntheticBenchmark, build_synthetic_benchmark, write_benchmark
from .datasets import discover_dataset_files, read_triple_file
from .evaluation import (
    evaluate_benchmark,
    write_evaluation_summary_csv,
    write_evaluation_summary_markdown,
)
from .kb import Atom, KnowledgeBase, Rule
from .reasoner import SearchBundle, SearchStrategy, SymbolicReasoner
from .rules import audit_rules, mine_rules_from_benchmark, write_rule_summary, write_rules_json
from .runtime import TORCH_AVAILABLE
from .traces import write_trace_records
from .trust import (
    CANDIDATE,
    REFUTED,
    AuditRecord,
    CertifiedReasoner,
    HarmTable,
    Schema,
    SequentialEvidenceMonitor,
    TrustContext,
    TrustState,
    audit_answers,
    build_functionality_attack_suite,
)


class ExperimentRun:
    def __init__(
        self, paper: str, config: dict[str, Any], results_root: str | Path, name: str | None = None
    ) -> None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        run_name = name or str(config.get("name", "run"))
        self.path = Path(results_root) / paper / f"{run_name}-{stamp}"
        self.path.mkdir(parents=True, exist_ok=False)
        self.paper = paper
        self.config = config
        self.started = perf_counter()
        self.write_json("config.json", config)

    def write_json(self, name: str, value: Any) -> None:
        (self.path / name).write_text(
            json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )

    def write_markdown(self, name: str, content: str) -> None:
        (self.path / name).write_text(content.rstrip() + "\n", encoding="utf-8")

    def finish(self, metrics: dict[str, Any], artifacts: list[str]) -> Path:
        self.write_json("metrics.json", metrics)
        manifest = {
            "paper": self.paper,
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "duration_seconds": round(perf_counter() - self.started, 6),
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "torch_available": TORCH_AVAILABLE,
            "artifacts": sorted(
                set(artifacts + ["config.json", "metrics.json", "manifest.json", "summary.md"])
            ),
        }
        self.write_json("manifest.json", manifest)
        return self.path


def load_config(path: str | Path) -> dict[str, Any]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Experiment configuration must be a JSON object")
    return payload


def _synthetic_benchmark(config: dict[str, Any]) -> SyntheticBenchmark:
    source = dict(config.get("synthetic", {}))
    return build_synthetic_benchmark(
        seed=int(source.get("seed", config.get("seed", 7))),
        num_instances=int(source.get("num_instances", 8)),
        chain_length=int(source.get("chain_length", 3)),
        distractors_per_step=int(source.get("distractors_per_step", 1)),
        include_pathway_proofs=bool(source.get("include_pathway_proofs", True)),
        negatives_per_instance=int(source.get("negatives_per_instance", 1)),
    )


def _search_settings(config: dict[str, Any]) -> tuple[int, int]:
    search = dict(config.get("search", {}))
    return int(search.get("max_depth", 8)), int(search.get("max_expansions", 5_000))


def _collect_traces(benchmark: SyntheticBenchmark, max_depth: int, max_expansions: int) -> list:
    reasoner = SymbolicReasoner(benchmark.kb, max_depth=max_depth, max_expansions=max_expansions)
    traces = []
    for item in benchmark.queries:
        bundle = reasoner.search(
            item.query, strategy=SearchStrategy.BEST_FIRST, collect_trace=True, top_k=1
        )
        assert isinstance(bundle, SearchBundle)
        traces.extend(bundle.trace)
    return traces


def _paper1(config: dict[str, Any], run: ExperimentRun) -> tuple[dict[str, Any], list[str]]:
    benchmark = _synthetic_benchmark(config)
    max_depth, max_expansions = _search_settings(config)
    write_benchmark(run.path / "benchmark.json", benchmark)
    traces = _collect_traces(benchmark, max_depth, max_expansions)
    write_trace_records(run.path / "traces.jsonl", traces)
    evaluation = dict(config.get("evaluation", {}))
    strategies = list(evaluation.get("strategies", ["bfs", "rule_confidence"]))
    if TORCH_AVAILABLE and bool(evaluation.get("include_gnn", True)):
        strategies.append("gnn")
    report = evaluate_benchmark(
        benchmark,
        strategies=strategies,
        max_depth=max_depth,
        max_expansions=max_expansions,
        top_k=1,
        bootstrap_train=TORCH_AVAILABLE,
        training_epochs=int(evaluation.get("training_epochs", 2)),
        hidden_dim=int(evaluation.get("hidden_dim", 64)),
        num_layers=int(evaluation.get("num_layers", 2)),
    )
    run.write_json("evaluation.json", report)
    write_evaluation_summary_csv(report, run.path / "summary.csv")
    write_evaluation_summary_markdown(report, run.path / "evaluation.md")
    summary = "\n".join(
        [
            "# Paper 1 Run",
            "",
            f"- Queries: {len(benchmark.queries)}",
            f"- Trace records: {len(traces)}",
            f"- Strategies: {', '.join(strategies)}",
            f"- GNN executed: {'yes' if 'gnn' in strategies else 'no (torch unavailable or disabled)'}",
            "",
            "See `evaluation.md` for strategy metrics.",
        ]
    )
    run.write_markdown("summary.md", summary)
    return {
        "query_count": len(benchmark.queries),
        "trace_records": len(traces),
        "strategies": strategies,
        "evaluation": report.get("summaries", []),
    }, ["benchmark.json", "traces.jsonl", "evaluation.json", "summary.csv", "evaluation.md"]


def _paper2(config: dict[str, Any], run: ExperimentRun) -> tuple[dict[str, Any], list[str]]:
    benchmark = _synthetic_benchmark(config)
    write_benchmark(run.path / "benchmark.json", benchmark)
    mining = dict(config.get("mining", {}))
    rules = mine_rules_from_benchmark(
        benchmark,
        min_inverse_support=int(mining.get("min_inverse_support", 1)),
        min_inverse_confidence=float(mining.get("min_inverse_confidence", 0.0)),
        min_chain_support=int(mining.get("min_chain_support", 1)),
        min_chain_confidence=float(mining.get("min_chain_confidence", 0.0)),
        max_inverse_rules=int(mining.get("max_inverse_rules", 50)),
        max_chain_rules=int(mining.get("max_chain_rules", 50)),
        algorithm=str(mining.get("algorithm", "basic")),
    )
    write_rules_json(run.path / "rules.json", rules)
    write_rule_summary(run.path / "rules.tsv", rules, top_k=int(mining.get("summary_top_k", 30)))
    audit = audit_rules(rules, min_confidence=float(mining.get("audit_min_confidence", 0.0)))
    run.write_json("rule_audit.json", audit)
    max_depth, max_expansions = _search_settings(config)
    mined_benchmark = SyntheticBenchmark(
        # Preserve the benchmark's trusted proof rules and add the mined
        # candidate pool. Evaluating the mined pool alone can remove every
        # rule that answers the workload, which is not the Paper 2 setting.
        kb=KnowledgeBase(facts=list(benchmark.kb.facts), rules=[*benchmark.kb.rules, *rules]),
        queries=benchmark.queries,
        metadata={**benchmark.metadata, "paper": "paper2", "mined_rules": len(rules)},
    )
    write_benchmark(run.path / "mined_benchmark.json", mined_benchmark)
    report = evaluate_benchmark(
        mined_benchmark,
        strategies=["bfs", "rule_confidence"],
        max_depth=max_depth,
        max_expansions=max_expansions,
        top_k=1,
        bootstrap_train=False,
    )
    run.write_json("evaluation.json", report)
    write_evaluation_summary_csv(report, run.path / "summary.csv")
    write_evaluation_summary_markdown(report, run.path / "evaluation.md")
    run.write_markdown(
        "summary.md",
        "\n".join(
            [
                "# Paper 2 Run",
                "",
                f"- Mined rules: {len(rules)}",
                f"- Candidate rules after audit threshold: {audit['filtered_rules']}",
                "- Compared BFS against rule-confidence guidance on the mined rule base.",
                "",
                "See `rule_audit.json`, `rules.tsv`, and `evaluation.md`.",
            ]
        ),
    )
    return {
        "mined_rules": len(rules),
        "rule_audit": audit,
        "evaluation": report.get("summaries", []),
    }, [
        "benchmark.json",
        "mined_benchmark.json",
        "rules.json",
        "rules.tsv",
        "rule_audit.json",
        "evaluation.json",
        "summary.csv",
        "evaluation.md",
    ]


def _paper3_context() -> tuple[TrustContext, Atom]:
    facts = [Atom("q", ("drug", "bad")), Atom("p", ("drug", "good"))]
    harmful = Rule(
        "injected_functional_rule",
        Atom("p", ("?x", "?y")),
        (Atom("q", ("?x", "?y")),),
        confidence=0.99,
    )
    context = TrustContext(
        KnowledgeBase(facts=facts, rules=[harmful]),
        schema=Schema(functional=frozenset({"p"})),
        rule_status={harmful.name: CANDIDATE},
        injected_rules=frozenset({harmful.name}),
    )
    return context, Atom("p", ("drug", "bad"))


def _paper3_smoke(config: dict[str, Any], run: ExperimentRun) -> tuple[dict[str, Any], list[str]]:
    context, query = _paper3_context()
    max_depth, max_expansions = _search_settings(config)
    deployment, deployment_stats = CertifiedReasoner(
        context, max_depth=max_depth, enforce=True
    ).search(query, budget=max_expansions)
    monitoring, monitoring_stats = CertifiedReasoner(
        context, max_depth=max_depth, enforce=False
    ).search(query, budget=max_expansions)
    harm = HarmTable()
    audit = audit_answers(monitoring, harm)
    detector = SequentialEvidenceMonitor(baseline=0.0, slack=0.0, threshold=0.5)
    for index, answer in enumerate(monitoring):
        for rule_name in answer.rules_used:
            detector.observe(rule_name, refuted=answer.status == "REFUTED", observation=index)
    audit_payload = [
        {
            "claim": {
                "predicate": item.answer.claim.predicate,
                "args": list(item.answer.claim.args),
            },
            "status": item.answer.status,
            "refutation": item.answer.refutation,
            "rules_used": list(item.answer.rules_used),
            "risk_summary": item.risk_summary,
            "blame_ranking": list(item.blame_ranking(harm.harm)),
        }
        for item in audit
    ]
    run.write_json("audit.json", audit_payload)
    run.write_json(
        "certificates.json",
        {
            "deployment": asdict(deployment_stats),
            "monitoring": asdict(monitoring_stats),
        },
    )
    metrics = {
        "deployment_answers": len(deployment),
        "monitoring_answers": len(monitoring),
        "monitoring_refuted": sum(answer.status == "REFUTED" for answer in monitoring),
        "detected_rules": detector.detected,
        "harm": {name: harm.harm(name) for name in sorted(harm.used)},
        "deployment_pruned": dict(deployment_stats.pruned),
        "monitoring_pruned": dict(monitoring_stats.pruned),
    }
    run.write_markdown(
        "summary.md",
        "\n".join(
            [
                "# Paper 3 Run",
                "",
                f"- Deployment answers: {metrics['deployment_answers']} (must be 0 for this harmful fixture).",
                f"- Monitoring refutations: {metrics['monitoring_refuted']}.",
                f"- Detected injected rules: {', '.join(sorted(detector.detected)) or 'none'}.",
                "- `certificates.json` records certified pruning; `audit.json` records blame evidence.",
            ]
        ),
    )
    return metrics, ["audit.json", "certificates.json"]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _sample_facts(facts: list[Atom], *, limit: int | None, seed: int) -> list[Atom]:
    """Take a deterministic, order-independent source-graph sample."""
    ordered = sorted(set(facts), key=lambda atom: (atom.predicate, atom.args))
    if limit is None or limit <= 0 or len(ordered) <= limit:
        return ordered
    selected = random.Random(seed).sample(ordered, limit)
    return sorted(selected, key=lambda atom: (atom.predicate, atom.args))


def _paper3_dataset_source(spec: dict[str, Any]) -> Path:
    if "train_path" in spec:
        return Path(str(spec["train_path"]))
    if "edge_path" in spec:
        return Path(str(spec["edge_path"]))
    if "root" in spec:
        return discover_dataset_files(spec["root"]).train
    raise ValueError("Each Paper 3 dataset requires one of root, train_path, or edge_path")


def _atom_payload(atom: Atom) -> dict[str, Any]:
    return {"predicate": atom.predicate, "args": list(atom.args)}


def _stats_payload(stats: Any) -> dict[str, Any]:
    return {
        "expanded": stats.expanded,
        "generated": stats.generated,
        "pruned": dict(stats.pruned),
        "exhausted_budget": stats.exhausted_budget,
        "exhausted_state_budget": stats.exhausted_state_budget,
        "exhausted_time_budget": stats.exhausted_time_budget,
    }


def _audit_payload(record: AuditRecord) -> dict[str, Any]:
    return {
        "claim": _atom_payload(record.answer.claim),
        "status": record.answer.status,
        "refutation": record.answer.refutation,
        "rules_used": list(record.answer.rules_used),
        "proof": [
            {"rule": name, "atom": _atom_payload(atom)} for name, atom in record.answer.proof
        ],
        "risk_summary": record.risk_summary,
        "blame_ranking": list(record.blame_ranking(lambda _: record.risk_summary)),
    }


def _paper3_pick_benign_fact(facts: list[Atom], functional: set[str], start: int) -> Atom:
    candidates = [
        fact for fact in facts if fact.predicate not in functional and len(fact.args) >= 2
    ]
    if not candidates:
        candidates = [fact for fact in facts if len(fact.args) >= 2]
    if not candidates:
        raise ValueError("Paper 3 controls require at least one binary fact")
    return candidates[start % len(candidates)]


def _sum_pruned(rows: list[dict[str, Any]]) -> dict[str, int]:
    total: dict[str, int] = {}
    for row in rows:
        for kind, count in row.get("deployment_certificate_pruning", {}).items():
            total[kind] = total.get(kind, 0) + int(count)
    return total


def _paper3_relation_index(facts: list[Atom]) -> dict[str, Any]:
    predicates = Counter(atom.predicate for atom in facts)
    subject_degree = Counter(atom.args[0] for atom in facts if len(atom.args) >= 1)
    object_degree = Counter(atom.args[1] for atom in facts if len(atom.args) >= 2)
    fact_set = set(facts)
    return {
        "predicates": predicates,
        "subject_degree": subject_degree,
        "object_degree": object_degree,
        "fact_set": fact_set,
    }


def _paper3_feature_vector(row: dict[str, Any], index: dict[str, Any]) -> list[float]:
    query = row.get("query", {})
    protected_fact = row.get("protected_fact", query)
    support = [item for item in row.get("support", []) if isinstance(item, dict)]
    query_pred = str(query.get("predicate", ""))
    query_args = [str(arg) for arg in query.get("args", [])]
    protected_args = [str(arg) for arg in protected_fact.get("args", [])]
    support_preds = [str(item.get("predicate", "")) for item in support]
    support_subjects = [
        str(item.get("args", [None, None])[0]) for item in support if len(item.get("args", [])) >= 1
    ]
    support_objects = [
        str(item.get("args", [None, None])[1]) for item in support if len(item.get("args", [])) >= 2
    ]
    predicate_freq = float(index["predicates"].get(query_pred, 0))
    query_subject_degree = (
        float(index["subject_degree"].get(query_args[0], 0)) if query_args else 0.0
    )
    query_object_degree = (
        float(index["object_degree"].get(query_args[1], 0)) if len(query_args) > 1 else 0.0
    )
    protected_subject_degree = (
        float(index["subject_degree"].get(protected_args[0], 0)) if protected_args else 0.0
    )
    protected_object_degree = (
        float(index["object_degree"].get(protected_args[1], 0)) if len(protected_args) > 1 else 0.0
    )
    support_predicate_freq = [
        float(index["predicates"].get(predicate, 0)) for predicate in support_preds
    ] or [0.0]
    support_subject_degree = [
        float(index["subject_degree"].get(subject, 0)) for subject in support_subjects
    ] or [0.0]
    support_object_degree = [
        float(index["object_degree"].get(obj, 0)) for obj in support_objects
    ] or [0.0]
    proof = row.get("refuted_audit", {}) or (
        row.get("monitoring_audit", [{}])[0] if row.get("monitoring_audit") else {}
    )
    proof_items = list(proof.get("proof", [])) if isinstance(proof, dict) else []
    proof_rule_count = sum(1 for item in proof_items if item.get("rule") and item["rule"] != "fact")
    proof_atom_count = len(proof_items)
    return [
        float(row.get("replicate", 0)),
        float(row.get("support_size", len(support))),
        float(row.get("rule_confidence", 0.0)),
        predicate_freq,
        query_subject_degree,
        query_object_degree,
        protected_subject_degree,
        protected_object_degree,
        float(len(set(support_preds))),
        float(sum(support_predicate_freq) / max(1.0, float(len(support_predicate_freq)))),
        float(min(support_predicate_freq)),
        float(max(support_predicate_freq)),
        float(sum(support_subject_degree) / max(1.0, float(len(support_subject_degree)))),
        float(sum(support_object_degree) / max(1.0, float(len(support_object_degree)))),
        float(proof_rule_count),
        float(proof_atom_count),
    ]


def _paper3_detector_score(row: dict[str, Any], index: dict[str, Any]) -> float:
    support = [item for item in row.get("support", []) if isinstance(item, dict)]
    if not support:
        return 0.0
    support_predicates = [str(item.get("predicate", "")) for item in support]
    support_subjects = [
        str(item.get("args", [None, None])[0]) for item in support if len(item.get("args", [])) >= 1
    ]
    support_objects = [
        str(item.get("args", [None, None])[1]) for item in support if len(item.get("args", [])) >= 2
    ]
    support_predicate_freq = [
        float(index["predicates"].get(predicate, 0)) for predicate in support_predicates
    ] or [0.0]
    support_subject_degree = [
        float(index["subject_degree"].get(subject, 0)) for subject in support_subjects
    ] or [0.0]
    support_object_degree = [
        float(index["object_degree"].get(obj, 0)) for obj in support_objects
    ] or [0.0]
    query = row.get("query", {})
    query_subject = (
        str(query.get("args", [None, None])[0]) if len(query.get("args", [])) >= 1 else ""
    )
    query_object = (
        str(query.get("args", [None, None])[1]) if len(query.get("args", [])) >= 2 else ""
    )
    query_subject_degree = float(index["subject_degree"].get(query_subject, 0))
    query_object_degree = float(index["object_degree"].get(query_object, 0))
    predicate_freq = float(index["predicates"].get(str(query.get("predicate", "")), 0))
    structural_rare = sum(support_predicate_freq) / max(1.0, float(len(support_predicate_freq)))
    degree_gap = abs(query_subject_degree - query_object_degree)
    support_balance = abs(
        float(sum(support_subject_degree) / max(1.0, float(len(support_subject_degree))))
        - float(sum(support_object_degree) / max(1.0, float(len(support_object_degree))))
    )
    return 1.0 / max(
        1.0,
        predicate_freq
        + structural_rare
        + degree_gap
        + support_balance
        + float(row.get("support_size", len(support))),
    )


def _paper3_roc_auc(labels: list[int], scores: list[float]) -> float:
    positives = sum(labels)
    negatives = len(labels) - positives
    if positives == 0 or negatives == 0:
        return 0.0
    order = sorted(range(len(scores)), key=lambda idx: scores[idx])
    ranks = [0.0] * len(scores)
    position = 0
    while position < len(order):
        end = position + 1
        while end < len(order) and scores[order[end]] == scores[order[position]]:
            end += 1
        rank = (position + end + 1) / 2.0
        for offset in range(position, end):
            ranks[order[offset]] = rank
        position = end
    sum_ranks_pos = sum(ranks[idx] for idx, label in enumerate(labels) if label == 1)
    u = sum_ranks_pos - positives * (positives + 1) / 2.0
    return float(u / (positives * negatives))


def _paper3_standardize(matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    mean = matrix.mean(axis=0)
    scale = matrix.std(axis=0)
    scale[scale == 0] = 1.0
    return (matrix - mean) / scale, mean, scale


def _paper3_logistic_regression(
    train_x: np.ndarray,
    train_y: np.ndarray,
    *,
    epochs: int = 250,
    learning_rate: float = 0.1,
    l2: float = 1e-3,
) -> np.ndarray:
    weights = np.zeros(train_x.shape[1], dtype=float)
    bias = 0.0
    for _ in range(epochs):
        logits = train_x @ weights + bias
        probs = 1.0 / (1.0 + np.exp(-np.clip(logits, -30.0, 30.0)))
        error = probs - train_y
        grad_w = (train_x.T @ error) / max(1, train_x.shape[0]) + l2 * weights
        grad_b = float(error.mean())
        weights -= learning_rate * grad_w
        bias -= learning_rate * grad_b
    return np.concatenate([weights, np.asarray([bias])])


def _paper3_logistic_predict(weights: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    logits = matrix @ weights[:-1] + weights[-1]
    return 1.0 / (1.0 + np.exp(-np.clip(logits, -30.0, 30.0)))


def _paper3_leave_one_out_scores(matrix: np.ndarray, labels: np.ndarray) -> np.ndarray:
    if matrix.shape[0] <= 1 or len(set(int(value) for value in labels.tolist())) <= 1:
        return np.zeros(matrix.shape[0], dtype=float)
    scores = np.zeros(matrix.shape[0], dtype=float)
    for index in range(matrix.shape[0]):
        mask = np.ones(matrix.shape[0], dtype=bool)
        mask[index] = False
        train_x = matrix[mask]
        train_y = labels[mask]
        if len(set(int(value) for value in train_y.tolist())) <= 1:
            scores[index] = float(train_y.mean())
            continue
        weights = _paper3_logistic_regression(train_x, train_y)
        scores[index] = float(_paper3_logistic_predict(weights, matrix[index : index + 1])[0])
    return scores


def _paper3_isolation_scores(matrix: np.ndarray, *, trees: int = 64, seed: int = 7) -> np.ndarray:
    rng = random.Random(seed)

    def c_factor(size: int) -> float:
        if size <= 1:
            return 0.0
        if size == 2:
            return 1.0
        return 2.0 * (math.log(size - 1) + 0.5772156649) - 2.0 * (size - 1) / size

    class Node:
        __slots__ = ("feature", "threshold", "left", "right", "size")

        def __init__(
            self,
            feature: int | None = None,
            threshold: float | None = None,
            left=None,
            right=None,
            size: int = 0,
        ) -> None:
            self.feature = feature
            self.threshold = threshold
            self.left = left
            self.right = right
            self.size = size

    def build(submatrix: np.ndarray, depth: int, max_depth: int) -> Node:
        size = submatrix.shape[0]
        if size <= 1 or depth >= max_depth or np.allclose(submatrix, submatrix[0]):
            return Node(size=size)
        variances = submatrix.var(axis=0)
        features = [idx for idx, value in enumerate(variances) if value > 0]
        if not features:
            return Node(size=size)
        feature = rng.choice(features)
        column = submatrix[:, feature]
        lo = float(column.min())
        hi = float(column.max())
        if lo == hi:
            return Node(size=size)
        threshold = rng.uniform(lo, hi)
        left_mask = column < threshold
        right_mask = ~left_mask
        if not left_mask.any() or not right_mask.any():
            return Node(size=size)
        return Node(
            feature=feature,
            threshold=threshold,
            left=build(submatrix[left_mask], depth + 1, max_depth),
            right=build(submatrix[right_mask], depth + 1, max_depth),
            size=size,
        )

    def path_length(node: Node, vector: np.ndarray, depth: int) -> float:
        if node.feature is None or node.left is None or node.right is None:
            return depth + c_factor(node.size)
        if vector[node.feature] < node.threshold:
            return path_length(node.left, vector, depth + 1)
        return path_length(node.right, vector, depth + 1)

    if matrix.size == 0:
        return np.zeros(0, dtype=float)
    max_depth = max(1, int(math.ceil(math.log2(max(2, matrix.shape[0])))))
    forest = [build(matrix, 0, max_depth) for _ in range(max(1, trees))]
    scores = []
    normalizer = c_factor(matrix.shape[0])
    for vector in matrix:
        lengths = [path_length(tree, vector, 0) for tree in forest]
        average = float(sum(lengths) / len(lengths))
        if normalizer == 0:
            scores.append(-average)
        else:
            scores.append(-(2.0 ** (-average / normalizer)))
    return np.asarray(scores, dtype=float)


def _paper3_pairwise_mrr(ranks: list[int | None], *, total: int) -> float:
    if not ranks or total <= 0:
        return 0.0
    reciprocal = 0.0
    for rank in ranks:
        reciprocal += 1.0 / rank if rank else 0.0
    return reciprocal / total


def _paper3_bootstrap_interval(
    values: list[float], *, seed: int, samples: int = 400, confidence: float = 0.95
) -> dict[str, float]:
    if not values:
        return {"mean": 0.0, "lower": 0.0, "upper": 0.0}
    rng = random.Random(seed)
    n = len(values)
    draws: list[float] = []
    for _ in range(max(1, samples)):
        sample = [values[rng.randrange(n)] for _ in range(n)]
        draws.append(float(sum(sample) / n))
    draws.sort()
    lower_index = max(0, int(((1.0 - confidence) / 2.0) * (len(draws) - 1)))
    upper_index = min(len(draws) - 1, int(((1.0 + confidence) / 2.0) * (len(draws) - 1)))
    return {
        "mean": float(sum(values) / len(values)),
        "lower": float(draws[lower_index]),
        "upper": float(draws[upper_index]),
    }


def _paper3_bootstrap_auc(
    labels: list[int], scores: list[float], *, seed: int, samples: int = 400
) -> dict[str, float]:
    base = _paper3_roc_auc(labels, scores)
    if len(labels) <= 1 or len(scores) <= 1:
        return {"mean": base, "lower": base, "upper": base}
    rng = random.Random(seed)
    n = len(labels)
    draws: list[float] = []
    attempts = 0
    while len(draws) < max(1, samples) and attempts < max(1, samples) * 4:
        attempts += 1
        indices = [rng.randrange(n) for _ in range(n)]
        sample_labels = [labels[index] for index in indices]
        sample_scores = [scores[index] for index in indices]
        if len(set(sample_labels)) < 2:
            continue
        draws.append(_paper3_roc_auc(sample_labels, sample_scores))
    if not draws:
        return {"mean": base, "lower": base, "upper": base}
    draws.sort()
    lower_index = max(0, int(0.025 * (len(draws) - 1)))
    upper_index = min(len(draws) - 1, int(0.975 * (len(draws) - 1)))
    return {
        "mean": float(base),
        "lower": float(draws[lower_index]),
        "upper": float(draws[upper_index]),
    }


def _paper3_certificate_coverage() -> dict[str, Any]:
    """Execute one minimal witness for every sound certificate class."""
    coverage: dict[str, Any] = {}
    pre_context = TrustContext(KnowledgeBase(facts=[], rules=[]))
    _, stats = CertifiedReasoner(pre_context).search(Atom("missing", ("a", "b")))
    coverage["C-PRE"] = _stats_payload(stats)

    type_context, type_query = _paper3_context()
    _, stats = CertifiedReasoner(type_context).search(type_query)
    coverage["C-TYPE"] = _stats_payload(stats)

    depth_rule = Rule("one_step", Atom("goal", ("?x", "?y")), (Atom("seed", ("?x", "?y")),))
    depth_context = TrustContext(
        KnowledgeBase(facts=[Atom("seed", ("a", "b"))], rules=[depth_rule])
    )
    _, stats = CertifiedReasoner(depth_context, max_depth=0).search(Atom("goal", ("a", "b")))
    coverage["C-DEPTH"] = _stats_payload(stats)

    loop_rule = Rule("loop", Atom("loop", ("?x", "?y")), (Atom("loop", ("?x", "?y")),))
    loop_context = TrustContext(KnowledgeBase(facts=[], rules=[loop_rule]))
    loop_reasoner = CertifiedReasoner(loop_context)
    loop_state = TrustState(Atom("loop", ("a", "b")), (Atom("loop", ("a", "b")),))
    loop_certificate = loop_reasoner.certify(
        loop_state, {loop_reasoner._subsumption_key(loop_state): 0}
    )
    coverage["C-SUBSUME"] = {"certificate": asdict(loop_certificate) if loop_certificate else None}

    left = Rule("left", Atom("left", ("?x", "?y")), ())
    right = Rule("right", Atom("right", ("?x", "?y")), ())
    unsat_context = TrustContext(
        KnowledgeBase(facts=[], rules=[left, right]),
        schema=Schema(
            domain={"left": "A", "right": "B"}, disjoint=frozenset({frozenset({"A", "B"})})
        ),
    )
    unsat_reasoner = CertifiedReasoner(unsat_context)
    unsat_state = TrustState(
        Atom("left", ("?x", "?y")), (Atom("left", ("?x", "?y")), Atom("right", ("?x", "?z")))
    )
    unsat_certificate = unsat_reasoner.certify(unsat_state, {})
    coverage["C-UNSAT"] = {"certificate": asdict(unsat_certificate) if unsat_certificate else None}
    expected = {"C-PRE", "C-TYPE", "C-DEPTH", "C-SUBSUME", "C-UNSAT"}
    for kind in expected:
        if kind in {"C-SUBSUME", "C-UNSAT"}:
            if (
                coverage[kind]["certificate"] is None
                or coverage[kind]["certificate"]["kind"] != kind
            ):
                raise AssertionError(f"Certificate coverage failed for {kind}")
        elif coverage[kind]["pruned"].get(kind, 0) != 1:
            raise AssertionError(f"Certificate coverage failed for {kind}")
    return coverage


def _paper3_real_dataset(
    spec: dict[str, Any], config: dict[str, Any], index: int, *, replicate: int = 0
) -> dict[str, Any]:
    name = str(spec.get("name", f"dataset_{index}"))
    source = _paper3_dataset_source(spec)
    if not source.exists():
        raise FileNotFoundError(f"Paper 3 source file does not exist: {source}")
    protocol = dict(config.get("protocol", {}))
    seed = int(protocol.get("seed", config.get("seed", 7))) + index
    max_facts = spec.get("max_facts", protocol.get("max_facts", 5_000))
    if max_facts is not None:
        max_facts = int(max_facts)
    max_depth, budget = _search_settings(config)
    source_facts = read_triple_file(source)
    facts = _sample_facts(source_facts, limit=max_facts, seed=seed)
    base = TrustContext(KnowledgeBase(facts=facts, rules=[]))
    families = tuple(
        spec.get("attack_families", protocol.get("attack_families", ["A1", "A2", "A3", "A4", "A5"]))
    )
    context, scenarios = build_functionality_attack_suite(base, seed=seed, families=families)
    functional = set(context.schema.functional)
    family_index = {family: pos for pos, family in enumerate(families)}
    repetitions = int(protocol.get("stream_repetitions", 5))
    detector_config = dict(protocol.get("monitor", {}))
    detector = SequentialEvidenceMonitor(
        baseline=float(detector_config.get("baseline", 0.0)),
        slack=float(detector_config.get("slack", 0.0)),
        threshold=float(detector_config.get("threshold", 0.5)),
    )
    rows: list[dict[str, Any]] = []
    controls: list[dict[str, Any]] = []
    rng = random.Random(seed)
    used_counts: Counter[str] = Counter()
    refuted_counts: Counter[str] = Counter()
    observation = 0
    safety_equal = True
    for scenario in scenarios:
        deployment, deploy_stats = CertifiedReasoner(
            context, max_depth=max_depth, enforce=True
        ).search(scenario.query, budget=budget)
        exhaustive, exhaustive_stats = CertifiedReasoner(
            context, max_depth=max_depth, enforce=True
        ).search(scenario.query, certified=False, budget=budget)
        monitoring, monitoring_stats = CertifiedReasoner(
            context, max_depth=max_depth, enforce=False
        ).search(scenario.query, budget=budget)
        monitoring_audit = audit_answers(monitoring)
        safety_equal = safety_equal and {
            (answer.claim, answer.status, answer.rules_used) for answer in deployment
        } == {(answer.claim, answer.status, answer.rules_used) for answer in exhaustive}
        refuted = [
            answer
            for answer in monitoring
            if answer.status == "REFUTED" and scenario.rule_name in answer.rules_used
        ]
        for record in monitoring_audit:
            for rule_name in record.answer.rules_used:
                used_counts[rule_name] += 1
                if record.answer.status == REFUTED:
                    refuted_counts[rule_name] += 1
        for _ in range(repetitions):
            detector.observe(scenario.rule_name, refuted=bool(refuted), observation=observation)
            observation += 1
        refuted_record = next(
            (
                record
                for record in monitoring_audit
                if record.answer.status == REFUTED
                and scenario.rule_name in record.answer.rules_used
            ),
            None,
        )
        rows.append(
            {
                "dataset": name,
                "replicate": replicate,
                "family": scenario.family,
                "family_index": family_index[scenario.family],
                "label": 1,
                "rule_name": scenario.rule_name,
                "rule_confidence": 0.99,
                "support_size": len(scenario.support),
                "query": _atom_payload(scenario.query),
                "protected_fact": _atom_payload(scenario.protected_fact),
                "support": [_atom_payload(atom) for atom in scenario.support],
                "deployment_answers": len(deployment),
                "unpruned_deployment_answers": len(exhaustive),
                "monitoring_answers": len(monitoring),
                "monitoring_refuted": len(refuted),
                "detected": scenario.rule_name in detector.detected,
                "detection_observation": detector.detected.get(scenario.rule_name),
                "deployment_certificate_pruning": dict(deploy_stats.pruned),
                "deployment_stats": _stats_payload(deploy_stats),
                "unpruned_deployment_stats": _stats_payload(exhaustive_stats),
                "monitoring_stats": _stats_payload(monitoring_stats),
                "monitoring_audit": [_audit_payload(record) for record in monitoring_audit],
                "refuted_audit": _audit_payload(refuted_record) if refuted_record else None,
            }
        )

    # A control pool of benign candidate rules with the same replay protocol.
    def build_control_rules(
        *, control_index: int, support: tuple[Atom, ...], subject: str, family: str, target: Atom
    ) -> tuple[list[Rule], Rule, Atom]:
        fresh_object = f"__trustkg_control_{family.lower()}_{replicate}_{control_index}"
        query = Atom(target.predicate, (subject, fresh_object))
        intermediate = Atom(
            f"__trustkg_control_mid_{family.lower()}_{replicate}_{control_index}",
            (subject, fresh_object),
        )
        helper_count = max(2, {"A1": 2, "A2": 3, "A3": 2, "A4": 3, "A5": 4}[family])
        helper_rules: list[Rule] = []
        for helper_pos in range(helper_count):
            helper_name = f"control_{family}_helper_{replicate}_{control_index}_{helper_pos}"
            helper_rules.append(
                Rule(
                    name=helper_name,
                    head=intermediate,
                    body=(support[helper_pos % len(support)],),
                    confidence=max(0.55, 0.80 - 0.05 * helper_pos),
                )
            )
        control_rule = Rule(
            name=f"benign_candidate_control_{family}_{replicate}_{control_index}",
            head=query,
            body=(intermediate,),
            confidence=0.99,
        )
        return helper_rules, control_rule, query

    for control_index, scenario in enumerate(scenarios):
        control_target = _paper3_pick_benign_fact(facts, functional, index + control_index)
        control_support = tuple(
            facts[(control_index + offset + 1) % len(facts)]
            for offset in range(len(scenario.support))
        )
        helper_rules, control_rule, control_query = build_control_rules(
            control_index=control_index,
            support=control_support,
            subject=str(control_target.args[0]),
            family=scenario.family,
            target=control_target,
        )
        controlled = context.with_rules([*helper_rules, control_rule], status=CANDIDATE)
        control_answers, control_stats = CertifiedReasoner(
            controlled, max_depth=max_depth, enforce=False
        ).search(control_query, budget=budget)
        control_audit = audit_answers(control_answers)
        control_refuted = [
            answer
            for answer in control_answers
            if control_rule.name in answer.rules_used and answer.status == "REFUTED"
        ]
        for record in control_audit:
            for rule_name in record.answer.rules_used:
                used_counts[rule_name] += 1
                if record.answer.status == REFUTED:
                    refuted_counts[rule_name] += 1
        for _ in range(repetitions):
            detector.observe(
                control_rule.name, refuted=bool(control_refuted), observation=observation
            )
            observation += 1
        control_row = {
            "dataset": name,
            "replicate": replicate,
            "family": f"{scenario.family}_control",
            "family_index": family_index[scenario.family],
            "label": 0,
            "rule_name": control_rule.name,
            "rule_confidence": 0.99,
            "support_size": len(control_support),
            "query": _atom_payload(control_query),
            "protected_fact": _atom_payload(control_target),
            "support": [_atom_payload(atom) for atom in control_support],
            "deployment_answers": len(control_answers),
            "unpruned_deployment_answers": len(control_answers),
            "monitoring_answers": len(control_answers),
            "monitoring_refuted": len(control_refuted),
            "detected": control_rule.name in detector.detected,
            "detection_observation": detector.detected.get(control_rule.name),
            "deployment_certificate_pruning": dict(control_stats.pruned),
            "deployment_stats": _stats_payload(control_stats),
            "unpruned_deployment_stats": _stats_payload(control_stats),
            "monitoring_stats": _stats_payload(control_stats),
            "monitoring_audit": [_audit_payload(record) for record in control_audit],
            "refuted_audit": None,
        }
        controls.append(control_row)

    case_rows = [*rows, *controls]
    feature_index = _paper3_relation_index(facts)
    feature_matrix = np.asarray(
        [_paper3_feature_vector(row, feature_index) for row in case_rows], dtype=float
    )
    standardized_matrix, _, _ = _paper3_standardize(feature_matrix)
    labels = [int(row["label"]) for row in case_rows]
    families_report: dict[str, dict[str, float]] = {}
    for family in families:
        family_labels = [
            int(row["label"])
            for row in case_rows
            if row["family"] == family or row["family"] == f"{family}_control"
        ]
        family_attack_rows = [row for row in case_rows if row["family"] == family]
        family_controls = [row for row in case_rows if row["family"] == f"{family}_control"]
        family_rows = [*family_attack_rows, *family_controls]
        if not family_rows:
            continue
        family_matrix = np.asarray(
            [_paper3_feature_vector(row, feature_index) for row in family_rows], dtype=float
        )
        family_standardized, _, _ = _paper3_standardize(family_matrix)
        d1_scores = [float(row["rule_confidence"]) for row in family_rows]
        d2_scores = [1.0 / max(1.0, float(row["support_size"])) for row in family_rows]
        d3_scores = list(_paper3_isolation_scores(family_standardized, seed=seed))
        d4_scores = []
        for row in family_rows:
            query_subject_degree = float(
                feature_index["subject_degree"].get(row["query"]["args"][0], 0)
            )
            query_object_degree = float(
                feature_index["object_degree"].get(row["query"]["args"][1], 0)
            )
            predicate_freq = float(feature_index["predicates"].get(row["query"]["predicate"], 0))
            d4_scores.append(
                1.0
                / max(
                    1.0,
                    predicate_freq
                    + abs(query_subject_degree - query_object_degree)
                    + float(row["support_size"]),
                )
            )
        d5_scores = [_paper3_detector_score(row, feature_index) for row in family_rows]
        d7_scores = list(
            _paper3_leave_one_out_scores(
                family_standardized, np.asarray(family_labels, dtype=float)
            )
        )
        family_score_map = {
            "D1": d1_scores,
            "D2": d2_scores,
            "D3": d3_scores,
            "D4": d4_scores,
            "D5": d5_scores,
            "D7": d7_scores,
        }
        family_report = {
            name: _paper3_roc_auc(family_labels, scores)
            for name, scores in family_score_map.items()
        }
        family_report["controls"] = len(family_controls)
        family_report["attacks"] = len(family_attack_rows)
        families_report[family] = family_report

    all_scores = {
        "D1": [float(row["rule_confidence"]) for row in case_rows],
        "D2": [1.0 / max(1.0, float(row["support_size"])) for row in case_rows],
        "D3": list(_paper3_isolation_scores(standardized_matrix, seed=seed)),
        "D4": [],
        "D5": [_paper3_detector_score(row, feature_index) for row in case_rows],
    }
    for row in case_rows:
        query_subject_degree = float(
            feature_index["subject_degree"].get(row["query"]["args"][0], 0)
        )
        query_object_degree = float(feature_index["object_degree"].get(row["query"]["args"][1], 0))
        predicate_freq = float(feature_index["predicates"].get(row["query"]["predicate"], 0))
        all_scores["D4"].append(
            1.0
            / max(
                1.0,
                predicate_freq
                + abs(query_subject_degree - query_object_degree)
                + float(row["support_size"]),
            )
        )
    all_scores["D7"] = list(
        _paper3_leave_one_out_scores(standardized_matrix, np.asarray(labels, dtype=float))
    )
    overall_report = {name: _paper3_roc_auc(labels, scores) for name, scores in all_scores.items()}
    attribution_rows = [row for row in rows if row.get("refuted_audit")]
    attribution_total = len(attribution_rows)
    random_hits = lowest_hits = loo_hits = harm_hits = 0
    random_mrr = lowest_mrr = loo_mrr = harm_mrr = 0.0
    for row in attribution_rows:
        refuted = row["refuted_audit"]
        proof_rules = [item["rule"] for item in refuted["proof"] if item["rule"] != "fact"]
        if not proof_rules:
            continue
        injected = row["rule_name"]
        chosen = rng.choice(proof_rules)
        random_rank = 1 if chosen == injected else len(proof_rules) + 1
        random_hits += int(chosen == injected)
        random_mrr += 1.0 / random_rank
        ranked_by_conf = sorted(
            proof_rules,
            key=lambda rule_name: (
                float(
                    next(
                        (
                            item["rule_confidence"]
                            for item in rows
                            if item["rule_name"] == rule_name
                        ),
                        0.0,
                    )
                ),
                rule_name,
            ),
        )
        chosen = ranked_by_conf[0]
        lowest_hits += int(chosen == injected)
        lowest_mrr += 1.0 / (1 if chosen == injected else len(proof_rules) + 1)
        culprit = None
        for candidate in proof_rules:
            if candidate == "fact":
                continue
            reduced_rules = [rule for rule in context.kb.rules if rule.name != candidate]
            reduced_status = {
                name: status for name, status in context.rule_status.items() if name != candidate
            }
            reduced_injected = frozenset(
                name for name in context.injected_rules if name != candidate
            )
            reduced_context = TrustContext(
                KnowledgeBase(facts=list(context.kb.facts), rules=reduced_rules),
                schema=context.schema,
                negatives=context.negatives,
                rule_status=reduced_status,
                injected_rules=reduced_injected,
            )
            reduced_answers, _ = CertifiedReasoner(
                reduced_context, max_depth=max_depth, enforce=False
            ).search(
                Atom(row["query"]["predicate"], tuple(row["query"]["args"])),
                budget=budget,
            )
            if not any(answer.status == REFUTED for answer in reduced_answers):
                culprit = candidate
                break
        if culprit is None and proof_rules:
            culprit = proof_rules[0]
        loo_hits += int(culprit == injected)
        loo_mrr += 1.0 / (1 if culprit == injected else len(proof_rules) + 1)
        harm_ranked = sorted(
            proof_rules,
            key=lambda rule_name: (
                -float(refuted_counts.get(rule_name, 0))
                / max(1.0, float(used_counts.get(rule_name, 0))),
                rule_name,
            ),
        )
        chosen = harm_ranked[0]
        harm_hits += int(chosen == injected)
        harm_mrr += 1.0 / (1 if chosen == injected else len(proof_rules) + 1)
    attribution_report = {
        "cases": attribution_total,
        "random": {
            "top1": random_hits / attribution_total if attribution_total else 0.0,
            "mrr": random_mrr / attribution_total if attribution_total else 0.0,
        },
        "lowest_remined": {
            "top1": lowest_hits / attribution_total if attribution_total else 0.0,
            "mrr": lowest_mrr / attribution_total if attribution_total else 0.0,
        },
        "leave_one_out": {
            "top1": loo_hits / attribution_total if attribution_total else 0.0,
            "mrr": loo_mrr / attribution_total if attribution_total else 0.0,
        },
        "harm_ranked": {
            "top1": harm_hits / attribution_total if attribution_total else 0.0,
            "mrr": harm_mrr / attribution_total if attribution_total else 0.0,
        },
    }
    return {
        "name": name,
        "replicate": replicate,
        "source": str(source),
        "source_sha256": _sha256(source),
        "source_triples": len(source_facts),
        "sampled_triples": len(facts),
        "sample_seed": seed,
        "rows": rows,
        "control": controls[0] if controls else None,
        "controls": controls,
        "safety_equivalence": safety_equal,
        "certificate_pruning": _sum_pruned(rows),
        "detected_rules": dict(detector.detected),
        "rule_harm": {name: (refuted_counts[name] / used_counts[name]) for name in used_counts},
        "detector_report": overall_report,
        "family_detector_report": families_report,
        "attribution_report": attribution_report,
    }


def _paper3_real(config: dict[str, Any], run: ExperimentRun) -> tuple[dict[str, Any], list[str]]:
    specifications = config.get("datasets")
    if not isinstance(specifications, list) or not specifications:
        raise ValueError("A Paper 3 real-data configuration requires a non-empty datasets array")
    protocol = dict(config.get("protocol", {}))
    seeds = protocol.get("seeds", [protocol.get("seed", config.get("seed", 7))])
    if not isinstance(seeds, list) or not seeds:
        raise ValueError("protocol.seeds must be a non-empty array when provided")
    datasets: list[dict[str, Any]] = []
    for replicate, seed in enumerate(seeds):
        replicate_config = dict(config)
        replicate_config["protocol"] = {**protocol, "seed": int(seed)}
        datasets.extend(
            _paper3_real_dataset(dict(spec), replicate_config, index, replicate=replicate)
            for index, spec in enumerate(specifications)
        )
    rows = [row for dataset in datasets for row in dataset["rows"]]
    controls = [
        control
        for dataset in datasets
        for control in dataset.get("controls", [])
        if control is not None
    ]
    attack_count = len(rows)
    control_count = len(controls)
    detected = sum(bool(row["detected"]) for row in rows)
    blocked = sum(row["deployment_answers"] == 0 and row["monitoring_refuted"] > 0 for row in rows)
    false_alarms = sum(bool(control["detected"]) for control in controls)
    detector_names: list[str] = []
    for dataset in datasets:
        if dataset.get("detector_report"):
            detector_names = sorted(dataset["detector_report"])
            break
    detector_report = {
        name: sum(float(dataset.get("detector_report", {}).get(name, 0.0)) for dataset in datasets)
        / max(1, sum(1 for dataset in datasets if name in dataset.get("detector_report", {})))
        for name in detector_names
    }
    dataset_detector_report: dict[str, dict[str, float]] = {}
    replicate_detector_report: dict[str, dict[str, float]] = {}
    for dataset in datasets:
        detector_values = dataset.get("detector_report", {})
        weight = float(len(dataset.get("rows", [])) or 1)
        dataset_bucket = dataset_detector_report.setdefault(str(dataset["name"]), {"weight": 0.0})
        dataset_bucket["weight"] += weight
        replicate_bucket = replicate_detector_report.setdefault(
            str(dataset.get("replicate", 0)), {"weight": 0.0}
        )
        replicate_bucket["weight"] += weight
        for detector_name, value in detector_values.items():
            dataset_bucket[detector_name] = (
                dataset_bucket.get(detector_name, 0.0) + float(value) * weight
            )
            replicate_bucket[detector_name] = (
                replicate_bucket.get(detector_name, 0.0) + float(value) * weight
            )
    for report in dataset_detector_report.values():
        weight = report.pop("weight", 1.0)
        for detector_name, value in list(report.items()):
            report[detector_name] = value / max(1.0, weight)
    for report in replicate_detector_report.values():
        weight = report.pop("weight", 1.0)
        for detector_name, value in list(report.items()):
            report[detector_name] = value / max(1.0, weight)
    family_detector_report: dict[str, dict[str, float]] = {}
    family_detector_report_weighted: dict[str, dict[str, float]] = {}
    for dataset in datasets:
        for family, report in dataset.get("family_detector_report", {}).items():
            family_detector_report.setdefault(family, {"count": 0.0})
            family_detector_report_weighted.setdefault(family, {"count": 0.0})
            family_detector_report[family]["count"] += 1.0
            family_weight = float(report.get("attacks", 0.0) + report.get("controls", 0.0))
            family_detector_report_weighted[family]["count"] += family_weight
            for detector_name, value in report.items():
                if detector_name in {"controls", "attacks"}:
                    continue
                family_detector_report[family][detector_name] = family_detector_report[family].get(
                    detector_name, 0.0
                ) + float(value)
                family_detector_report_weighted[family][detector_name] = (
                    family_detector_report_weighted[family].get(detector_name, 0.0)
                    + float(value) * family_weight
                )
    for family, report in family_detector_report.items():
        count = report.pop("count", 1.0)
        for detector_name, value in list(report.items()):
            report[detector_name] = value / max(1.0, count)
    for family, report in family_detector_report_weighted.items():
        count = report.pop("count", 1.0)
        for detector_name, value in list(report.items()):
            report[detector_name] = value / max(1.0, count)
    attribution_report: dict[str, dict[str, float]] = {}
    attribution_keys = ["random", "lowest_remined", "leave_one_out", "harm_ranked"]
    for key in attribution_keys:
        cases = sum(
            float(dataset.get("attribution_report", {}).get("cases", 0.0)) for dataset in datasets
        )
        if cases <= 0:
            continue
        top1 = (
            sum(
                float(dataset.get("attribution_report", {}).get(key, {}).get("top1", 0.0))
                * float(dataset.get("attribution_report", {}).get("cases", 0.0))
                for dataset in datasets
            )
            / cases
        )
        mrr = (
            sum(
                float(dataset.get("attribution_report", {}).get(key, {}).get("mrr", 0.0))
                * float(dataset.get("attribution_report", {}).get("cases", 0.0))
                for dataset in datasets
            )
            / cases
        )
        attribution_report[key] = {"top1": top1, "mrr": mrr}
    bootstrap_report = {
        "rates": {
            "deployment_block_rate": _paper3_bootstrap_interval(
                [float(row["deployment_answers"] == 0) for row in rows], seed=sum(seeds) + 101
            ),
            "monitoring_refutation_rate": _paper3_bootstrap_interval(
                [float(row["monitoring_refuted"] > 0) for row in rows], seed=sum(seeds) + 103
            ),
            "monitor_detection_rate": _paper3_bootstrap_interval(
                [float(row["detected"]) for row in rows], seed=sum(seeds) + 107
            ),
            "monitor_false_alarm_rate": _paper3_bootstrap_interval(
                [float(control["detected"]) for control in controls], seed=sum(seeds) + 109
            ),
        }
    }
    metrics = {
        "datasets": len(specifications),
        "replicates": len(seeds),
        "attack_cases": attack_count,
        "control_cases": control_count,
        "attack_families": sorted({row["family"] for row in rows}),
        "deployment_block_rate": blocked / attack_count if attack_count else 0.0,
        "monitoring_refutation_rate": sum(row["monitoring_refuted"] > 0 for row in rows)
        / attack_count
        if attack_count
        else 0.0,
        "monitor_detection_rate": detected / attack_count if attack_count else 0.0,
        "monitor_false_alarm_rate": false_alarms / len(controls) if controls else 0.0,
        "certification_preserves_unpruned_deployment_answers": all(
            dataset["safety_equivalence"] for dataset in datasets
        ),
        "certificate_pruning": _sum_pruned(rows),
        "detector_report": detector_report,
        "dataset_detector_report": dataset_detector_report,
        "replicate_detector_report": replicate_detector_report,
        "family_detector_report": family_detector_report,
        "family_detector_report_weighted": family_detector_report_weighted,
        "attribution_report": attribution_report,
        "bootstrap_report": bootstrap_report,
    }
    submission_artifacts: list[str] = []
    if config.get("submission"):
        from .paper3_submission import run_submission_suite

        submission_specs = [
            {
                "name": str(spec.get("name", f"dataset_{index}")),
                "source": str(_paper3_dataset_source(dict(spec))),
            }
            for index, spec in enumerate(specifications)
        ]
        submission = run_submission_suite(config, submission_specs)
        metrics["submission"] = {
            "pruning": submission["pruning"],
            "detector": submission["detector"],
            "attribution": submission["attribution"],
            "execution": submission["execution"],
            "attack_cases": len(submission["attack_cases"]),
            "duration_seconds": submission["duration_seconds"],
        }
        run.write_json("submission_sources.json", submission["sources"])
        run.write_json("submission_attacks.json", submission["attack_cases"])
        run.write_json("submission_detector.json", submission["detector"])
        run.write_json("submission_execution.json", submission["execution"])
        run.write_json("submission_pruning.json", submission["pruning_rows"])
        run.write_json("submission_attribution.json", submission["attribution_rows"])
        submission_artifacts = [
            "submission_sources.json",
            "submission_attacks.json",
            "submission_detector.json",
            "submission_execution.json",
            "submission_pruning.json",
            "submission_attribution.json",
        ]
    certificate_coverage = _paper3_certificate_coverage()
    metrics["certificate_coverage"] = sorted(certificate_coverage)
    run.write_json("datasets.json", datasets)
    run.write_json("attack_cases.json", rows)
    run.write_json("controls.json", controls)
    run.write_json("detectors.json", detector_report)
    run.write_json("family_detectors.json", family_detector_report)
    run.write_json("attribution.json", attribution_report)
    run.write_json("certificate_coverage.json", certificate_coverage)
    with (run.path / "attack_cases.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = [
            "dataset",
            "replicate",
            "family",
            "rule_name",
            "deployment_answers",
            "unpruned_deployment_answers",
            "monitoring_answers",
            "monitoring_refuted",
            "detected",
            "detection_observation",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows({key: row[key] for key in fields} for row in rows)
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in rows:
        grouped.setdefault((row["dataset"], row["family"]), []).append(row)
    aggregate_rows = []
    for (dataset, family), group in sorted(grouped.items()):
        total = len(group)
        aggregate_rows.append(
            {
                "dataset": dataset,
                "family": family,
                "replicates": total,
                "deployment_block_rate": sum(row["deployment_answers"] == 0 for row in group)
                / total,
                "monitoring_refutation_rate": sum(row["monitoring_refuted"] > 0 for row in group)
                / total,
                "monitor_detection_rate": sum(bool(row["detected"]) for row in group) / total,
                "mean_certified_expanded": sum(row["deployment_stats"]["expanded"] for row in group)
                / total,
                "mean_unpruned_expanded": sum(
                    row["unpruned_deployment_stats"]["expanded"] for row in group
                )
                / total,
            }
        )
    with (run.path / "aggregate.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = list(aggregate_rows[0]) if aggregate_rows else ["dataset", "family", "replicates"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(aggregate_rows)
    run.write_markdown(
        "protocol.md",
        "\n".join(
            [
                "# Paper 3 Real-Data Protocol",
                "",
                "Each dataset is loaded from its declared native triple export and used at full available size.",
                "For each A1--A5 case, the runner injects only a candidate rule. Its premises and the",
                "protected conflicting fact are retained from the source graph; the fresh rule head is a",
                "known functionality violation. Deployment must block it, monitoring must retain a",
                "refuted audit record, and the sequential evidence monitor is evaluated on repeated observations. A matched pool of",
                "benign candidate controls uses real non-functional predicates with fresh objects so the",
                "comparison stays on the same vocabulary without turning into a synthetic predicate test.",
                "",
                "This is a labelled rule-injection evaluation. `detectors.json` records D1--D7 AUCs over",
                "the injected-vs-control cases and `attribution.json` records the blame baselines.",
                "The family-stratified detector slice is diagnostic; the pooled detector report is the headline view.",
                "It does not claim semantic ground truth for arbitrary rules mined from these KGs.",
            ]
        ),
    )
    submission_lines: list[str] = []
    if "submission" in metrics:
        submission_metrics = metrics["submission"]
        submission_lines = [
            "",
            "## Submission Stress Suite",
            "",
            f"- Structurally distinct attack/control cases: {submission_metrics['attack_cases']}",
            f"- Executed attack blocking/refutation: {submission_metrics['execution']['attack_blocked']}/{submission_metrics['execution']['attacks']}, {submission_metrics['execution']['attack_refuted']}/{submission_metrics['execution']['attacks']}",
            f"- Executed control refutations: {submission_metrics['execution']['control_refuted']}/{submission_metrics['execution']['controls']}",
            f"- Nontrivial pruning queries: {submission_metrics['pruning']['queries']}",
            f"- Certified/exhaustive answer-set agreement: {submission_metrics['pruning']['answer_set_agreement']:.3f}",
            f"- Certified expansion reduction: {submission_metrics['pruning']['expansion_reduction']:.3f}",
            f"- Matched-volume unsafe answer recall: {submission_metrics['pruning']['matched_volume_answer_recall']:.3f}",
            f"- Dataset-held-out message-passing AUROC: {submission_metrics['detector']['dataset_held_out']['auroc']:.3f}",
            f"- Family-held-out message-passing AUROC: {submission_metrics['detector']['family_held_out']['auroc']:.3f}",
            f"- Template-held-out message-passing AUROC: {submission_metrics['detector']['template_held_out']['auroc']:.3f}",
        ]
    run.write_markdown(
        "summary.md",
        "\n".join(
            [
                "# Paper 3 Real-Data Run",
                "",
                f"- Datasets: {metrics['datasets']}",
                f"- Independent sampled replicas: {metrics['replicates']}",
                f"- Labelled injected attacks: {metrics['attack_cases']}",
                f"- Benign controls: {metrics['control_cases']}",
                f"- Deployment block rate: {metrics['deployment_block_rate']:.3f}",
                f"- Monitoring refutation rate: {metrics['monitoring_refutation_rate']:.3f}",
                f"- Sequential-monitor detection rate: {metrics['monitor_detection_rate']:.3f}",
                f"- Sequential-monitor false-alarm rate on benign controls: {metrics['monitor_false_alarm_rate']:.3f}",
                f"- Detector AUCs: D1 {metrics['detector_report']['D1']:.3f}, D2 {metrics['detector_report']['D2']:.3f}, D3 {metrics['detector_report']['D3']:.3f}, D4 {metrics['detector_report']['D4']:.3f}, D5 {metrics['detector_report']['D5']:.3f}, D7 {metrics['detector_report']['D7']:.3f}",
                "- Stratified detector reports are written to `metrics.json` as pooled, dataset-weighted, and family-weighted views.",
                "- Bootstrap intervals for the headline rates are written to `metrics.json`.",
                f"- Attribution top-1: random {metrics['attribution_report']['random']['top1']:.3f}, lowest {metrics['attribution_report']['lowest_remined']['top1']:.3f}, leave-one-out {metrics['attribution_report']['leave_one_out']['top1']:.3f}, harm-ranked {metrics['attribution_report']['harm_ranked']['top1']:.3f}",
                f"- Certified and unpruned deployment answers agree: {metrics['certification_preserves_unpruned_deployment_answers']}",
                "",
                "`certificate_coverage.json` executes a minimal witness for every certificate class.",
                "See `protocol.md`, `datasets.json`, `attack_cases.csv`, `controls.json`, `detectors.json`, `attribution.json`, and `aggregate.csv` for the complete, reproducible evidence.",
                *submission_lines,
            ]
        ),
    )
    return metrics, [
        "datasets.json",
        "attack_cases.json",
        "controls.json",
        "attack_cases.csv",
        "aggregate.csv",
        "certificate_coverage.json",
        "detectors.json",
        "family_detectors.json",
        "attribution.json",
        "protocol.md",
        *submission_artifacts,
    ]


def _paper3(config: dict[str, Any], run: ExperimentRun) -> tuple[dict[str, Any], list[str]]:
    return _paper3_real(config, run) if config.get("datasets") else _paper3_smoke(config, run)


def collect_paper3_runs(run_paths: list[str | Path], output_dir: str | Path) -> Path:
    """Collect independent Paper 3 replicas without altering their artifacts."""
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=False)
    rows: list[dict[str, Any]] = []
    sources: list[dict[str, Any]] = []
    runs: list[dict[str, Any]] = []
    for raw_path in run_paths:
        path = Path(raw_path)
        required = [
            path / "metrics.json",
            path / "datasets.json",
            path / "attack_cases.json",
            path / "manifest.json",
        ]
        missing = [str(item) for item in required if not item.exists()]
        if missing:
            raise FileNotFoundError(f"Not a completed Paper 3 real-data run: {', '.join(missing)}")
        metrics = json.loads((path / "metrics.json").read_text(encoding="utf-8"))
        if "attack_cases" not in metrics:
            raise ValueError(f"Not a Paper 3 real-data result: {path}")
        run_rows = json.loads((path / "attack_cases.json").read_text(encoding="utf-8"))
        for row in run_rows:
            rows.append({**row, "run_dir": str(path)})
        sources.extend(json.loads((path / "datasets.json").read_text(encoding="utf-8")))
        runs.append({"run_dir": str(path), "metrics": metrics})
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in rows:
        grouped.setdefault((row["dataset"], row["family"]), []).append(row)
    aggregate_rows = []
    for (dataset, family), group in sorted(grouped.items()):
        count = len(group)
        aggregate_rows.append(
            {
                "dataset": dataset,
                "family": family,
                "cases": count,
                "deployment_block_rate": sum(row["deployment_answers"] == 0 for row in group)
                / count,
                "monitoring_refutation_rate": sum(row["monitoring_refuted"] > 0 for row in group)
                / count,
                "monitor_detection_rate": sum(bool(row["detected"]) for row in group) / count,
                "mean_certified_expanded": sum(row["deployment_stats"]["expanded"] for row in group)
                / count,
                "mean_unpruned_expanded": sum(
                    row["unpruned_deployment_stats"]["expanded"] for row in group
                )
                / count,
            }
        )
    with (destination / "aggregate.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = list(aggregate_rows[0]) if aggregate_rows else ["dataset", "family", "cases"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(aggregate_rows)
    attack_count = len(rows)
    controls = [
        control
        for dataset in sources
        for control in dataset.get(
            "controls", ([dataset["control"]] if dataset.get("control") is not None else [])
        )
        if control is not None
    ]
    summary_metrics = {
        "runs": len(runs),
        "datasets": len({row["dataset"] for row in rows}),
        "attack_cases": attack_count,
        "deployment_block_rate": sum(row["deployment_answers"] == 0 for row in rows) / attack_count
        if attack_count
        else 0.0,
        "monitoring_refutation_rate": sum(row["monitoring_refuted"] > 0 for row in rows)
        / attack_count
        if attack_count
        else 0.0,
        "monitor_detection_rate": sum(bool(row["detected"]) for row in rows) / attack_count
        if attack_count
        else 0.0,
        "monitor_false_alarm_rate": sum(bool(control["detected"]) for control in controls)
        / len(controls)
        if controls
        else 0.0,
    }
    (destination / "metrics.json").write_text(
        json.dumps(summary_metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (destination / "runs.json").write_text(
        json.dumps(runs, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (destination / "sources.json").write_text(
        json.dumps(sources, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (destination / "summary.md").write_text(
        "\n".join(
            [
                "# Paper 3 Replica Collection",
                "",
                f"- Completed runs: {summary_metrics['runs']}",
                f"- Datasets: {summary_metrics['datasets']}",
                f"- Labelled attack cases: {summary_metrics['attack_cases']}",
                f"- Deployment block rate: {summary_metrics['deployment_block_rate']:.3f}",
                f"- Monitoring refutation rate: {summary_metrics['monitoring_refutation_rate']:.3f}",
                f"- Sequential-monitor detection rate: {summary_metrics['monitor_detection_rate']:.3f}",
                f"- Sequential-monitor false-alarm rate on benign controls: {summary_metrics['monitor_false_alarm_rate']:.3f}",
                "",
                "`runs.json` preserves source run locations; `sources.json` preserves their input fingerprints.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    (destination / "manifest.json").write_text(
        json.dumps(
            {
                "paper": "paper3",
                "created_at_utc": datetime.now(timezone.utc).isoformat(),
                "artifacts": [
                    "aggregate.csv",
                    "metrics.json",
                    "runs.json",
                    "sources.json",
                    "summary.md",
                    "manifest.json",
                ],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    return destination


RUNNERS: dict[str, Callable[[dict[str, Any], ExperimentRun], tuple[dict[str, Any], list[str]]]] = {
    "paper1": _paper1,
    "paper2": _paper2,
    "paper3": _paper3,
}


def run_experiment(
    paper: str,
    config: dict[str, Any],
    *,
    results_root: str | Path = "results",
    name: str | None = None,
) -> Path:
    if paper not in RUNNERS:
        raise ValueError(f"Unknown paper '{paper}'. Expected one of: {', '.join(RUNNERS)}")
    declared = config.get("paper")
    if declared and declared != paper:
        raise ValueError(f"Config declares paper '{declared}', not '{paper}'")
    run = ExperimentRun(paper, config, results_root, name)
    metrics, artifacts = RUNNERS[paper](config, run)
    return run.finish(metrics, artifacts)
