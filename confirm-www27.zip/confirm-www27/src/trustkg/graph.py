from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

from .kb import KnowledgeBase, is_variable
from .reasoner import ProofState
from .runtime import TORCH_AVAILABLE, require_torch, torch
from .unify import apply_substitution

ENTITY = 0
RELATION = 1
RULE = 2
VARIABLE = 3
GOAL = 4
STATE = 5
QUERY = 6

EDGE_FACT_SUBJECT = 0
EDGE_FACT_OBJECT = 1
EDGE_RULE_BODY = 2
EDGE_RULE_HEAD = 3
EDGE_INVERSE = 4
EDGE_QUERY_STATE = 5
EDGE_STATE_GOAL = 6
EDGE_STATE_RULE = 7
EDGE_GOAL_RELATION = 8
EDGE_GOAL_ENTITY = 9
EDGE_VAR_BIND = 10
EDGE_QUERY_ENTITY = 11
EDGE_QUERY_RELATION = 12


@dataclass(frozen=True)
class StateGraph:
    node_ids: torch.Tensor
    node_types: torch.Tensor
    edge_index: torch.Tensor
    edge_type: torch.Tensor
    node_features: torch.Tensor
    graph_features: torch.Tensor
    active_mask: torch.Tensor
    query_index: int
    state_index: int
    active_goal_index: int | None


class SymbolGraphBuilder:
    def __init__(self, kb: KnowledgeBase) -> None:
        self.kb = kb
        self.node_to_id: Dict[str, int] = {}
        self.node_types: List[int] = []
        self.node_names: List[str] = []
        self.edge_src: List[int] = []
        self.edge_dst: List[int] = []
        self.edge_type: List[int] = []
        self._build_static_graph()

    def _add_node(self, name: str, node_type: int) -> int:
        if name in self.node_to_id:
            return self.node_to_id[name]
        node_id = len(self.node_names)
        self.node_to_id[name] = node_id
        self.node_names.append(name)
        self.node_types.append(node_type)
        return node_id

    def _add_edge(self, src: int, dst: int, edge_type: int) -> None:
        self.edge_src.append(src)
        self.edge_dst.append(dst)
        self.edge_type.append(edge_type)

    def _node_name(self, prefix: str, symbol: str) -> str:
        return f"{prefix}::{symbol}"

    def _ensure_entity(self, entity: str) -> int:
        return self._add_node(self._node_name("entity", entity), ENTITY)

    def _ensure_relation(self, relation: str) -> int:
        return self._add_node(self._node_name("relation", relation), RELATION)

    def _ensure_rule(self, rule: str) -> int:
        return self._add_node(self._node_name("rule", rule), RULE)

    def _build_static_graph(self) -> None:
        for entity in self.kb.entities:
            self._ensure_entity(entity)
        for relation in self.kb.predicates:
            self._ensure_relation(relation)
        for rule in self.kb.rules:
            rule_id = self._ensure_rule(rule.name)
            head_rel = self._ensure_relation(rule.head.predicate)
            self._add_edge(rule_id, head_rel, EDGE_RULE_HEAD)
            self._add_edge(head_rel, rule_id, EDGE_INVERSE)
            for atom in rule.body:
                body_rel = self._ensure_relation(atom.predicate)
                self._add_edge(body_rel, rule_id, EDGE_RULE_BODY)
                self._add_edge(rule_id, body_rel, EDGE_INVERSE)
        for fact in self.kb.facts:
            if len(fact.args) != 2:
                continue
            subj = self._ensure_entity(fact.args[0])
            rel = self._ensure_relation(fact.predicate)
            obj = self._ensure_entity(fact.args[1])
            self._add_edge(subj, rel, EDGE_FACT_SUBJECT)
            self._add_edge(rel, subj, EDGE_INVERSE)
            self._add_edge(rel, obj, EDGE_FACT_OBJECT)
            self._add_edge(obj, rel, EDGE_INVERSE)

    def build_state(self, state: ProofState) -> StateGraph:
        if not TORCH_AVAILABLE:
            require_torch("State graph construction")
        dynamic_names: List[str] = []
        dynamic_types: List[int] = []
        dynamic_features: List[List[float]] = []
        dynamic_edges: List[Tuple[int, int, int]] = []

        base_count = len(self.node_names)

        def add_dynamic(name: str, node_type: int, features: List[float]) -> int:
            node_id = base_count + len(dynamic_names)
            dynamic_names.append(name)
            dynamic_types.append(node_type)
            dynamic_features.append(features)
            return node_id

        def add_edge(src: int, dst: int, edge_type: int) -> None:
            dynamic_edges.append((src, dst, edge_type))

        substitution = state.substitution_dict()
        query = state.query or state.current_goal()
        normalized_query = apply_substitution(query, substitution) if query is not None else None
        goals = state.normalized_goals()
        active_goal = goals[0] if goals else None

        query_index = add_dynamic(
            "dynamic::query",
            QUERY,
            [
                1.0,
                0.0,
                0.0,
                0.0,
                float(len(goals)),
                float(len(substitution)),
                float(state.depth),
                0.0,
            ],
        )
        state_index = add_dynamic(
            "dynamic::state",
            STATE,
            [
                0.0,
                1.0,
                0.0,
                0.0,
                float(len(goals)),
                float(len(substitution)),
                float(state.depth),
                float(len(state.path)),
            ],
        )
        add_edge(query_index, state_index, EDGE_QUERY_STATE)
        add_edge(state_index, query_index, EDGE_INVERSE)

        if normalized_query is not None:
            relation_id = self.node_to_id.get(
                self._node_name("relation", normalized_query.predicate)
            )
            if relation_id is not None:
                add_edge(query_index, relation_id, EDGE_QUERY_RELATION)
                add_edge(relation_id, query_index, EDGE_INVERSE)
            for arg in normalized_query.args:
                if is_variable(arg):
                    continue
                entity_id = self.node_to_id.get(self._node_name("entity", arg))
                if entity_id is not None:
                    add_edge(query_index, entity_id, EDGE_QUERY_ENTITY)
                    add_edge(entity_id, query_index, EDGE_INVERSE)

        active_goal_index: int | None = None
        if active_goal is not None:
            active_goal_index = add_dynamic(
                "dynamic::active_goal",
                GOAL,
                [
                    0.0,
                    0.0,
                    1.0,
                    0.0,
                    float(len(goals)),
                    float(len(substitution)),
                    float(state.depth),
                    float(len(state.path)),
                ],
            )
            add_edge(state_index, active_goal_index, EDGE_STATE_GOAL)
            add_edge(active_goal_index, state_index, EDGE_INVERSE)
            relation_id = self.node_to_id.get(self._node_name("relation", active_goal.predicate))
            if relation_id is not None:
                add_edge(active_goal_index, relation_id, EDGE_GOAL_RELATION)
                add_edge(relation_id, active_goal_index, EDGE_INVERSE)
            for arg in active_goal.args:
                if is_variable(arg):
                    var_node = add_dynamic(
                        f"dynamic::var::{arg}",
                        VARIABLE,
                        [
                            0.0,
                            0.0,
                            0.0,
                            1.0,
                            float(len(goals)),
                            float(len(substitution)),
                            float(state.depth),
                            1.0,
                        ],
                    )
                    add_edge(active_goal_index, var_node, EDGE_GOAL_ENTITY)
                    add_edge(var_node, active_goal_index, EDGE_INVERSE)
                    continue
                entity_id = self.node_to_id.get(self._node_name("entity", arg))
                if entity_id is not None:
                    add_edge(active_goal_index, entity_id, EDGE_GOAL_ENTITY)
                    add_edge(entity_id, active_goal_index, EDGE_INVERSE)

        for index, goal in enumerate(goals[1:], start=1):
            goal_node = add_dynamic(
                f"dynamic::goal::{index}",
                GOAL,
                [
                    0.0,
                    0.0,
                    1.0,
                    0.0,
                    float(len(goals)),
                    float(len(substitution)),
                    float(state.depth),
                    float(index),
                ],
            )
            add_edge(state_index, goal_node, EDGE_STATE_GOAL)
            add_edge(goal_node, state_index, EDGE_INVERSE)
            relation_id = self.node_to_id.get(self._node_name("relation", goal.predicate))
            if relation_id is not None:
                add_edge(goal_node, relation_id, EDGE_GOAL_RELATION)
                add_edge(relation_id, goal_node, EDGE_INVERSE)
            for arg in goal.args:
                if is_variable(arg):
                    continue
                entity_id = self.node_to_id.get(self._node_name("entity", arg))
                if entity_id is not None:
                    add_edge(goal_node, entity_id, EDGE_GOAL_ENTITY)
                    add_edge(entity_id, goal_node, EDGE_INVERSE)

        for var, value in sorted(substitution.items()):
            var_node = add_dynamic(
                f"dynamic::binding::{var}",
                VARIABLE,
                [
                    0.0,
                    0.0,
                    0.0,
                    1.0,
                    float(len(goals)),
                    float(len(substitution)),
                    float(state.depth),
                    2.0,
                ],
            )
            entity_id = self.node_to_id.get(self._node_name("entity", value))
            if entity_id is not None:
                add_edge(var_node, entity_id, EDGE_VAR_BIND)
                add_edge(entity_id, var_node, EDGE_INVERSE)

        if state.path:
            last_step = state.path[-1]
            if last_step.clause_kind == "rule":
                rule_node = self.node_to_id.get(
                    self._node_name("rule", last_step.clause_name.split("__", 1)[0])
                )
                if rule_node is not None:
                    add_edge(state_index, rule_node, EDGE_STATE_RULE)
                    add_edge(rule_node, state_index, EDGE_INVERSE)

        node_names = self.node_names + dynamic_names
        node_types = torch.tensor(self.node_types + dynamic_types, dtype=torch.long)
        node_ids = torch.arange(len(node_names), dtype=torch.long)

        static_features = torch.zeros(len(self.node_names), 8, dtype=torch.float32)
        for entity in self.kb.entities:
            entity_id = self.node_to_id[self._node_name("entity", entity)]
            static_features[entity_id, 0] = 1.0
        for relation in self.kb.predicates:
            relation_id = self.node_to_id[self._node_name("relation", relation)]
            static_features[relation_id, 1] = 1.0
        for rule in self.kb.rules:
            rule_id = self.node_to_id[self._node_name("rule", rule.name)]
            static_features[rule_id, 2] = 1.0
            static_features[rule_id, 7] = float(rule.confidence)

        dynamic_tensor = (
            torch.tensor(dynamic_features, dtype=torch.float32)
            if dynamic_features
            else torch.zeros(0, 8)
        )
        node_features = torch.cat([static_features, dynamic_tensor], dim=0)

        if dynamic_edges:
            full_src = self.edge_src + [src for src, _, _ in dynamic_edges]
            full_dst = self.edge_dst + [dst for _, dst, _ in dynamic_edges]
            full_type = self.edge_type + [etype for _, _, etype in dynamic_edges]
        else:
            full_src = list(self.edge_src)
            full_dst = list(self.edge_dst)
            full_type = list(self.edge_type)

        edge_index = torch.tensor([full_src, full_dst], dtype=torch.long)
        edge_type = torch.tensor(full_type, dtype=torch.long)

        candidate_count = 0
        if active_goal is not None:
            candidate_count = len(self.kb.candidate_clauses(active_goal)[1]) + len(
                self.kb.candidate_clauses(active_goal)[0]
            )

        graph_features = torch.tensor(
            [
                float(state.depth),
                float(len(goals)),
                float(len(substitution)),
                float(len(state.path)),
                float(candidate_count),
                float(len(dynamic_names)),
            ],
            dtype=torch.float32,
        )

        active_mask = torch.zeros(len(node_names), dtype=torch.bool)
        active_mask[state_index] = True
        active_mask[query_index] = True
        if active_goal_index is not None:
            active_mask[active_goal_index] = True
        for idx in range(base_count, len(node_names)):
            if node_types[idx] in (VARIABLE, GOAL):
                active_mask[idx] = True

        return StateGraph(
            node_ids=node_ids,
            node_types=node_types,
            edge_index=edge_index,
            edge_type=edge_type,
            node_features=node_features,
            graph_features=graph_features,
            active_mask=active_mask,
            query_index=query_index,
            state_index=state_index,
            active_goal_index=active_goal_index,
        )
