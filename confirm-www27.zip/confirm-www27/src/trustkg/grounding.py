"""Ground Horn-rule bodies against a finite fact collection."""

from __future__ import annotations

from collections.abc import Iterator, Mapping, Sequence

from .kb import Atom, Rule, is_variable


def unify_ground_atom(atom: Atom, fact: Atom, binding: Mapping[str, str]) -> dict[str, str] | None:
    if atom.predicate != fact.predicate or len(atom.args) != len(fact.args):
        return None
    updated = dict(binding)
    for term, value in zip(atom.args, fact.args):
        if is_variable(term):
            if term in updated and updated[term] != value:
                return None
            updated[term] = value
        elif term != value:
            return None
    return updated


def ground_atom(atom: Atom, binding: Mapping[str, str]) -> Atom | None:
    args: list[str] = []
    for term in atom.args:
        if is_variable(term):
            if term not in binding:
                return None
            args.append(binding[term])
        else:
            args.append(term)
    return Atom(atom.predicate, tuple(args))


def find_rule_grounding(
    rule: Rule, facts_by_predicate: Mapping[str, Sequence[Atom]]
) -> tuple[dict[str, str], tuple[Atom, ...]] | None:
    """Return one complete body grounding, preferring selective atoms first."""
    ordered = sorted(rule.body, key=lambda atom: len(facts_by_predicate.get(atom.predicate, ())))

    def visit(
        index: int, binding: dict[str, str], support: list[Atom]
    ) -> tuple[dict[str, str], tuple[Atom, ...]] | None:
        if index == len(ordered):
            return binding, tuple(support)
        atom = ordered[index]
        for fact in facts_by_predicate.get(atom.predicate, ()):
            updated = unify_ground_atom(atom, fact, binding)
            if updated is None:
                continue
            result = visit(index + 1, updated, [*support, fact])
            if result is not None:
                return result
        return None

    return visit(0, {}, [])


def iter_rule_groundings(
    rule: Rule,
    facts_by_predicate: Mapping[str, Sequence[Atom]],
    *,
    limit: int | None = None,
) -> Iterator[tuple[dict[str, str], tuple[Atom, ...]]]:
    """Yield distinct complete body groundings, most selective atoms first."""
    if limit is not None and limit < 1:
        return
    ordered = sorted(rule.body, key=lambda atom: len(facts_by_predicate.get(atom.predicate, ())))
    yielded = 0
    seen: set[tuple[tuple[tuple[str, str], ...], tuple[Atom, ...]]] = set()

    def visit(
        index: int, binding: dict[str, str], support: list[Atom]
    ) -> Iterator[tuple[dict[str, str], tuple[Atom, ...]]]:
        nonlocal yielded
        if limit is not None and yielded >= limit:
            return
        if index == len(ordered):
            key = (tuple(sorted(binding.items())), tuple(support))
            if key not in seen:
                seen.add(key)
                yielded += 1
                yield dict(binding), tuple(support)
            return
        atom = ordered[index]
        for fact in facts_by_predicate.get(atom.predicate, ()):
            updated = unify_ground_atom(atom, fact, binding)
            if updated is not None:
                yield from visit(index + 1, updated, [*support, fact])
            if limit is not None and yielded >= limit:
                return

    yield from visit(0, {}, [])
