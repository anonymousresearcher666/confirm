from __future__ import annotations

import random

from .kb import KnowledgeBase
from .reasoner import ProofState


def shortest_path_heuristic(state: ProofState, kb: KnowledgeBase) -> float:
    return -float(len(state.goals) + state.depth)


def rule_confidence_heuristic(state: ProofState, kb: KnowledgeBase) -> float:
    goal = state.current_goal()
    if goal is None:
        return 1.0
    confidence = 0.0
    for rule in kb.rules_for(goal.predicate):
        confidence = max(confidence, rule.confidence)
    if kb.facts_for(goal.predicate):
        confidence = max(confidence, 0.5)
    return confidence - 0.01 * state.depth


def random_heuristic(state: ProofState, kb: KnowledgeBase) -> float:
    return random.random()
