"""Standalone checker for four logical pruning classes plus exact-state C-SUBSUME.

No imports from the ConFIRM reasoner. The trusted KB snapshot is supplied
SEPARATELY from the untrusted certificate. Scope: deployment C-PRE,
C-TYPE, C-DEPTH and C-UNSAT, under finite range-restricted Horn rules.
C-SUBSUME checks only proof-sensitive exact-state dedup against a trusted
prior-state log, NOT general logical subsumption.
"""
from __future__ import annotations
import hashlib
import json

def _hash(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=True).encode()).hexdigest()

class PreparedSnapshot:
    """One-time immutable-by-contract snapshot copy with precomputed indexes.

    Preparation clones the input via JSON normalization, computes its digest,
    and indexes facts/rules by predicate and ground-term position. The caller must obtain the snapshot
    from a trusted source; this object does NOT authenticate the producer's
    transcript or search history. Treat instances as read-only.
    """

    __slots__ = (
        "_data", "_sha256", "_facts_by_predicate", "_rules_by_predicate",
        "_facts_by_signature", "_fact_postings", "_fact_wildcards",
    )

    def __init__(self, snapshot: dict, *, expected_sha256: str | None = None):
        if type(snapshot) is not dict:
            raise TypeError("snapshot must be a JSON dictionary")
        canonical = json.dumps(
            snapshot, sort_keys=True, separators=(",", ":"), ensure_ascii=True
        )
        digest = hashlib.sha256(canonical.encode()).hexdigest()
        if expected_sha256 is not None and digest != expected_sha256:
            raise ValueError("Trusted snapshot SHA-256 mismatch")
        data = json.loads(canonical)
        facts: dict[str, list] = {}
        rules: dict[str, list] = {}
        signatures: dict[tuple, list] = {}
        postings: dict[tuple, list] = {}
        wildcards: dict[tuple, list] = {}
        for fact in data["facts"]:
            predicate = fact["predicate"]
            args = fact["args"]
            arity = len(args)
            facts.setdefault(predicate, []).append(fact)
            signatures.setdefault((predicate, arity), []).append(fact)
            for position, value in enumerate(args):
                if value.startswith("?"):
                    wildcards.setdefault(
                        (predicate, arity, position), []
                    ).append(fact)
                else:
                    postings.setdefault(
                        (predicate, arity, position, value), []
                    ).append(fact)
        for rule in data["rules"]:
            rules.setdefault(rule["head"]["predicate"], []).append(rule)
        self._data = data
        self._sha256 = digest
        self._facts_by_predicate = {
            key: tuple(value) for key, value in facts.items()
        }
        self._rules_by_predicate = {
            key: tuple(value) for key, value in rules.items()
        }
        self._facts_by_signature = {
            key: tuple(value) for key, value in signatures.items()
        }
        self._fact_postings = {
            key: tuple(value) for key, value in postings.items()
        }
        self._fact_wildcards = {
            key: tuple(value) for key, value in wildcards.items()
        }

    @property
    def sha256(self) -> str:
        return self._sha256


def _valid_atom(atom):
    return (type(atom) is dict and set(atom) == {"predicate", "args"}
            and type(atom["predicate"]) is str and type(atom["args"]) is list
            and all(type(x) is str for x in atom["args"]))

def _match(a, b):
    if a["predicate"] != b["predicate"] or len(a["args"]) != len(b["args"]):
        return False
    # Clauses are standardized apart; variables on either side may unify.
    mapping = {}
    def deref(x):
        visited = set()
        while x in mapping and x not in visited:
            visited.add(x)
            x = mapping[x]
        return x
    for i, (left, right) in enumerate(zip(a["args"], b["args"])):
        left = deref(("g",left) if left.startswith("?") else ("c",left))
        right = deref(("r",right) if right.startswith("?") else ("c",right))
        if left == right: continue
        if left[0] in ("g","r"): mapping[left] = right
        elif right[0] in ("g","r"): mapping[right] = left
        else: return False
    return True

def _clauses(goal, snapshot, prepared=None):
    if prepared is None:
        facts = snapshot["facts"]
        rules = snapshot["rules"]
    else:
        predicate = goal["predicate"]
        arity = len(goal["args"])
        # Position postings narrow high-degree predicates without silently
        # excluding variable-containing fact clauses. For a constant goal
        # term, a unifiable fact must have either the same constant or a
        # variable in that position. Keep _match() as the final authority,
        # including repeated-variable consistency.
        facts = prepared._facts_by_signature.get((predicate, arity), ())
        smallest = len(facts)
        for position, value in enumerate(goal["args"]):
            if value.startswith("?"):
                continue
            exact = prepared._fact_postings.get(
                (predicate, arity, position, value), ()
            )
            variable = prepared._fact_wildcards.get(
                (predicate, arity, position), ()
            )
            size = len(exact) + len(variable)
            if size < smallest:
                # The selected candidate groups are disjoint at this
                # position; no duplicate fact object is introduced.
                facts = (*exact, *variable)
                smallest = size
                if not smallest:
                    break
        rules = prepared._rules_by_predicate.get(predicate, ())
    for fact in facts:
        if _match(goal, fact):
            yield "fact"
    for rule in rules:
        if rule["status"] != "rejected" and _match(goal, rule["head"]):
            yield "rule"

def _reason(goal, snapshot, prepared=None):
    if any(x.startswith("?") for x in goal["args"]): return None
    if goal in snapshot["negatives"]: return "explicit-negative"
    if len(goal["args"]) != 2: return None
    subj, obj = goal["args"]
    p = goal["predicate"]; schema = snapshot["schema"]
    if p in schema["irreflexive"] and subj == obj: return "irreflexivity"
    for entity, need in ((subj,schema["domain"].get(p)), (obj,schema["range"].get(p))):
        if need and any(sorted((actual, need)) in schema["disjoint"]
                        for actual in schema["types"].get(entity, [])):
            return "type"
    if p in schema["functional"]:
        if any(f["predicate"] == p and f["args"] and len(f["args"]) == 2
               and f["args"][0] == subj and f["args"][1] != obj
               for f in (snapshot["facts"] if prepared is None
                         else prepared._facts_by_predicate.get(p, ()))): return "functionality"
    return None

def _unsat_type_obligations(goals, snapshot, witness):
    """Independently reconstruct a type-obligation contradiction.

    A witness is [term, first_class, second_class]. Each obligation must
    follow from the trusted schema and a goal of the trusted search state.
    The disjointness axiom must be present in the trusted schema.
    """
    if (type(witness) is not list or len(witness) != 3
            or not all(type(item) is str for item in witness)):
        return False
    term, first, second = witness
    if first == second:
        return False
    schema = snapshot["schema"]
    if not any(type(pair) is list and len(pair) == 2
               and set(pair) == {first, second}
               for pair in schema["disjoint"]):
        return False
    obligations = {}
    for goal in goals:
        if len(goal["args"]) != 2:
            continue
        predicate = goal["predicate"]
        for entity, required in (
            (goal["args"][0], schema["domain"].get(predicate)),
            (goal["args"][1], schema["range"].get(predicate)),
        ):
            if type(required) is str:
                obligations.setdefault(entity, set()).add(required)
    return {first, second}.issubset(obligations.get(term, set()))



def _valid_subsumption_state(state):
    """Validate a serialized state WITHOUT trusting the producing reasoner."""
    if type(state) is not dict or set(state) != {
        "query", "goals", "proof", "substitution", "depth"
    }:
        return False
    if not _valid_atom(state["query"]):
        return False
    if type(state["depth"]) is not int or state["depth"] < 0:
        return False
    if (type(state["goals"]) is not list or not state["goals"]
            or not all(_valid_atom(g) for g in state["goals"])):
        return False
    if type(state["proof"]) is not list:
        return False
    for step in state["proof"]:
        if (type(step) is not dict or set(step) != {"rule", "atom"}
                or type(step["rule"]) is not str
                or not _valid_atom(step["atom"])):
            return False
    pairs = state["substitution"]
    if (type(pairs) is not list
            or not all(
                type(pair) is list and len(pair) == 2
                and all(type(term) is str for term in pair)
                for pair in pairs
            )):
        return False
    return True


def _verify_subsumption(evidence, trusted_state, trusted_history):
    """Only exact proof-sensitive dedup against EXTERNALLY trusted prior log.

    The producer may choose an index but cannot create, replace or move
    entries in the trusted history. The caller must log ONLY earlier expanded
    states, not the current or future states. This checks exact-key equality
    and previous_depth <= current_depth, never general subsumption.
    """
    current = trusted_state
    if not _valid_subsumption_state(current):
        return False
    if type(trusted_history) not in (list, tuple):
        return False
    witness = evidence.get("witness")
    if type(witness) is not dict or set(witness) != {"seen_index"}:
        return False
    index = witness["seen_index"]
    if type(index) is not int or index < 0 or index >= len(trusted_history):
        return False
    previous = trusted_history[index]
    if not _valid_subsumption_state(previous):
        return False
    signature_keys = ("query", "goals", "proof", "substitution")
    return (
        all(previous[key] == current[key] for key in signature_keys)
        and previous["depth"] <= current["depth"]
    )


def verify(
    evidence: dict,
    trusted_snapshot: dict | PreparedSnapshot,
    *,
    trusted_state: dict | None = None,
    trusted_max_depth: int | None = None,
    trusted_history: list[dict] | tuple[dict, ...] | None = None,
) -> bool:
    """Verify against an independently supplied snapshot, state and policy.

    For security-sensitive use both trusted_state and trusted_max_depth are mandatory.
    Legacy two-argument calls are deliberately rejected (fail closed).
    """
    try:
        if type(evidence) is not dict:
            return False
        prepared = None
        if type(trusted_snapshot) is PreparedSnapshot:
            prepared = trusted_snapshot
            snapshot = prepared._data
            expected_digest = prepared.sha256
        elif type(trusted_snapshot) is dict:
            snapshot = trusted_snapshot
            expected_digest = _hash(snapshot)
        else:
            return False
        if type(trusted_state) is not dict or type(trusted_max_depth) is not int:
            return False
        if (evidence.get("state") != trusted_state
                or evidence.get("max_depth") != trusted_max_depth):
            return False
        if evidence["snapshot_sha256"] != expected_digest:
            return False
        kind = evidence["kind"]; state = evidence["state"]
        if kind == "C-SUBSUME":
            return (evidence["version"] == 2
                    and _verify_subsumption(evidence, trusted_state, trusted_history))
        if evidence["version"] != 1:
            return False
        goals = state["goals"]; depth = state["depth"]; limit = evidence["max_depth"]
        if kind not in ("C-PRE","C-TYPE","C-DEPTH","C-UNSAT"): return False
        if type(depth) is not int or type(limit) is not int or depth < 0 or limit < 0:
            return False
        if type(goals) is not list or not goals or not all(_valid_atom(g) for g in goals):
            return False
        if kind == "C-PRE":
            return evidence["witness"] == goals[0] and not any(_clauses(goals[0], snapshot, prepared))
        if kind == "C-TYPE":
            return (type(evidence["witness"]) is dict and
                    evidence["witness"] in goals and _reason(evidence["witness"], snapshot, prepared) is not None)
        if kind == "C-UNSAT":
            return _unsat_type_obligations(goals, snapshot, evidence["witness"])
        if kind == "C-DEPTH":
            # Each goal lacking a matching fact needs >= 1 rule application;
            # if it also lacks a rule, C-PRE can establish infeasibility.
            lower = sum(not any(c == "fact" for c in _clauses(g, snapshot, prepared))
                        and any(c == "rule" for c in _clauses(g, snapshot, prepared))
                        for g in goals)
            return evidence["witness"] == [depth, lower, limit] and depth + lower > limit
        return False
    except (KeyError, TypeError, ValueError, IndexError, AttributeError):
        return False
