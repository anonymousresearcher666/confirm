"""Independent GO audit source: trusted snapshot, states and exact transitions.

This file deliberately imports NEITHER trustkg.trust, trustkg.kb,
trustkg.unify NOR the producer's trace-generation helpers.
The input root query and KB are loaded separately from trusted files.
Producer events are treated as untrusted claims about search transitions.
"""
from __future__ import annotations

import hashlib
import heapq
import itertools
import json
from collections import Counter, defaultdict
from pathlib import Path
from time import perf_counter

from trustkg.independent_checker import PreparedSnapshot, verify


def canonical_sha256(data):
    return hashlib.sha256(
        json.dumps(data, sort_keys=True, separators=(",", ":"),
                   ensure_ascii=True).encode()
    ).hexdigest()


def atom(predicate, args):
    return {"predicate": predicate, "args": list(args)}


def trusted_go_snapshot(root):
    """GO trusted input loader, NOT using producer context/serialization."""
    root = Path(root)
    def load(path):
        with path.open(encoding="utf-8") as handle:
            return [json.loads(line) for line in handle if line.strip()]
    facts = [
        atom(line["predicate"], line["args"])
        for line in load(root / "facts.jsonl")
    ]
    rules = []
    for line in load(root / "trusted_rules.jsonl"):
        compiled = line["compiled_expression"]
        rules.append({
            "name": line["rule_id"],
            "head": atom(compiled["head"]["predicate"], compiled["head"]["args"]),
            "body": [
                atom(a["predicate"], a["args"]) for a in compiled["body"]
            ],
            "status": line.get("status", "trusted"),
        })
    schema = json.loads((root / "schema.json").read_text(encoding="utf-8"))
    safe_schema = {
        "types": {k: sorted(v) for k, v in schema.get("types", {}).items()},
        "domain": schema.get("domain", {}),
        "range": schema.get("range", {}),
        "disjoint": sorted(sorted(pair) for pair in schema.get("disjoint", [])),
        "functional": sorted(schema.get("functional", [])),
        "irreflexive": sorted(schema.get("irreflexive", [])),
    }
    negative_path = root / "negatives.jsonl"
    negatives = [
        atom(line["predicate"], line["args"])
        for line in load(negative_path)
    ] if negative_path.is_file() else []
    statuses = {"trusted", "candidate", "rejected"}
    if any(rule["status"] not in statuses for rule in rules):
        raise ValueError("Unrecognized trusted-source rule status")
    return {
        "facts": facts, "rules": rules, "negatives": negatives,
        "schema": safe_schema,
    }


def isvar(term):
    return term.startswith("?")


def resolve(term, subst):
    visited = set()
    while isvar(term) and term in subst and term not in visited:
        visited.add(term)
        term = subst[term]
    return term


def apply(a, subst):
    return atom(a["predicate"], [resolve(x, subst) for x in a["args"]])


def unify(a, b, subst):
    if a["predicate"] != b["predicate"] or len(a["args"]) != len(b["args"]):
        return None
    out = dict(subst)
    for left, right in zip(a["args"], b["args"]):
        left = resolve(left, out)
        right = resolve(right, out)
        if left == right:
            continue
        if isvar(left):
            out[left] = right
        elif isvar(right):
            out[right] = left
        else:
            return None
    return out


def substitutions(state):
    pairs = state["substitution"]
    if (type(pairs) is not list or not all(
        type(p) is list and len(p) == 2
        and all(type(v) is str for v in p) for p in pairs
    )):
        raise ValueError("invalid substitution representation")
    if len({p[0] for p in pairs}) != len(pairs):
        raise ValueError("duplicate substitution variable")
    return dict(pairs)


def normalized(state):
    subst = substitutions(state)
    return {
        "query": apply(state["query"], subst),
        "goals": [apply(goal, subst) for goal in state["goals"]],
        "proof": [
            {"rule": step["rule"], "atom": apply(step["atom"], subst)}
            for step in state["proof"]
        ],
        "substitution": state["substitution"],
        "depth": state["depth"],
    }


def _vars_in(state):
    items = [state["query"], *state["goals"]]
    items += [step["atom"] for step in state["proof"]]
    variables = {arg for a in items for arg in a["args"] if isvar(arg)}
    for k, v in state["substitution"]:
        if isvar(k):
            variables.add(k)
        if isvar(v):
            variables.add(v)
    return variables


def _child_key(state, parent):
    """Alpha-normalize ONLY the new variables; parent vars stay anchored.

    Fresh producer rule suffixes differ from our independent freshening,
    but pre-existing parent variables must NOT be renamed/rebound.
    """
    anchored = _vars_in(parent)
    new = {}
    def mapped(x):
        if isvar(x) and x not in anchored:
            if x not in new:
                new[x] = f"?__new{len(new)}"
            return new[x]
        return x
    def converted(a):
        return [a["predicate"], [mapped(x) for x in a["args"]]]
    # Inspect query/goals/proof before substitution to preserve semantic
    # variable identities across old and newly freshened rule variables.
    representation = [
        converted(state["query"]),
        [converted(x) for x in state["goals"]],
        [[step["rule"], converted(step["atom"])] for step in state["proof"]],
    ]
    pairs = sorted(
        [[mapped(k), mapped(v)] for k, v in state["substitution"]],
        key=lambda item: (item[0], item[1]),
    )
    representation += [pairs, state["depth"]]
    return json.dumps(representation, sort_keys=True, separators=(",", ":"))


def _check_atom(a):
    return (
        type(a) is dict and set(a) == {"predicate", "args"}
        and type(a["predicate"]) is str
        and type(a["args"]) is list
        and all(type(x) is str for x in a["args"])
    )


def _check_state(s):
    if type(s) is not dict or set(s) != {
        "query", "goals", "proof", "substitution", "depth"
    }:
        return False
    if not _check_atom(s["query"]):
        return False
    if type(s["goals"]) is not list or not all(_check_atom(a) for a in s["goals"]):
        return False
    if type(s["proof"]) is not list or not all(
        type(p) is dict and set(p) == {"rule", "atom"}
        and type(p["rule"]) is str and _check_atom(p["atom"])
        for p in s["proof"]
    ):
        return False
    if type(s["depth"]) is not int or s["depth"] < 0:
        return False
    try:
        subst = substitutions(s)
    except (TypeError, ValueError):
        return False
    return all(isvar(k) for k in subst)


def _compatible_type(entity, need, schema):
    actuals = schema["types"].get(entity, ())
    if need in actuals:
        return True
    disjoint = {frozenset(pair) for pair in schema["disjoint"]}
    return not any(frozenset((actual, need)) in disjoint for actual in actuals)


class TrustedGOIndex:
    def __init__(self, snapshot):
        self.snapshot = snapshot
        self.prepared = PreparedSnapshot(snapshot)
        self.rules = defaultdict(list)
        self.fact_positions = defaultdict(list)
        self.fact_wildcards = defaultdict(list)
        self.facts_by_signature = defaultdict(list)
        self.function_values = defaultdict(set)
        for pos, fact in enumerate(snapshot["facts"]):
            p = fact["predicate"]
            args = fact["args"]
            self.facts_by_signature[(p, len(args))].append((pos, fact))
            for i, value in enumerate(args):
                if isvar(value):
                    self.fact_wildcards[(p, len(args), i)].append((pos, fact))
                else:
                    self.fact_positions[(p, len(args), i, value)].append((pos, fact))
            if p in snapshot["schema"]["functional"] and len(args) == 2:
                self.function_values[(p, args[0])].add(args[1])
        for rule in snapshot["rules"]:
            self.rules[rule["head"]["predicate"]].append(rule)
        self.negatives = {
            (a["predicate"], tuple(a["args"])) for a in snapshot["negatives"]
        }
        self.disjoint = {
            frozenset(pair) for pair in snapshot["schema"]["disjoint"]
        }

    def matching_facts(self, goal):
        p = goal["predicate"]
        arity = len(goal["args"])
        selected = self.facts_by_signature.get((p, arity), [])
        smallest = len(selected)
        for i, value in enumerate(goal["args"]):
            if isvar(value):
                continue
            exact = self.fact_positions.get((p, arity, i, value), ())
            variable = self.fact_wildcards.get((p, arity, i), ())
            size = len(exact) + len(variable)
            if size < smallest:
                selected = [*exact, *variable]
                smallest = size
                if not smallest:
                    break
        # Same original fact ordering as the engine's facts_for(predicate).
        for _, fact in sorted(selected, key=lambda pair: pair[0]):
            yield fact

    def consistent(self, state):
        n = normalized(state)
        atoms = [*n["goals"], *(p["atom"] for p in n["proof"])]
        ground = [a for a in atoms if not any(isvar(x) for x in a["args"])]
        schema = self.snapshot["schema"]
        required = defaultdict(set)
        functional = {}
        for a in ground:
            p = a["predicate"]
            args = a["args"]
            if (p, tuple(args)) in self.negatives:
                return False
            if len(args) != 2:
                continue
            subj, obj = args
            if p in schema["irreflexive"] and subj == obj:
                return False
            dom = schema["domain"].get(p)
            ran = schema["range"].get(p)
            if dom:
                if not _compatible_type(subj, dom, schema):
                    return False
                required[subj].add(dom)
            if ran:
                if not _compatible_type(obj, ran, schema):
                    return False
                required[obj].add(ran)
            if p in schema["functional"]:
                if any(value != obj for value in self.function_values.get((p, subj), ())):
                    return False
                key = (p, subj)
                if key in functional and functional[key] != obj:
                    return False
                functional[key] = obj
        return not any(
            frozenset((left, right)) in self.disjoint
            for classes in required.values()
            for left in classes for right in classes if left != right
        )

    def terminal_consistent(self, state):
        """Independent equivalent of completed proof validation.

        A completed proof has no goals. In addition to refuting ground
        proof atoms, check symbolic variable type obligations even before
        they become ground, exactly as the engine's completed-proof guard.
        """
        if state["goals"]:
            return False
        if not self.consistent(state):
            return False
        proof = normalized(state)["proof"]
        schema = self.snapshot["schema"]
        required = defaultdict(set)
        for step in proof:
            a = step["atom"]
            if len(a["args"]) != 2:
                continue
            subj, obj = a["args"]
            dom = schema["domain"].get(a["predicate"])
            ran = schema["range"].get(a["predicate"])
            if dom:
                required[subj].add(dom)
            if ran:
                required[obj].add(ran)
        return not any(
            frozenset((left, right)) in self.disjoint
            for classes in required.values()
            for left in classes for right in classes if left != right
        )

    def children(self, state):
        subst = substitutions(state)
        if not state["goals"]:
            return []
        goal = apply(state["goals"][0], subst)
        rest = state["goals"][1:]
        children = []
        for fact in self.matching_facts(goal):
            updated = unify(goal, fact, subst)
            if updated is None:
                continue
            child = {
                "query": state["query"], "goals": rest,
                "substitution": [list(x) for x in sorted(updated.items())],
                "proof": [*state["proof"], {"rule": "fact", "atom": fact}],
                "depth": state["depth"],
            }
            if self.consistent(child):
                children.append(child)
        for i, rule in enumerate(self.rules.get(goal["predicate"], ())):
            if rule["status"] == "rejected":
                continue
            # Names are arbitrary but guaranteed apart from existing vars.
            new_vars = {}
            def rename(x):
                if not isvar(x):
                    return x
                if x not in new_vars:
                    new_vars[x] = f"?__AUDIT_FRESH_{i}_{len(new_vars)}"
                return new_vars[x]
            head = atom(rule["head"]["predicate"], [
                rename(x) for x in rule["head"]["args"]
            ])
            body = [
                atom(a["predicate"], [rename(x) for x in a["args"]])
                for a in rule["body"]
            ]
            updated = unify(goal, head, subst)
            if updated is None:
                continue
            child = {
                "query": state["query"],
                "goals": [*body, *rest],
                "substitution": [list(x) for x in sorted(updated.items())],
                "proof": [
                    *state["proof"], {"rule": rule["name"], "atom": goal}
                ],
                "depth": state["depth"] + 1,
            }
            if self.consistent(child):
                children.append(child)
        return children


def replay_trace(trace, trusted_queries, index, *, max_depth, max_events=100000):
    """Strict frontier replay; no supplied state/history is trusted blindly.

    Child lists are re-derived from the independently loaded trusted KB and
    checked exactly (modulo fresh variable alpha-renaming). Pop order, depth,
    terminal events, individual certificate witnesses and the source log of
    expanded states are independently enforced. A complete frontier is needed.
    """
    start = perf_counter()
    failures = []
    results = []
    for qi, expected_query in enumerate(trusted_queries):
        if qi >= len(trace.get("queries", ())):
            failures.append({"query_index": qi, "reason": "missing_query_trace"})
            continue
        qtrace = trace["queries"][qi]
        if qtrace.get("query") != expected_query:
            failures.append({"query_index": qi, "reason": "wrong_external_query"})
            continue
        root = {
            "query": expected_query, "goals": [expected_query],
            "proof": [], "substitution": [], "depth": 0,
        }
        heap = [(0, 0, root)]
        serial = itertools.count(1)
        history = []
        counts = Counter()
        events = qtrace.get("events")
        if type(events) is not list or len(events) > max_events:
            failures.append({"query_index": qi, "reason": "invalid_event_list"})
            continue
        checked_children = 0
        for pos, event in enumerate(events):
            if type(event) is not dict or event.get("type") not in (
                "expanded", "certificate", "terminal"
            ):
                failures.append({"query_index": qi, "event": pos,
                                 "reason": "unknown_event"})
                break
            while heap and heap[0][2]["depth"] > max_depth:
                heapq.heappop(heap)
            if not heap:
                failures.append({"query_index": qi, "event": pos,
                                 "reason": "extra_event"})
                break
            _, _, expected = heapq.heappop(heap)
            actual = event.get("state")
            if not _check_state(actual) or actual != expected:
                failures.append({"query_index": qi, "event": pos,
                                 "reason": "frontier_state_or_order_mismatch"})
                break
            kind = event["type"]
            if kind == "terminal":
                if expected["goals"] or event.get("consistent") is not index.terminal_consistent(expected):
                    failures.append({"query_index": qi, "event": pos,
                                     "reason": "invalid_terminal"})
                    break
            elif kind == "certificate":
                if not expected["goals"]:
                    failures.append({"query_index": qi, "event": pos,
                                     "reason": "certified_terminal"})
                    break
                evidence = event.get("evidence")
                if type(evidence) is not dict or not verify(
                    evidence, index.prepared,
                    trusted_state=normalized(expected) if evidence.get("kind") == "C-SUBSUME"
                    else {"goals": normalized(expected)["goals"], "depth": expected["depth"]},
                    trusted_max_depth=max_depth,
                    trusted_history=history,
                ):
                    failures.append({"query_index": qi, "event": pos,
                                     "reason": "invalid_certificate_or_history"})
                    break
                counts[evidence["kind"]] += 1
            else:
                if not expected["goals"]:
                    failures.append({"query_index": qi, "event": pos,
                                     "reason": "expanded_terminal"})
                    break
                producer_children = event.get("children")
                if type(producer_children) is not list or not all(
                    _check_state(c) for c in producer_children
                ):
                    failures.append({"query_index": qi, "event": pos,
                                     "reason": "malformed_children"})
                    break
                independently_generated = index.children(expected)
                if len(independently_generated) != len(producer_children):
                    failures.append({"query_index": qi, "event": pos,
                                     "reason": "missing_or_extra_child",
                                     "expected": len(independently_generated),
                                     "observed": len(producer_children)})
                    break
                # The expected child order is semantically significant:
                # best-first tie-breaking uses original fact/rule order.
                good = all(
                    _child_key(given, expected) == _child_key(calculated, expected)
                    for given, calculated in zip(
                        producer_children, independently_generated
                    )
                )
                if not good:
                    failures.append({"query_index": qi, "event": pos,
                                     "reason": "illegal_transition_or_child_order"})
                    break
                history.append(normalized(expected))
                checked_children += len(producer_children)
                for child in producer_children:
                    heapq.heappush(heap, (child["depth"], next(serial), child))
        else:
            while heap and heap[0][2]["depth"] > max_depth:
                heapq.heappop(heap)
            if heap:
                failures.append({
                    "query_index": qi, "reason": "missing_events_or_unfinished_frontier",
                    "pending": len(heap),
                })
        results.append({
            "query_index": qi, "events": len(events),
            "checked_children": checked_children,
            "expanded_states": len(history),
            "certificates_by_kind": dict(counts),
        })
    if len(trace.get("queries", ())) != len(trusted_queries):
        failures.append({"reason": "query_count_mismatch"})
    return {
        "passed": not failures,
        "failures": failures,
        "queries": len(trusted_queries),
        "results": results,
        "certificate_count": sum(
            sum(r["certificates_by_kind"].values()) for r in results
        ),
        "elapsed_seconds": round(perf_counter() - start, 6),
        "trust_model": (
            "Trusted local GO files and query indices are separately supplied. "
            "The verifier independently derives exact successors and checks "
            "the best-first frontier and prior expanded-state history. "
            "It does not cryptographically attest the GO files, and does "
            "not independently reconstruct aggregated answer verdicts."
        ),
    }
