"""Independent reconstruction of final proof/claim verdicts from v2 audit.

This code does NOT import the producer reasoner, its status classifier,
or its aggregation function. Run ONLY after full transition replay accepted
the trace: terminal events must then be independently reconstructed states.
Trusted rule statuses and schema come from independently loaded GO inputs.
"""
from __future__ import annotations

from collections import defaultdict

from .independent_transition_audit import isvar, normalized, canonical_sha256


def _key_atom(value):
    return value["predicate"], tuple(value["args"])


def _ground(value):
    return all(not isvar(term) for term in value["args"])


def _refutation_reason(atoms, index):
    """Reimplement producer's finite deployment refutation checks."""
    schema = index.snapshot["schema"]
    ground_atoms = [a for a in atoms if _ground(a)]
    for a in ground_atoms:
        p, args = a["predicate"], a["args"]
        if (p, tuple(args)) in index.negatives:
            return "explicit-negative"
        if len(args) != 2:
            continue
        sub, obj = args
        if p in schema["irreflexive"] and sub == obj:
            return "irreflexivity"
        domain = schema["domain"].get(p)
        if domain and not _type_ok(sub, domain, index):
            return "domain-violation"
        range_ = schema["range"].get(p)
        if range_ and not _type_ok(obj, range_, index):
            return "range-violation"
        if p in schema["functional"] and any(
            val != obj for val in index.function_values.get((p, sub), ())
        ):
            return "functionality"

    values = {}
    required = defaultdict(set)
    for a in ground_atoms:
        p, args = a["predicate"], a["args"]
        if len(args) != 2:
            continue
        sub, obj = args
        d = schema["domain"].get(p)
        r = schema["range"].get(p)
        if d:
            required[sub].add(d)
        if r:
            required[obj].add(r)
        if p in schema["functional"]:
            key = (p, sub)
            if key in values and values[key] != obj:
                return "functionality"
            values[key] = obj
    for types in required.values():
        for a in types:
            for b in types:
                if a != b and frozenset((a, b)) in index.disjoint:
                    return "type-obligation-conflict"
    return None


def _type_ok(entity, required, index):
    present = index.snapshot["schema"]["types"].get(entity, ())
    if required in present:
        return True
    return not any(
        frozenset((actual, required)) in index.disjoint for actual in present
    )


def reconstructed_decisions(events, index):
    """Return engine-compatible sorted [claim,status,trusted,candidate] rows.

    Preserve proof trace identity and deduplicate exactly as the producer:
    its answer keys are (ground claim, normalized ordered proof). The
    producer ignores nonground query conclusions and terminal states whose
    completion-level schema/type obligations are inconsistent.
    """
    statuses = {r["name"]: r["status"] for r in index.snapshot["rules"]}
    seen = set()
    claims = defaultdict(list)

    for event in events:
        if event["type"] != "terminal":
            continue
        state = event["state"]
        if not event["consistent"] or not index.terminal_consistent(state):
            continue
        item = normalized(state)
        claim = item["query"]
        if not _ground(claim):
            continue
        proof = item["proof"]
        proof_key = tuple(
            (step["rule"], _key_atom(step["atom"])) for step in proof
        )
        key = (_key_atom(claim), proof_key)
        if key in seen:
            continue
        seen.add(key)
        reason = _refutation_reason(
            [step["atom"] for step in proof] + [claim], index
        )
        if reason is not None:
            status = "REFUTED"
        else:
            used = [x["rule"] for x in proof if x["rule"] != "fact"]
            if any(statuses.get(name, "candidate") == "rejected" for name in used):
                raise ValueError("A completed proof contains a rejected rule")
            status = (
                "PROVEN"
                if all(statuses.get(name, "candidate") == "trusted" for name in used)
                else "HYPOTHESIZED"
            )
        claims[_key_atom(claim)].append(status)

    decisions = []
    for (predicate, args), evidence in claims.items():
        trusted = evidence.count("PROVEN")
        candidate = evidence.count("HYPOTHESIZED")
        status = (
            "PROVEN" if trusted else
            "HYPOTHESIZED" if candidate else
            "REFUTED"
        )
        decisions.append([
            {"predicate": predicate, "args": list(args)},
            status, trusted, candidate,
        ])
    return sorted(decisions, key=repr)


def compare_decisions(trace, index, trusted_source_indices):
    """Reject forged or missing producer verdict records.

    Note: externally trusted query indices are NOT taken from trace metadata.
    The underlying events must pass full independent transition replay first;
    this function alone is not a verifier of search history.
    """
    runs = trace.get("runs")
    queries = trace.get("queries")
    if (type(runs) is not list or type(queries) is not list
            or len(runs) != len(trusted_source_indices)
            or len(queries) != len(trusted_source_indices)):
        return {
            "passed": False, "failures": [
                {"reason": "missing_or_extra_claim_decision_records"}
            ], "rows": [],
        }
    rows, failures = [], []
    for pos, source_index in enumerate(trusted_source_indices):
        run = runs[pos]
        if (type(run) is not dict
                or run.get("source_index") != source_index
                or run.get("complete") is not True
                or queries[pos].get("source_index") != source_index):
            failures.append({"query_index": pos,
                             "reason": "invalid_claim_record_or_source"})
            continue
        observed = reconstructed_decisions(queries[pos]["events"], index)
        # Direct negative evidence is a separate *claim-level* witness,
        # not a positive terminal proof. The independent checker reconstructs
        # it from its own trusted snapshot/query after full frontier replay.
        # Older unit-level verdict fixtures omit the external query; they
        # exercise only terminal-proof reconstruction. In the secure full
        # protocol replay_trace already REQUIRED the external query to match,
        # so absence here cannot bypass the deployment verifier.
        query_claim = queries[pos].get("query")
        direct_reason = (
            _refutation_reason([query_claim], index)
            if query_claim is not None else None
        )
        has_direct_claim = any(row[0] == query_claim for row in observed)
        if direct_reason is not None and not has_direct_claim:
            observed = sorted(
                [*observed, [query_claim, "REFUTED", 0, 0]], key=repr
            )
        expected_witness = ({
            "kind": "trusted_direct_contradiction",
            "claim": query_claim,
            "reason": direct_reason,
            "trusted_snapshot_sha256": canonical_sha256(index.snapshot),
        } if direct_reason is not None else None)
        submitted_witness = run.get("refutation_witness")
        # A missing witness or any forged claim/reason/digest is rejected;
        # its digest alone never establishes that the trusted input is sound.
        if submitted_witness != expected_witness:
            failures.append({
                "query_index": pos,
                "reason": "missing_or_invalid_direct_refutation_witness",
                "expected_reason": direct_reason,
            })
        claimed = run.get("decision_summary")
        if claimed != observed:
            failures.append({
                "query_index": pos,
                "reason": "incorrect_aggregated_verdict_or_proof_counts",
                "independent": observed,
                "claimed": claimed,
            })
        rows.append({
            "source_index": source_index,
            "verdicts": observed,
            "equal": claimed == observed,
        })
    return {"passed": not failures, "failures": failures, "rows": rows}
