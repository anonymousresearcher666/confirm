from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Sequence, Tuple

from .unify import apply_substitution, freshen_rule, unify_atoms


def is_variable(symbol: str) -> bool:
    return symbol.startswith("?")


@dataclass(frozen=True)
class Atom:
    predicate: str
    args: Tuple[str, ...]

    def substitute(self, substitution: Dict[str, str]) -> "Atom":
        return apply_substitution(self, substitution)

    def variables(self) -> Tuple[str, ...]:
        return tuple(arg for arg in self.args if is_variable(arg))


@dataclass(frozen=True)
class Rule:
    name: str
    head: Atom
    body: Tuple[Atom, ...]
    confidence: float = 1.0


@dataclass
class KnowledgeBase:
    facts: List[Atom] = field(default_factory=list)
    rules: List[Rule] = field(default_factory=list)

    def __post_init__(self) -> None:
        self._facts_by_predicate: Dict[str, List[Atom]] = {}
        self._rules_by_head_predicate: Dict[str, List[Rule]] = {}
        # Conservative candidate indexes for read-only fact existence checks.
        # They never replace final unification. Each wildcard/constant posting
        # holds original facts; duplicates and variable facts are preserved.
        self._facts_by_signature: Dict[tuple[str, int], List[Atom]] = {}
        self._fact_postings: Dict[tuple[str, int, int, str], List[Atom]] = {}
        self._fact_wildcards: Dict[tuple[str, int, int], List[Atom]] = {}
        # Parallel ordinal postings preserve EXACT source fact order, including
        # duplicate occurrences and variable-containing EDB facts. The
        # proof-sensitive producer/checker cannot tolerate child reordering.
        self._fact_position_postings: Dict[tuple[str, int, int, str], List[int]] = {}
        self._fact_position_wildcards: Dict[tuple[str, int, int], List[int]] = {}
        for fact in self.facts:
            self._facts_by_predicate.setdefault(fact.predicate, []).append(fact)
            arity = len(fact.args)
            signature = (fact.predicate, arity)
            bucket = self._facts_by_signature.setdefault(signature, [])
            offset = len(bucket)
            bucket.append(fact)
            for position, value in enumerate(fact.args):
                if is_variable(value):
                    self._fact_wildcards.setdefault(
                        (fact.predicate, arity, position), []
                    ).append(fact)
                    self._fact_position_wildcards.setdefault(
                        (fact.predicate, arity, position), []
                    ).append(offset)
                else:
                    self._fact_postings.setdefault(
                        (fact.predicate, arity, position, value), []
                    ).append(fact)
                    self._fact_position_postings.setdefault(
                        (fact.predicate, arity, position, value), []
                    ).append(offset)
        for rule in self.rules:
            self._rules_by_head_predicate.setdefault(rule.head.predicate, []).append(rule)

    @property
    def predicates(self) -> List[str]:
        names = set()
        for fact in self.facts:
            names.add(fact.predicate)
        for rule in self.rules:
            names.add(rule.head.predicate)
            for atom in rule.body:
                names.add(atom.predicate)
        return sorted(names)

    @property
    def entities(self) -> List[str]:
        names = set()
        for fact in self.facts:
            for arg in fact.args:
                if not is_variable(arg):
                    names.add(arg)
        for rule in self.rules:
            for atom in (rule.head, *rule.body):
                for arg in atom.args:
                    if not is_variable(arg):
                        names.add(arg)
        return sorted(names)

    def facts_for(self, predicate: str) -> Sequence[Atom]:
        return self._facts_by_predicate.get(predicate, ())

    def facts_maybe_matching(self, goal: Atom) -> Sequence[Atom]:
        """Return a sound *superset* of unifiable facts (never a verdict).

        Select the narrowest positional posting using ground goal terms.
        A fact with a variable in that position remains eligible, so this
        cannot eliminate a genuine match. The caller MUST still unify.
        Unlike facts_for(), this does not promise input order.
        """
        arity = len(goal.args)
        signature = (goal.predicate, arity)
        selected: Sequence[Atom] = self._facts_by_signature.get(signature, ())
        smallest = len(selected)
        for position, value in enumerate(goal.args):
            if is_variable(value):
                continue
            matching = self._fact_postings.get(
                (goal.predicate, arity, position, value), ()
            )
            wildcards = self._fact_wildcards.get(
                (goal.predicate, arity, position), ()
            )
            size = len(matching) + len(wildcards)
            if size < smallest:
                selected = (*matching, *wildcards)
                smallest = size
                if not smallest:
                    break
        return selected

    def facts_for_goal_ordered(self, goal: Atom) -> Sequence[Atom]:
        """Sound indexed expansion candidates in EXACT EDB input order.

        All terms that are ground in the already-substituted goal restrict
        possible matches. Use one narrowest positional index, combining
        exact-symbol facts with variable-valued (unifiable) EDB facts.
        Index offsets, unlike Atom identity, preserve identical duplicate
        facts. Keeping source order preserves child frontier ordering and
        the externally replayable proof identity/transition contract.

        This method returns a SUPERSET, not a proof or a certificate.
        Each caller MUST perform the original final atom unification.
        The fallback without bound terms is precisely the original
        predicate+arity ordered sequence.
        """
        arity = len(goal.args)
        signature = (goal.predicate, arity)
        facts = self._facts_by_signature.get(signature, ())
        selected_offsets = None
        smallest = len(facts)
        for position, value in enumerate(goal.args):
            if is_variable(value):
                continue
            exact = self._fact_position_postings.get(
                (goal.predicate, arity, position, value), ()
            )
            wild = self._fact_position_wildcards.get(
                (goal.predicate, arity, position), ()
            )
            size = len(exact) + len(wild)
            if size < smallest:
                selected_offsets = sorted((*exact, *wild))
                smallest = size
                if not smallest:
                    break
        if selected_offsets is None:
            return facts
        return [facts[i] for i in selected_offsets]

    def rules_for(self, predicate: str) -> Sequence[Rule]:
        return self._rules_by_head_predicate.get(predicate, ())

    def all_symbols(self) -> List[str]:
        return self.entities + self.predicates + [rule.name for rule in self.rules]

    def candidate_clauses(
        self, goal: Atom
    ) -> Tuple[List[Tuple[Atom, Dict[str, str]]], List[Tuple[Rule, Dict[str, str]]]]:
        fact_matches: List[Tuple[Atom, Dict[str, str]]] = []
        for fact in self.facts_for(goal.predicate):
            substitution = unify_atoms(goal, fact, {})
            if substitution is not None:
                fact_matches.append((fact, substitution))

        rule_matches: List[Tuple[Rule, Dict[str, str]]] = []
        for rule in self.rules_for(goal.predicate):
            fresh_rule = freshen_rule(rule)
            substitution = unify_atoms(goal, fresh_rule.head, {})
            if substitution is not None:
                rule_matches.append((fresh_rule, substitution))
        return fact_matches, rule_matches

    def contains_fact(self, atom: Atom) -> bool:
        return atom in self.facts
