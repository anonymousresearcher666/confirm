from __future__ import annotations

from .graph import StateGraph
from .runtime import TORCH_AVAILABLE, require_torch, torch

if TORCH_AVAILABLE:
    from torch import nn
    from torch.nn import functional as F
else:  # pragma: no cover - exercised only when torch is absent
    nn = None
    F = None


if TORCH_AVAILABLE:

    class RelGraphConv(nn.Module):
        def __init__(self, hidden_dim: int, num_edge_types: int, dropout: float = 0.0) -> None:
            super().__init__()
            self.hidden_dim = hidden_dim
            self.num_edge_types = num_edge_types
            self.self_loop = nn.Linear(hidden_dim, hidden_dim, bias=False)
            self.relation_weights = nn.Parameter(
                torch.empty(num_edge_types, hidden_dim, hidden_dim)
            )
            self.bias = nn.Parameter(torch.zeros(hidden_dim))
            self.dropout = nn.Dropout(dropout)
            nn.init.xavier_uniform_(self.relation_weights)

        def forward(
            self, x: torch.Tensor, edge_index: torch.Tensor, edge_type: torch.Tensor
        ) -> torch.Tensor:
            out = self.self_loop(x)
            src, dst = edge_index
            for rel in range(self.num_edge_types):
                mask = edge_type == rel
                if not torch.any(mask):
                    continue
                rel_src = src[mask]
                rel_dst = dst[mask]
                messages = x.index_select(0, rel_src) @ self.relation_weights[rel]
                aggregated = torch.zeros_like(x)
                aggregated.index_add_(0, rel_dst, messages)
                out = out + aggregated
            out = out + self.bias
            return self.dropout(F.relu(out))

    class TraceGuidedHeuristicNet(nn.Module):
        def __init__(
            self,
            num_node_types: int,
            num_edge_types: int,
            hidden_dim: int = 128,
            num_layers: int = 2,
            dropout: float = 0.1,
            node_feature_dim: int = 8,
            graph_feature_dim: int = 6,
        ) -> None:
            super().__init__()
            self.type_embedding = nn.Embedding(num_node_types, hidden_dim)
            self.feature_projection = nn.Linear(node_feature_dim, hidden_dim)
            self.graph_projection = nn.Linear(graph_feature_dim, hidden_dim)
            self.convs = nn.ModuleList(
                [
                    RelGraphConv(hidden_dim, num_edge_types, dropout=dropout)
                    for _ in range(num_layers)
                ]
            )
            self.readout = nn.Sequential(
                nn.Linear(hidden_dim * 3, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
            )
            self.dropout = nn.Dropout(dropout)
            self.priority_head = nn.Linear(hidden_dim, 1)
            self.risk_head = nn.Linear(hidden_dim, 1)
            self.prune_head = nn.Linear(hidden_dim, 1)
            self.contradiction_head = nn.Linear(hidden_dim, 1)

        def _encode(self, graph: StateGraph) -> torch.Tensor:
            x = self.type_embedding(graph.node_types) + self.feature_projection(graph.node_features)
            for conv in self.convs:
                x = conv(x, graph.edge_index, graph.edge_type)

            if torch.any(graph.active_mask):
                active_nodes = x[graph.active_mask]
                pooled_active = active_nodes.mean(dim=0)
                pooled_max = active_nodes.max(dim=0).values
            else:
                pooled_active = x.mean(dim=0)
                pooled_max = x.max(dim=0).values

            pooled_global = x.mean(dim=0)
            graph_features = self.graph_projection(graph.graph_features)
            return self.readout(
                torch.cat([pooled_active + graph_features, pooled_global, pooled_max], dim=0)
            )

        def forward_all(self, graph: StateGraph) -> dict[str, torch.Tensor]:
            hidden = self.dropout(self._encode(graph))
            return {
                "priority": self.priority_head(hidden).squeeze(-1),
                "risk": self.risk_head(hidden).squeeze(-1),
                "prune": self.prune_head(hidden).squeeze(-1),
                "contradiction": self.contradiction_head(hidden).squeeze(-1),
            }

        def forward(self, graph: StateGraph) -> torch.Tensor:
            return self.forward_all(graph)["priority"]
else:

    class RelGraphConv:  # pragma: no cover - exercised only when torch is absent
        def __init__(self, *args, **kwargs) -> None:
            require_torch("Relational graph convolution")

    class TraceGuidedHeuristicNet:  # pragma: no cover - exercised only when torch is absent
        def __init__(self, *args, **kwargs) -> None:
            require_torch("Trace-guided heuristic model")
