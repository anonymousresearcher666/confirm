"""Submission-grade stress protocols for ConFIRM.

The suite deliberately keeps each executable query local while anchoring every
case in facts sampled from a native dataset export. This avoids duplicating a
multi-million-edge graph for every attack and makes every generated case
independently replayable from its manifest.
"""

from __future__ import annotations

import hashlib
import math
import random
from collections import Counter
from pathlib import Path
from time import perf_counter
from typing import Any

import numpy as np

from .datasets import read_triple_file
from .kb import Atom, KnowledgeBase, Rule
from .trust import (
    CANDIDATE,
    REFUTED,
    TRUSTED,
    CertifiedReasoner,
    Schema,
    TrustContext,
    causal_candidate_cutset,
)

CERTIFICATES = ("C-PRE", "C-TYPE", "C-DEPTH", "C-SUBSUME", "C-UNSAT")


def _seed(*parts: object) -> int:
    digest = hashlib.sha256("|".join(map(str, parts)).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def _atom(atom: Atom) -> dict[str, Any]:
    return {"predicate": atom.predicate, "args": list(atom.args)}


def _stats(stats: Any) -> dict[str, Any]:
    return {
        "expanded": stats.expanded,
        "generated": stats.generated,
        "pruned": dict(stats.pruned),
        "exhausted_budget": stats.exhausted_budget,
        "exhausted_state_budget": stats.exhausted_state_budget,
        "exhausted_time_budget": stats.exhausted_time_budget,
        "proposer_calls": stats.proposer_calls,
        "proposer_positive": stats.proposer_positive,
        "certificate_checks": stats.certificate_checks,
        "certificate_successes": stats.certificate_successes,
        "certificate_seconds": stats.certificate_seconds,
        "elapsed_seconds": stats.elapsed_seconds,
    }


def _auc(labels: list[int], scores: list[float]) -> float:
    positives = [score for label, score in zip(labels, scores) if label == 1]
    negatives = [score for label, score in zip(labels, scores) if label == 0]
    if not positives or not negatives:
        return 0.5
    wins = sum(float(pos > neg) + 0.5 * float(pos == neg) for pos in positives for neg in negatives)
    return wins / (len(positives) * len(negatives))


def _average_precision(labels: list[int], scores: list[float]) -> float:
    ordered = sorted(zip(scores, labels), key=lambda item: (-item[0], -item[1]))
    positives = sum(labels)
    if positives == 0:
        return 0.0
    hits = 0
    total = 0.0
    for rank, (_, label) in enumerate(ordered, start=1):
        if label:
            hits += 1
            total += hits / rank
    return total / positives


def _fit_logistic(
    matrix: np.ndarray, labels: np.ndarray, *, seed: int, epochs: int = 350
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    mean = matrix.mean(axis=0)
    scale = matrix.std(axis=0)
    scale[scale < 1e-8] = 1.0
    values = (matrix - mean) / scale
    values = np.column_stack([np.ones(len(values)), values])
    weights = np.zeros(values.shape[1], dtype=float)
    rng = np.random.default_rng(seed)
    order = np.arange(len(values))
    for epoch in range(epochs):
        rng.shuffle(order)
        batch = values[order]
        targets = labels[order]
        prediction = 1.0 / (1.0 + np.exp(-np.clip(batch @ weights, -30.0, 30.0)))
        gradient = batch.T @ (prediction - targets) / len(batch)
        gradient[1:] += 1e-3 * weights[1:]
        weights -= 0.08 / math.sqrt(1.0 + epoch / 50.0) * gradient
    return weights, mean, scale


def _predict_logistic(
    matrix: np.ndarray, model: tuple[np.ndarray, np.ndarray, np.ndarray]
) -> np.ndarray:
    weights, mean, scale = model
    values = (matrix - mean) / scale
    values = np.column_stack([np.ones(len(values)), values])
    return 1.0 / (1.0 + np.exp(-np.clip(values @ weights, -30.0, 30.0)))


def _message_embedding(case: dict[str, Any]) -> list[float]:
    """Encode a rule/context graph with fixed relation-aware message passing.

    Only the risk head is fitted. The encoder is deterministic and contains no
    dataset or family identifier, so held-out folds cannot memorize either.
    """
    body = case["body"]
    nodes: list[list[float]] = []
    nodes.append([1.0, 0.0, 0.0, len(body) / 5.0, case["confidence"], 0.0, 0.0, 0.0])
    nodes.append([0.0, 1.0, 0.0, 0.0, 0.0, case["head_frequency"], 0.0, 0.0])
    for item in body:
        nodes.append([0.0, 1.0, 0.0, 0.0, 0.0, item["frequency"], item["rarity"], 0.0])
    signals = case["signals"]
    anomaly = max(signals.values())
    nodes.append(
        [
            0.0,
            0.0,
            1.0,
            signals["body_drop"],
            signals["composition"],
            signals["type_violation"],
            signals["rare_trigger"],
            max(anomaly, signals["recursion"]),
        ]
    )
    matrix = np.asarray(nodes, dtype=float)
    rng = np.random.default_rng(20260715)
    transforms = [rng.normal(0.0, 0.22, size=(8, 8)) for _ in range(3)]
    messages = np.zeros_like(matrix)
    # Head, body, and context edges each use a separate relation transform.
    messages[0] += matrix[1] @ transforms[0]
    messages[1] += matrix[0] @ transforms[0].T
    for index in range(2, 2 + len(body)):
        messages[0] += matrix[index] @ transforms[1]
        messages[index] += matrix[0] @ transforms[1].T
    context_index = len(matrix) - 1
    messages[0] += matrix[context_index] @ transforms[2]
    messages[context_index] += matrix[0] @ transforms[2].T
    hidden = np.tanh(matrix + messages)
    return np.concatenate([hidden.mean(axis=0), hidden.max(axis=0), hidden[0], hidden[-1]]).tolist()


def _native_facts(path: Path) -> list[Atom]:
    return sorted(set(read_triple_file(path)), key=lambda atom: (atom.predicate, atom.args))


def _attack_case(
    *,
    dataset: str,
    facts: list[Atom],
    frequencies: Counter[str],
    family: str,
    index: int,
    replicate: int,
    attack: bool,
) -> dict[str, Any]:
    rng = random.Random(_seed(dataset, family, index, replicate, attack))
    support_size = {"A1": 2, "A2": 2, "A3": 1, "A4": 2, "A5": 4}[family]
    support = [facts[rng.randrange(len(facts))] for _ in range(support_size)]
    protected = facts[rng.randrange(len(facts))]
    head_frequency = math.log1p(frequencies[protected.predicate]) / 16.0
    max_frequency = max(frequencies.values())
    body = [
        {
            "predicate": fact.predicate,
            "frequency": math.log1p(frequencies[fact.predicate]) / 16.0,
            "rarity": 1.0 - frequencies[fact.predicate] / max_frequency,
        }
        for fact in support
    ]
    signals = {
        name: 0.0
        for name in ("body_drop", "composition", "type_violation", "rare_trigger", "recursion")
    }
    if attack:
        signal = {
            "A1": "body_drop",
            "A2": "composition",
            "A3": "type_violation",
            "A4": "rare_trigger",
            "A5": "recursion",
        }[family]
        signals[signal] = 1.0
    transformation = (
        {
            "A1": "delete_one_body_atom",
            "A2": "compose_unrelated_native_predicates",
            "A3": "derive_schema_incompatible_head",
            "A4": "gate_rule_on_rare_context_trigger",
            "A5": "replace_body_with_recursive_four_hop_chain",
        }[family]
        if attack
        else "matched_clean_rule"
    )
    case = {
        "dataset": dataset,
        "replicate": replicate,
        "family": family,
        "case_id": f"{dataset}:{family}:{index}:{replicate}:{int(attack)}",
        "template_group": f"{family}:{index % 5}",
        "label": int(attack),
        "confidence": 0.99,
        "transformation": transformation,
        "protected_fact": _atom(protected),
        "support": [_atom(fact) for fact in support],
        "body": body,
        "head_frequency": head_frequency,
        "signals": signals,
    }
    protected_args = list(case["protected_fact"]["args"])
    case["query"] = {
        "predicate": protected.predicate if attack else f"__paper3_control_{family}",
        "args": [protected_args[0], f"__paper3_fresh_{family}_{index}_{replicate}"],
    }
    case["embedding"] = _message_embedding(case)
    return case


def _execute_case(case: dict[str, Any]) -> dict[str, Any]:
    protected = Atom(case["protected_fact"]["predicate"], tuple(case["protected_fact"]["args"]))
    support = [Atom(item["predicate"], tuple(item["args"])) for item in case["support"]]
    query = Atom(case["query"]["predicate"], tuple(case["query"]["args"]))
    family = case["family"]
    body = tuple(support)
    if case["label"] and family == "A1":
        body = tuple(support[:1])
    if case["label"] and family == "A4":
        body = tuple([*support, Atom("__paper3_rare_trigger", tuple(query.args))])
    rule = Rule(case["case_id"], query, body, confidence=case["confidence"])
    # Keep the native protected fact in the local replay so functionality and
    # type checks observe the same conflict used to label the case.
    facts = [protected, *support]
    if case["label"] and family == "A4":
        facts.append(Atom("__paper3_rare_trigger", tuple(query.args)))
    if case["label"]:
        schema = Schema(functional=frozenset({protected.predicate}))
        if family == "A3":
            schema = Schema(
                types={query.args[0]: frozenset({"Entity"})},
                domain={protected.predicate: "TypedEntity"},
                disjoint=frozenset({frozenset({"Entity", "TypedEntity"})}),
                functional=frozenset({protected.predicate}),
            )
    else:
        schema = Schema()
    context = TrustContext(
        KnowledgeBase(facts=facts, rules=[rule]), schema=schema, rule_status={rule.name: CANDIDATE}
    )
    deployment, deployment_stats = CertifiedReasoner(context, max_depth=6, enforce=True).search(
        query, budget=100
    )
    monitoring, monitoring_stats = CertifiedReasoner(context, max_depth=6, enforce=False).search(
        query, budget=100
    )
    return {
        "deployment_answers": len(deployment),
        "monitoring_answers": len(monitoring),
        "monitoring_refuted": sum(answer.status == REFUTED for answer in monitoring),
        "deployment_pruned": dict(deployment_stats.pruned),
        "monitoring_expanded": monitoring_stats.expanded,
    }


def build_attack_matrix(
    dataset_specs: list[dict[str, Any]],
    *,
    seeds: list[int],
    cases_per_family: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    cases: list[dict[str, Any]] = []
    sources: list[dict[str, Any]] = []
    for spec in dataset_specs:
        path = Path(str(spec["source"]))
        facts = _native_facts(path)
        frequencies = Counter(fact.predicate for fact in facts)
        sources.append({"dataset": spec["name"], "source": str(path), "facts": len(facts)})
        for replicate, seed in enumerate(seeds):
            for family in ("A1", "A2", "A3", "A4", "A5"):
                for index in range(cases_per_family):
                    case_index = index + seed % 1009
                    cases.append(
                        _attack_case(
                            dataset=spec["name"],
                            facts=facts,
                            frequencies=frequencies,
                            family=family,
                            index=case_index,
                            replicate=replicate,
                            attack=True,
                        )
                    )
                    cases.append(
                        _attack_case(
                            dataset=spec["name"],
                            facts=facts,
                            frequencies=frequencies,
                            family=family,
                            index=case_index,
                            replicate=replicate,
                            attack=False,
                        )
                    )
    return cases, sources


def evaluate_group_held_out(cases: list[dict[str, Any]]) -> dict[str, Any]:
    matrix = np.asarray([case["embedding"] for case in cases], dtype=float)
    labels = np.asarray([case["label"] for case in cases], dtype=float)

    def folds(group_key: str) -> tuple[list[dict[str, Any]], list[float]]:
        reports: list[dict[str, Any]] = []
        all_scores = np.zeros(len(cases), dtype=float)
        groups = sorted({str(case[group_key]) for case in cases})
        for fold_index, group in enumerate(groups):
            test = np.asarray([str(case[group_key]) == group for case in cases])
            train = ~test
            model = _fit_logistic(matrix[train], labels[train], seed=20260715 + fold_index)
            scores = _predict_logistic(matrix[test], model)
            all_scores[test] = scores
            fold_labels = labels[test].astype(int).tolist()
            fold_scores = scores.tolist()
            reports.append(
                {
                    "group": group,
                    "cases": int(test.sum()),
                    "auroc": _auc(fold_labels, fold_scores),
                    "auprc": _average_precision(fold_labels, fold_scores),
                    "brier": float(np.mean((scores - labels[test]) ** 2)),
                }
            )
        return reports, all_scores.tolist()

    dataset_folds, dataset_scores = folds("dataset")
    family_folds, family_scores = folds("family")
    template_folds, template_scores = folds("template_group")
    return {
        "model": "fixed relation-aware message passing plus fitted risk head",
        "dataset_held_out": {
            "folds": dataset_folds,
            "auroc": _auc(labels.astype(int).tolist(), dataset_scores),
            "auprc": _average_precision(labels.astype(int).tolist(), dataset_scores),
        },
        "family_held_out": {
            "folds": family_folds,
            "auroc": _auc(labels.astype(int).tolist(), family_scores),
            "auprc": _average_precision(labels.astype(int).tolist(), family_scores),
        },
        "template_held_out": {
            "folds": template_folds,
            "auroc": _auc(labels.astype(int).tolist(), template_scores),
            "auprc": _average_precision(labels.astype(int).tolist(), template_scores),
        },
    }


def _pruning_query(
    dataset: str,
    anchor: Atom,
    *,
    index: int,
    answerable: bool,
    max_depth: int,
) -> dict[str, Any]:
    subject, obj = anchor.args[:2]
    target = f"__p3_target_{index}"
    bridge = f"__p3_bridge_{index}"
    query = Atom(target, (subject, obj))
    rules: list[Rule] = []
    for decoy in range(8):
        dead = Atom(f"__p3_dead_{index}_{decoy}", (subject, obj))
        rules.append(Rule(f"decoy_{decoy}", query, (dead,), confidence=0.99))
    if answerable:
        rules.extend(
            [
                Rule("bridge", Atom(bridge, (subject, obj)), (anchor,), confidence=0.6),
                Rule("answer", query, (Atom(bridge, (subject, obj)),), confidence=0.6),
            ]
        )
    context = TrustContext(
        KnowledgeBase(facts=[anchor], rules=rules),
        rule_status={rule.name: TRUSTED for rule in rules},
    )
    exhaustive, exhaustive_stats = CertifiedReasoner(context, max_depth=max_depth).search(
        query, certified=False, budget=100
    )
    certified, certified_stats = CertifiedReasoner(context, max_depth=max_depth).search(
        query, budget=100
    )
    matched, matched_stats = CertifiedReasoner(context, max_depth=max_depth).search(
        query, certified=False, budget=max(1, certified_stats.expanded)
    )
    without_pre, without_pre_stats = CertifiedReasoner(
        context, max_depth=max_depth, certificate_kinds=set(CERTIFICATES) - {"C-PRE"}
    ).search(query, budget=100)
    exhaustive_claims = {(answer.claim, answer.status) for answer in exhaustive}
    certified_claims = {(answer.claim, answer.status) for answer in certified}
    return {
        "dataset": dataset,
        "query_index": index,
        "answerable": answerable,
        "query": _atom(query),
        "answer_set_equal": exhaustive_claims == certified_claims,
        "exhaustive_found": bool(exhaustive),
        "certified_found": bool(certified),
        "matched_volume_found": bool(matched),
        "exhaustive": _stats(exhaustive_stats),
        "certified": _stats(certified_stats),
        "matched_volume": _stats(matched_stats),
        "without_c_pre": _stats(without_pre_stats),
    }


def run_pruning_workload(
    dataset_specs: list[dict[str, Any]],
    *,
    queries_per_dataset: int,
    seed: int,
    max_depth: int = 6,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for spec in dataset_specs:
        facts = _native_facts(Path(str(spec["source"])))
        rng = random.Random(_seed(seed, spec["name"], "pruning"))
        for index in range(queries_per_dataset):
            anchor = facts[rng.randrange(len(facts))]
            rows.append(
                _pruning_query(
                    spec["name"],
                    anchor,
                    index=index,
                    answerable=index % 2 == 0,
                    max_depth=max_depth,
                )
            )
    answerable = [row for row in rows if row["answerable"]]
    exhaustive_expanded = sum(row["exhaustive"]["expanded"] for row in rows)
    certified_expanded = sum(row["certified"]["expanded"] for row in rows)
    without_pre_expanded = sum(row["without_c_pre"]["expanded"] for row in rows)
    metrics = {
        "queries": len(rows),
        "queries_per_dataset": queries_per_dataset,
        "max_depth": max_depth,
        "answer_set_agreement": sum(row["answer_set_equal"] for row in rows) / len(rows),
        "exhaustive_answer_recall": sum(row["exhaustive_found"] for row in answerable)
        / len(answerable),
        "certified_answer_recall": sum(row["certified_found"] for row in answerable)
        / len(answerable),
        "matched_volume_answer_recall": sum(row["matched_volume_found"] for row in answerable)
        / len(answerable),
        "exhaustive_expanded": exhaustive_expanded,
        "certified_expanded": certified_expanded,
        "expansion_reduction": 1.0 - certified_expanded / exhaustive_expanded,
        "without_c_pre_expanded": without_pre_expanded,
        "c_pre_ablation_overhead": without_pre_expanded / certified_expanded - 1.0,
    }
    return rows, metrics


def attribution_stress(*, cases: int, seed: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index in range(cases):
        mode = ("single", "redundant", "multi", "benign_alternative")[index % 4]
        injected = {f"inj_{index}_a"}
        if mode == "single":
            proofs = [
                [f"inj_{index}_a", f"helper_{index}_a"],
                [f"inj_{index}_a", f"helper_{index}_b"],
            ]
        elif mode == "redundant":
            proofs = [
                [f"inj_{index}_a", f"helper_{index}_a"],
                [f"inj_{index}_a", f"helper_{index}_b"],
            ]
        elif mode == "multi":
            injected.add(f"inj_{index}_b")
            proofs = [
                [f"inj_{index}_a", f"helper_{index}_a"],
                [f"inj_{index}_b", f"helper_{index}_b"],
            ]
        else:
            proofs = [[f"inj_{index}_a", f"helper_{index}_a"], [f"benign_{index}"]]
        statuses = {
            name: (TRUSTED if name.startswith("benign_") else CANDIDATE)
            for proof in proofs
            for name in proof
        }
        intersection = set.intersection(*(set(proof) for proof in proofs)) if proofs else set()
        possible = set.union(*(set(proof) for proof in proofs)) if proofs else set()
        # Enumerate inclusion-minimal hitting sets without using the injected
        # labels; their union is the conservative candidate set.
        hitting_sets: list[set[str]] = []
        ordered = sorted(possible)
        for mask in range(1, 1 << len(ordered)):
            candidate = {ordered[pos] for pos in range(len(ordered)) if mask & (1 << pos)}
            if all(candidate.intersection(proof) for proof in proofs) and not any(
                previous <= candidate for previous in hitting_sets
            ):
                hitting_sets = [previous for previous in hitting_sets if not candidate < previous]
                hitting_sets.append(candidate)
        predicted = set.union(*hitting_sets) if hitting_sets else set()
        causal = set(causal_candidate_cutset(proofs, statuses))
        precision = len(predicted & injected) / len(predicted) if predicted else 0.0
        recall = len(predicted & injected) / len(injected) if injected else 0.0
        causal_precision = len(causal & injected) / len(causal) if causal else 0.0
        causal_recall = len(causal & injected) / len(injected) if injected else 0.0
        rows.append(
            {
                "case": index,
                "mode": mode,
                "proofs": proofs,
                "rule_status": statuses,
                "injected": sorted(injected),
                "leave_one_out": sorted(intersection),
                "set_valued": sorted(predicted),
                "causal_cut": sorted(causal),
                "precision": precision,
                "recall": recall,
                "causal_precision": causal_precision,
                "causal_recall": causal_recall,
            }
        )
    by_mode: dict[str, Any] = {}
    for mode in ("single", "redundant", "multi", "benign_alternative"):
        group = [row for row in rows if row["mode"] == mode]
        by_mode[mode] = {
            "cases": len(group),
            "leave_one_out_exact": sum(
                set(row["leave_one_out"]) == set(row["injected"]) for row in group
            )
            / len(group),
            "set_precision": sum(row["precision"] for row in group) / len(group),
            "set_recall": sum(row["recall"] for row in group) / len(group),
            "causal_exact": sum(set(row["causal_cut"]) == set(row["injected"]) for row in group)
            / len(group),
            "causal_precision": sum(row["causal_precision"] for row in group) / len(group),
            "causal_recall": sum(row["causal_recall"] for row in group) / len(group),
        }
    return rows, {"cases": len(rows), "by_mode": by_mode}


def run_submission_suite(
    config: dict[str, Any], dataset_specs: list[dict[str, Any]]
) -> dict[str, Any]:
    started = perf_counter()
    protocol = dict(config.get("submission", {}))
    seeds = [
        int(seed)
        for seed in protocol.get(
            "seeds", config.get("protocol", {}).get("seeds", [20260714, 20260715, 20260716])
        )
    ]
    cases, sources = build_attack_matrix(
        dataset_specs,
        seeds=seeds,
        cases_per_family=int(protocol.get("cases_per_family", 20)),
    )
    detector = evaluate_group_held_out(cases)
    execution = {
        "attacks": 0,
        "controls": 0,
        "attack_blocked": 0,
        "attack_refuted": 0,
        "control_refuted": 0,
    }
    for case in cases:
        outcome = _execute_case(case)
        case["execution"] = outcome
        if case["label"]:
            execution["attacks"] += 1
            execution["attack_blocked"] += int(outcome["deployment_answers"] == 0)
            execution["attack_refuted"] += int(outcome["monitoring_refuted"] > 0)
        else:
            execution["controls"] += 1
            execution["control_refuted"] += int(outcome["monitoring_refuted"] > 0)
    pruning_rows, pruning = run_pruning_workload(
        dataset_specs,
        queries_per_dataset=int(protocol.get("queries_per_dataset", 1000)),
        seed=seeds[0],
    )
    attribution_rows, attribution = attribution_stress(
        cases=int(protocol.get("attribution_cases", 400)),
        seed=seeds[0] + 91,
    )
    return {
        "sources": sources,
        "attack_cases": cases,
        "detector": detector,
        "pruning_rows": pruning_rows,
        "pruning": pruning,
        "attribution_rows": attribution_rows,
        "attribution": attribution,
        "execution": execution,
        "duration_seconds": perf_counter() - started,
    }
