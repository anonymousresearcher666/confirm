from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Callable, Dict, List, Optional, Tuple, Union

from .kb import Atom, KnowledgeBase
from .unify import apply_substitution, freshen_rule, unify_atoms

if TYPE_CHECKING:
    from .traces import SearchTraceRecord


@dataclass(frozen=True)
class ProofStep:
    goal: Atom
    clause_name: str
    clause_kind: str
    substitution: Tuple[Tuple[str, str], ...]


@dataclass(frozen=True)
class ProofState:
    goals: Tuple[Atom, ...]
    query: Optional[Atom] = None
    substitution: Tuple[Tuple[str, str], ...] = ()
    path: Tuple[ProofStep, ...] = ()
    depth: int = 0

    def substitution_dict(self) -> Dict[str, str]:
        return dict(self.substitution)

    def current_goal(self) -> Optional[Atom]:
        return self.goals[0] if self.goals else None

    def normalized_goals(self) -> Tuple[Atom, ...]:
        substitution = self.substitution_dict()
        return tuple(apply_substitution(goal, substitution) for goal in self.goals)

    def signature(self) -> Tuple:
        substitution = self.substitution_dict()
        goals = tuple(
            (goal.predicate, apply_substitution(goal, substitution).args) for goal in self.goals
        )
        query = apply_substitution(self.query, substitution) if self.query is not None else None
        query_sig = (query.predicate, query.args) if query is not None else None
        return query_sig, goals, tuple(sorted(substitution.items()))


@dataclass
class ProofResult:
    success: bool
    state: ProofState
    proof_steps: Tuple[ProofStep, ...] = ()
    expanded_states: int = 0
    generated_states: int = 0
    visited_states: int = 0
    score: float = 0.0


class SearchStrategy(str, Enum):
    BEST_FIRST = "best_first"
    BFS = "bfs"
    DFS = "dfs"
    RANDOM = "random"


HeuristicFn = Callable[[ProofState, KnowledgeBase], float]


@dataclass
class SearchBundle:
    results: List[ProofResult]
    trace: List["SearchTraceRecord"]


@dataclass
class SymbolicReasoner:
    kb: KnowledgeBase
    max_depth: int = 20
    max_expansions: int = 20_000

    def _goal_support_score(self, state: ProofState) -> float:
        goals = state.normalized_goals()
        if not goals:
            return 1.0
        support = 0.0
        for goal in goals:
            goal_support = 0.0
            if self.kb.facts_for(goal.predicate):
                goal_support = max(goal_support, 0.5)
            if self.kb.rules_for(goal.predicate):
                goal_support = max(
                    goal_support,
                    max(float(rule.confidence) for rule in self.kb.rules_for(goal.predicate)),
                )
            support += goal_support
        return support / max(1, len(goals))

    def _trace_utility(
        self,
        state: ProofState,
        *,
        outcome: str,
        remaining: int,
        proof_len: int,
        utility_mode: str,
        utility_decay: float,
    ) -> float:
        if outcome not in {"proof", "proof_path"}:
            return 0.0
        if utility_mode == "binary":
            return 1.0
        if utility_mode == "depth":
            return 1.0 / (1.0 + float(state.depth))
        if utility_mode == "exponential":
            return math.exp(-max(0.0, float(utility_decay)) * float(remaining))
        if utility_mode == "semantic":
            distance = 1.0 / (1.0 + float(remaining))
            support = self._goal_support_score(state)
            return 0.6 * distance + 0.4 * support
        if utility_mode != "proof_distance":
            raise ValueError(
                "Unknown utility_mode "
                f"{utility_mode!r}; expected one of proof_distance, exponential, depth, binary, semantic"
            )
        return 1.0 / (1.0 + float(remaining))

    def expand_state(self, state: ProofState) -> List[Tuple[ProofStep, ProofState]]:
        goal = state.current_goal()
        if goal is None:
            return []

        substitution = state.substitution_dict()
        ground_goal = apply_substitution(goal, substitution)
        rest = state.goals[1:]
        children: List[Tuple[ProofStep, ProofState]] = []

        for fact in self.kb.facts_for(ground_goal.predicate):
            child_subst = unify_atoms(ground_goal, fact, substitution)
            if child_subst is None:
                continue
            step = ProofStep(
                goal=ground_goal,
                clause_name=f"fact::{fact.predicate}",
                clause_kind="fact",
                substitution=tuple(sorted(child_subst.items())),
            )
            children.append(
                (
                    step,
                    ProofState(
                        goals=rest,
                        query=state.query,
                        substitution=tuple(sorted(child_subst.items())),
                        path=state.path + (step,),
                        depth=state.depth + 1,
                    ),
                )
            )

        for rule in self.kb.rules_for(ground_goal.predicate):
            fresh_rule = freshen_rule(rule)
            child_subst = unify_atoms(ground_goal, fresh_rule.head, substitution)
            if child_subst is None:
                continue
            new_goals = tuple(
                apply_substitution(atom, child_subst) for atom in fresh_rule.body
            ) + tuple(apply_substitution(atom, child_subst) for atom in rest)
            step = ProofStep(
                goal=ground_goal,
                clause_name=fresh_rule.name,
                clause_kind="rule",
                substitution=tuple(sorted(child_subst.items())),
            )
            children.append(
                (
                    step,
                    ProofState(
                        goals=new_goals,
                        query=state.query,
                        substitution=tuple(sorted(child_subst.items())),
                        path=state.path + (step,),
                        depth=state.depth + 1,
                    ),
                )
            )

        return children

    def search(
        self,
        query: Atom,
        *,
        strategy: SearchStrategy = SearchStrategy.BEST_FIRST,
        heuristic: Optional[HeuristicFn] = None,
        top_k: int = 1,
        random_seed: int = 0,
        collect_trace: bool = False,
        utility_mode: str = "proof_distance",
        utility_decay: float = 1.0,
    ) -> Union[List[ProofResult], SearchBundle]:
        import heapq
        import random

        if collect_trace:
            from .traces import SearchTraceRecord
        else:
            SearchTraceRecord = None  # type: ignore[assignment]

        rng = random.Random(random_seed)
        heuristic = heuristic or (lambda state, kb: -float(state.depth))

        root = ProofState(goals=(query,), query=query)
        frontier: List[Tuple[float, int, int, ProofState]] = []
        counter = 0
        state_id_counter = 0

        trace_records: List["SearchTraceRecord"] = []
        trace_by_id: Dict[int, "SearchTraceRecord"] = {}
        parent_by_id: Dict[int, Optional[int]] = {}
        proof_path_ids: List[int] = []
        proof_state_id: Optional[int] = None

        def push(state: ProofState, parent_id: Optional[int]) -> int:
            nonlocal counter, state_id_counter
            if strategy == SearchStrategy.BFS:
                priority = float(state.depth)
                score = -float(state.depth)
            elif strategy == SearchStrategy.DFS:
                priority = -float(state.depth)
                score = float(state.depth)
            elif strategy == SearchStrategy.RANDOM:
                score = rng.random()
                priority = -score
            else:
                score = float(heuristic(state, self.kb))
                priority = -score
            state_id = state_id_counter
            state_id_counter += 1
            heapq.heappush(frontier, (priority, counter, state_id, state))
            counter += 1
            parent_by_id[state_id] = parent_id
            if collect_trace:
                record = SearchTraceRecord(
                    state_id=state_id,
                    parent_id=parent_id,
                    frontier_id=parent_id if parent_id is not None else -1,
                    query=state.query,
                    state=state,
                    score=score,
                    strategy=strategy.value,
                    outcome="pending",
                    utility=0.0,
                    weight=1.0,
                    label=0,
                    depth=state.depth,
                    expanded_order=-1,
                    generated_children=0,
                )
                trace_records.append(record)
                trace_by_id[state_id] = record
            return state_id

        push(root, None)
        visited = set()
        results: List[ProofResult] = []
        expanded = 0
        generated = 0
        expansion_order = 0

        while frontier and expanded < self.max_expansions and len(results) < top_k:
            _, _, state_id, state = heapq.heappop(frontier)
            signature = state.signature()
            if signature in visited:
                continue
            visited.add(signature)

            if collect_trace and state_id in trace_by_id:
                trace_by_id[state_id].expanded_order = expansion_order
                expansion_order += 1

            if not state.goals:
                proof_state_id = state_id
                cursor = state_id
                while cursor is not None:
                    proof_path_ids.append(cursor)
                    cursor = parent_by_id.get(cursor)
                proof_path_ids.reverse()
                results.append(
                    ProofResult(
                        success=True,
                        state=state,
                        proof_steps=state.path,
                        expanded_states=expanded,
                        generated_states=generated,
                        visited_states=len(visited),
                        score=1.0,
                    )
                )
                continue

            if state.depth >= self.max_depth:
                expanded += 1
                if collect_trace and state_id in trace_by_id:
                    trace_by_id[state_id].outcome = "timeout"
                    trace_by_id[state_id].weight = 0.1
                continue

            expanded += 1
            children = self.expand_state(state)
            generated += len(children)
            if collect_trace and state_id in trace_by_id:
                trace_by_id[state_id].generated_children = len(children)
                if not children:
                    trace_by_id[state_id].outcome = "dead_end"
            for _, child_state in children:
                child_id = push(child_state, state_id)
                if collect_trace and child_id in trace_by_id:
                    trace_by_id[child_id].frontier_id = state_id

        if not results:
            results.append(
                ProofResult(
                    success=False,
                    state=root,
                    proof_steps=(),
                    expanded_states=expanded,
                    generated_states=generated,
                    visited_states=len(visited),
                    score=0.0,
                )
            )

        if collect_trace:
            proof_set = set(proof_path_ids)
            proof_len = max(0, len(proof_path_ids) - 1)
            for record in trace_records:
                if record.state_id in proof_set:
                    idx = proof_path_ids.index(record.state_id)
                    remaining = proof_len - idx
                    record.outcome = "proof" if record.state_id == proof_state_id else "proof_path"
                    record.utility = self._trace_utility(
                        record.state,
                        outcome=record.outcome,
                        remaining=remaining,
                        proof_len=proof_len,
                        utility_mode=utility_mode,
                        utility_decay=utility_decay,
                    )
                    record.label = 1
                    record.weight = 1.0
                elif record.outcome == "pending":
                    record.outcome = "timeout"
                    record.utility = 0.0
                    record.label = 0
                    record.weight = 0.1
            return SearchBundle(results=results, trace=trace_records)

        return results
