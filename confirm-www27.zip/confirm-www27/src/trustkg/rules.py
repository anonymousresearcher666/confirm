from __future__ import annotations

import json
import re
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean
from typing import Dict, List, Sequence, Tuple

from .kb import Atom, Rule


def _sanitize_rule_name(text: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_]+", "_", text.strip())
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    return cleaned or "rule"


def _rule_to_dict(rule: Rule) -> Dict:
    return {
        "name": rule.name,
        "head": {"predicate": rule.head.predicate, "args": list(rule.head.args)},
        "body": [{"predicate": atom.predicate, "args": list(atom.args)} for atom in rule.body],
        "confidence": rule.confidence,
    }


def _rule_signature(head: Atom, body: Sequence[Atom]) -> Tuple:
    return (
        head.predicate,
        head.args,
        tuple((atom.predicate, atom.args) for atom in body),
    )


def _anyburl_is_variable(term: str) -> bool:
    return bool(re.fullmatch(r"[A-Z][A-Z0-9_]*", term))


def _normalize_anyburl_term(term: str) -> str:
    stripped = term.strip()
    if _anyburl_is_variable(stripped):
        return f"?{stripped}"
    return stripped


def _split_top_level_commas(text: str) -> List[str]:
    parts: List[str] = []
    start = 0
    depth = 0
    for index, char in enumerate(text):
        if char == "(":
            depth += 1
        elif char == ")":
            depth = max(0, depth - 1)
        elif char == "," and depth == 0:
            part = text[start:index].strip()
            if part:
                parts.append(part)
            start = index + 1
    tail = text[start:].strip()
    if tail:
        parts.append(tail)
    return parts


def _parse_anyburl_atom(text: str) -> Atom:
    cleaned = text.strip()
    if not cleaned.endswith(")") or "(" not in cleaned:
        raise ValueError(f"Invalid AnyBURL atom: {text!r}")
    predicate, raw_args = cleaned.split("(", 1)
    args = raw_args[:-1]
    parsed_args = tuple(_normalize_anyburl_term(arg) for arg in _split_top_level_commas(args))
    return Atom(predicate=predicate.strip(), args=parsed_args)


def parse_anyburl_rule_line(line: str, *, index: int = 0) -> Rule:
    stripped = line.strip()
    if not stripped:
        raise ValueError("Empty AnyBURL rule line")
    parts = stripped.split("\t", 3)
    if len(parts) != 4:
        raise ValueError(
            f"Expected 4 tab-separated columns in AnyBURL rule line, got {len(parts)}: {line!r}"
        )
    support_text, body_size_text, confidence_text, rule_text = parts
    support = int(float(support_text))
    body_size = int(float(body_size_text))
    confidence = float(confidence_text)
    if "<=" in rule_text:
        head_text, body_text = rule_text.split("<=", 1)
        body_atoms = [_parse_anyburl_atom(atom) for atom in _split_top_level_commas(body_text)]
    else:
        head_text = rule_text
        body_atoms = []
    head = _parse_anyburl_atom(head_text)
    safe_head = _sanitize_rule_name(head.predicate)
    name = f"anyburl_{support}_{body_size}_{safe_head}_{index}"
    return Rule(name=name, head=head, body=tuple(body_atoms), confidence=confidence)


def read_anyburl_rule_file(path: str | Path, *, limit: int | None = None) -> List[Rule]:
    source = Path(path)
    rules: List[Rule] = []
    if source.suffix == ".zip":
        with zipfile.ZipFile(source) as archive:
            candidate_names = [name for name in archive.namelist() if not name.endswith("/")]
            member_name = next(
                (name for name in candidate_names if "anyburl" in Path(name).name.lower()), None
            )
            if member_name is None:
                raise FileNotFoundError(f"Could not find an AnyBURL rule file inside {source}")
            with archive.open(member_name, "r") as handle:
                for index, raw_line in enumerate(handle):
                    line = raw_line.decode("utf-8").strip()
                    if not line:
                        continue
                    rules.append(parse_anyburl_rule_line(line, index=index))
                    if limit is not None and len(rules) >= limit:
                        break
        return rules
    with source.open("r", encoding="utf-8") as handle:
        for index, raw_line in enumerate(handle):
            line = raw_line.strip()
            if not line:
                continue
            rules.append(parse_anyburl_rule_line(line, index=index))
            if limit is not None and len(rules) >= limit:
                break
    return rules


def import_anyburl_rules(
    source: str | Path, output: str | Path, *, limit: int | None = None
) -> List[Rule]:
    rules = read_anyburl_rule_file(source, limit=limit)
    write_rules_json(output, rules)
    return rules


def write_rules_json(path: str | Path, rules: Sequence[Rule]) -> None:
    payload = [_rule_to_dict(rule) for rule in rules]
    Path(path).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_rule_summary(path: str | Path, rules: Sequence[Rule], *, top_k: int = 50) -> None:
    ordered = sorted(
        rules,
        key=lambda rule: (-float(rule.confidence), len(rule.body), rule.name),
    )[:top_k]
    lines = ["name\tconfidence\thead\tbody"]
    for rule in ordered:
        body = " , ".join(f"{atom.predicate}({', '.join(atom.args)})" for atom in rule.body)
        lines.append(
            "\t".join(
                [
                    rule.name,
                    f"{float(rule.confidence):.6f}",
                    f"{rule.head.predicate}({', '.join(rule.head.args)})",
                    body,
                ]
            )
        )
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def _is_trivial_inverse(rule: Rule) -> bool:
    return len(rule.body) == 1 and rule.head.predicate == rule.body[0].predicate


def audit_rules(
    rules: Sequence[Rule],
    *,
    min_confidence: float = 0.0,
    min_body_length: int = 0,
    exclude_trivial_inverse: bool = False,
) -> Dict:
    total = len(rules)
    body_length_counts = Counter(len(rule.body) for rule in rules)
    confidences = [float(rule.confidence) for rule in rules] or [0.0]
    filtered = [
        rule
        for rule in rules
        if float(rule.confidence) >= min_confidence
        and len(rule.body) >= min_body_length
        and (not exclude_trivial_inverse or not _is_trivial_inverse(rule))
    ]
    duplicate_signatures = Counter(_rule_signature(rule.head, rule.body) for rule in rules)
    duplicate_rules = sum(count - 1 for count in duplicate_signatures.values() if count > 1)
    predicate_counts = Counter(rule.head.predicate for rule in rules)
    body_predicate_counts = Counter(atom.predicate for rule in rules for atom in rule.body)
    report = {
        "total_rules": total,
        "filtered_rules": len(filtered),
        "body_length_counts": dict(sorted(body_length_counts.items())),
        "confidence": {
            "min": min(confidences),
            "mean": mean(confidences),
            "max": max(confidences),
        },
        "duplicate_rules": duplicate_rules,
        "trivial_inverse_rules": sum(1 for rule in rules if _is_trivial_inverse(rule)),
        "head_predicates_top": predicate_counts.most_common(20),
        "body_predicates_top": body_predicate_counts.most_common(20),
        "filters": {
            "min_confidence": min_confidence,
            "min_body_length": min_body_length,
            "exclude_trivial_inverse": exclude_trivial_inverse,
        },
    }
    return report


def filter_rules(
    rules: Sequence[Rule],
    *,
    min_confidence: float = 0.0,
    min_body_length: int = 0,
    exclude_trivial_inverse: bool = False,
) -> List[Rule]:
    return [
        rule
        for rule in rules
        if float(rule.confidence) >= min_confidence
        and len(rule.body) >= min_body_length
        and (not exclude_trivial_inverse or not _is_trivial_inverse(rule))
    ]


def _rule_name(prefix: str, *parts: str) -> str:
    text = "_".join(_sanitize_rule_name(part) for part in parts if part)
    return f"{prefix}_{text}" if text else prefix


def _fact_index_by_relation(facts: Sequence[Atom]) -> Dict[str, List[Tuple[str, str]]]:
    index: Dict[str, List[Tuple[str, str]]] = defaultdict(list)
    for fact in facts:
        if len(fact.args) != 2:
            continue
        index[fact.predicate].append((fact.args[0], fact.args[1]))
    return index


def _fact_index_by_relation_subject(facts: Sequence[Atom]) -> Dict[str, Dict[str, List[str]]]:
    index: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: defaultdict(list))
    for fact in facts:
        if len(fact.args) != 2:
            continue
        subject, obj = fact.args
        index[fact.predicate][subject].append(obj)
    return index


def _fact_index_by_relation_object(facts: Sequence[Atom]) -> Dict[str, Dict[str, List[str]]]:
    index: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: defaultdict(list))
    for fact in facts:
        if len(fact.args) != 2:
            continue
        subject, obj = fact.args
        index[fact.predicate][obj].append(subject)
    return index


def _relation_pairs(
    index: Dict[str, List[Tuple[str, str]]], relation: str, *, reversed: bool = False
) -> set[Tuple[str, str]]:
    pairs = index.get(relation, [])
    if reversed:
        return {(tail, head) for head, tail in pairs}
    return set(pairs)


def _pca_denominator(
    body_pairs: set[Tuple[str, str]],
    target_facts: set[Tuple[str, str]],
) -> int:
    allowed_subjects = {subject for subject, _ in target_facts}
    return sum(1 for subject, _ in body_pairs if subject in allowed_subjects)


def _join_forward_forward(
    left_object_index: Dict[str, Dict[str, List[str]]],
    right_subject_index: Dict[str, Dict[str, List[str]]],
    left_relation: str,
    right_relation: str,
) -> set[Tuple[str, str]]:
    body_pairs: set[Tuple[str, str]] = set()
    left_objects = left_object_index.get(left_relation, {})
    right_objects = right_subject_index.get(right_relation, {})
    for y, xs in left_objects.items():
        zs = right_objects.get(y)
        if not zs:
            continue
        for x in xs:
            for z in zs:
                body_pairs.add((x, z))
    return body_pairs


def _join_reverse_forward(
    left_subject_index: Dict[str, Dict[str, List[str]]],
    right_subject_index: Dict[str, Dict[str, List[str]]],
    left_relation: str,
    right_relation: str,
) -> set[Tuple[str, str]]:
    body_pairs: set[Tuple[str, str]] = set()
    left_subjects = left_subject_index.get(left_relation, {})
    right_objects = right_subject_index.get(right_relation, {})
    for y, xs in left_subjects.items():
        zs = right_objects.get(y)
        if not zs:
            continue
        for x in xs:
            for z in zs:
                body_pairs.add((x, z))
    return body_pairs


def _join_forward_reverse(
    left_object_index: Dict[str, Dict[str, List[str]]],
    right_object_index: Dict[str, Dict[str, List[str]]],
    left_relation: str,
    right_relation: str,
) -> set[Tuple[str, str]]:
    body_pairs: set[Tuple[str, str]] = set()
    left_objects = left_object_index.get(left_relation, {})
    right_objects = right_object_index.get(right_relation, {})
    for y, xs in left_objects.items():
        zs = right_objects.get(y)
        if not zs:
            continue
        for x in xs:
            for z in zs:
                body_pairs.add((x, z))
    return body_pairs


def _join_reverse_reverse(
    left_subject_index: Dict[str, Dict[str, List[str]]],
    right_object_index: Dict[str, Dict[str, List[str]]],
    left_relation: str,
    right_relation: str,
) -> set[Tuple[str, str]]:
    body_pairs: set[Tuple[str, str]] = set()
    left_subjects = left_subject_index.get(left_relation, {})
    right_objects = right_object_index.get(right_relation, {})
    for y, xs in left_subjects.items():
        zs = right_objects.get(y)
        if not zs:
            continue
        for x in xs:
            for z in zs:
                body_pairs.add((x, z))
    return body_pairs


def mine_inverse_rules(
    facts: Sequence[Atom],
    *,
    min_support: int = 3,
    min_confidence: float = 0.5,
    max_rules: int = 50,
) -> List[Rule]:
    index = _fact_index_by_relation(facts)
    relations = sorted(index)
    counts = {relation: Counter(pairs) for relation, pairs in index.items()}
    total_by_relation = {relation: len(pairs) for relation, pairs in index.items()}
    rules: List[Rule] = []
    seen: set[Tuple] = set()

    for head_relation in relations:
        head_pairs = index[head_relation]
        if not head_pairs:
            continue
        for body_relation in relations:
            if body_relation == head_relation:
                continue
            body_pairs = index[body_relation]
            if not body_pairs:
                continue
            support = 0
            for left, right in body_pairs:
                if counts[head_relation].get((right, left), 0):
                    support += 1
            confidence = support / max(1, total_by_relation[body_relation])
            if support < min_support or confidence < min_confidence:
                continue
            head = Atom(head_relation, ("?X", "?Y"))
            body = (Atom(body_relation, ("?Y", "?X")),)
            signature = _rule_signature(head, body)
            if signature in seen:
                continue
            seen.add(signature)
            rules.append(
                Rule(
                    name=_rule_name("inverse", head_relation, body_relation),
                    head=head,
                    body=body,
                    confidence=float(confidence),
                )
            )
            if len(rules) >= max_rules:
                return rules
    return rules


def mine_chain_rules(
    facts: Sequence[Atom],
    *,
    min_support: int = 5,
    min_confidence: float = 0.3,
    max_rules: int = 100,
) -> List[Rule]:
    index = _fact_index_by_relation(facts)
    if not index:
        return []

    forward_by_relation: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: defaultdict(list))
    fact_sets: Dict[str, set[Tuple[str, str]]] = {}
    for relation, pairs in index.items():
        fact_sets[relation] = set(pairs)
        for left, right in pairs:
            forward_by_relation[relation][left].append(right)

    relations = sorted(index)
    rules: List[Rule] = []
    seen: set[Tuple] = set()
    for first in relations:
        for second in relations:
            body_pairs: set[Tuple[str, str]] = set()
            first_map = forward_by_relation[first]
            second_map = forward_by_relation[second]
            for x, ys in first_map.items():
                for y in ys:
                    for z in second_map.get(y, []):
                        body_pairs.add((x, z))
            if not body_pairs:
                continue
            body_support = len(body_pairs)
            for target in relations:
                target_facts = fact_sets[target]
                support_pairs = body_pairs & target_facts
                support = len(support_pairs)
                if support < min_support:
                    continue
                confidence = support / max(1, body_support)
                if confidence < min_confidence:
                    continue
                head = Atom(target, ("?X", "?Z"))
                body = (Atom(first, ("?X", "?Y")), Atom(second, ("?Y", "?Z")))
                signature = _rule_signature(head, body)
                if signature in seen:
                    continue
                seen.add(signature)
                rules.append(
                    Rule(
                        name=_rule_name("chain", target, first, second),
                        head=head,
                        body=body,
                        confidence=float(confidence),
                    )
                )
                if len(rules) >= max_rules:
                    return rules
    return rules


def mine_rules_from_benchmark(
    benchmark,
    *,
    min_inverse_support: int = 3,
    min_inverse_confidence: float = 0.5,
    min_chain_support: int = 5,
    min_chain_confidence: float = 0.3,
    max_inverse_rules: int = 50,
    max_chain_rules: int = 100,
    algorithm: str = "basic",
) -> List[Rule]:
    if algorithm == "amie":
        return mine_amie_style_rules(
            benchmark.kb.facts,
            min_support=min_chain_support,
            min_confidence=min_chain_confidence,
            max_rules=max_inverse_rules + max_chain_rules,
        )
    rules: List[Rule] = []
    rules.extend(
        mine_inverse_rules(
            benchmark.kb.facts,
            min_support=min_inverse_support,
            min_confidence=min_inverse_confidence,
            max_rules=max_inverse_rules,
        )
    )
    rules.extend(
        mine_chain_rules(
            benchmark.kb.facts,
            min_support=min_chain_support,
            min_confidence=min_chain_confidence,
            max_rules=max_chain_rules,
        )
    )
    return rules


def mine_amie_style_rules(
    facts: Sequence[Atom],
    *,
    min_support: int = 5,
    min_confidence: float = 0.3,
    min_head_coverage: float = 0.0,
    min_pca_confidence: float = 0.0,
    max_rules: int = 200,
) -> List[Rule]:
    """Mine a compact AMIE-style Horn rule set from binary KG facts.

    This is intentionally lightweight: it explores connected 1-body and 2-body
    patterns, scores them with support, confidence, head coverage, and PCA
    confidence, and exports the best rules in the same JSON schema used by the
    rest of the pipeline.
    """
    index = _fact_index_by_relation(facts)
    if not index:
        return []

    relations = sorted(index)
    relation_facts = {relation: set(pairs) for relation, pairs in index.items()}
    relation_sizes = {relation: len(pairs) for relation, pairs in relation_facts.items()}
    subject_index = _fact_index_by_relation_subject(facts)
    object_index = _fact_index_by_relation_object(facts)

    candidate_rows: List[tuple[float, float, float, int, str, Rule]] = []
    seen: set[Tuple] = set()

    def register_rule(
        *,
        head_relation: str,
        body: Sequence[Atom],
        body_pairs: set[Tuple[str, str]],
        head_pairs: set[Tuple[str, str]],
        name_prefix: str,
    ) -> None:
        if not body_pairs:
            return
        support_pairs = body_pairs & head_pairs
        support = len(support_pairs)
        if support < min_support:
            return
        confidence = support / max(1, len(body_pairs))
        head_coverage = support / max(1, relation_sizes[head_relation])
        if head_coverage < min_head_coverage or confidence < min_confidence:
            return
        pca_den = _pca_denominator(body_pairs, head_pairs)
        pca_confidence = support / max(1, pca_den)
        if pca_confidence < min_pca_confidence:
            return
        rule = Rule(
            name=_rule_name(name_prefix, head_relation, *[atom.predicate for atom in body]),
            head=Atom(head_relation, ("?X", "?Z"))
            if len(body) > 1
            else Atom(head_relation, ("?X", "?Y")),
            body=tuple(body),
            confidence=float(confidence),
        )
        signature = _rule_signature(rule.head, rule.body)
        if signature in seen:
            return
        seen.add(signature)
        score = head_coverage * confidence
        candidate_rows.append(
            (
                -score,
                -confidence,
                -head_coverage,
                -support,
                rule.name,
                rule,
            )
        )

    for head_relation in relations:
        head_pairs = relation_facts[head_relation]

        for body_relation in relations:
            forward_pairs = _relation_pairs(index, body_relation, reversed=False)
            reverse_pairs = _relation_pairs(index, body_relation, reversed=True)

            # 1-body rules.
            register_rule(
                head_relation=head_relation,
                body=(Atom(body_relation, ("?X", "?Y")),),
                body_pairs=forward_pairs,
                head_pairs=head_pairs,
                name_prefix="amie",
            )
            register_rule(
                head_relation=head_relation,
                body=(Atom(body_relation, ("?Y", "?X")),),
                body_pairs=reverse_pairs,
                head_pairs=head_pairs,
                name_prefix="amie",
            )

            for second_relation in relations:
                joins = [
                    (
                        (Atom(body_relation, ("?X", "?Y")), Atom(second_relation, ("?Y", "?Z"))),
                        _join_forward_forward(
                            object_index, subject_index, body_relation, second_relation
                        ),
                    ),
                    (
                        (Atom(body_relation, ("?Y", "?X")), Atom(second_relation, ("?Y", "?Z"))),
                        _join_reverse_forward(
                            subject_index, subject_index, body_relation, second_relation
                        ),
                    ),
                    (
                        (Atom(body_relation, ("?X", "?Y")), Atom(second_relation, ("?Z", "?Y"))),
                        _join_forward_reverse(
                            object_index, object_index, body_relation, second_relation
                        ),
                    ),
                    (
                        (Atom(body_relation, ("?Y", "?X")), Atom(second_relation, ("?Z", "?Y"))),
                        _join_reverse_reverse(
                            subject_index, object_index, body_relation, second_relation
                        ),
                    ),
                ]
                for body_atoms, body_pairs in joins:
                    if not body_pairs:
                        continue
                    register_rule(
                        head_relation=head_relation,
                        body=body_atoms,
                        body_pairs=body_pairs,
                        head_pairs=head_pairs,
                        name_prefix="amie",
                    )
                if len(candidate_rows) >= max_rules * 4:
                    break
            if len(candidate_rows) >= max_rules * 4:
                break

    ordered = [
        item[-1]
        for item in sorted(
            candidate_rows,
            key=lambda item: (item[0], item[1], item[2], item[3], item[4]),
        )[:max_rules]
    ]
    return ordered


def generate_inverse_rules(predicates: Sequence[str], *, confidence: float = 0.9) -> List[Rule]:
    rules: List[Rule] = []
    for predicate in sorted(set(predicates)):
        name = f"inverse_{_sanitize_rule_name(predicate)}"
        rules.append(
            Rule(
                name=name,
                head=Atom(predicate, ("?X", "?Y")),
                body=(Atom(predicate, ("?Y", "?X")),),
                confidence=confidence,
            )
        )
    return rules


def generate_chain_rules(
    predicates: Sequence[str],
    *,
    confidence: float = 0.55,
    max_rules: int = 24,
) -> List[Rule]:
    unique = [predicate for predicate in sorted(set(predicates)) if predicate]
    rules: List[Rule] = []
    for idx, left in enumerate(unique):
        for right in unique[idx + 1 :]:
            if len(rules) >= max_rules:
                return rules
            name = f"chain_{_sanitize_rule_name(left)}_{_sanitize_rule_name(right)}"
            rules.append(
                Rule(
                    name=name,
                    head=Atom(left, ("?X", "?Z")),
                    body=(Atom(left, ("?X", "?Y")), Atom(right, ("?Y", "?Z"))),
                    confidence=confidence,
                )
            )
    return rules


def generate_starter_rules_from_benchmark(
    benchmark,
    *,
    include_inverse: bool = True,
    include_chain: bool = True,
    chain_max_rules: int = 24,
) -> List[Rule]:
    if benchmark.kb.facts:
        return mine_rules_from_benchmark(
            benchmark,
            max_inverse_rules=50 if include_inverse else 0,
            max_chain_rules=chain_max_rules if include_chain else 0,
        )
    predicates = benchmark.kb.predicates
    rules: List[Rule] = []
    if include_inverse:
        rules.extend(generate_inverse_rules(predicates))
    if include_chain:
        rules.extend(generate_chain_rules(predicates, max_rules=chain_max_rules))
    return rules
