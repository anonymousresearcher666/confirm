from __future__ import annotations

try:
    import torch as _torch  # type: ignore[import-not-found]

    TORCH_AVAILABLE = True
except ModuleNotFoundError:  # pragma: no cover - runtime dependent
    _torch = None
    TORCH_AVAILABLE = False

torch = _torch


def require_torch(feature: str) -> None:
    raise RuntimeError(
        f"{feature} requires PyTorch, but torch is not installed in this environment. "
        "Create the local venv and install a torch build that matches your platform."
    )
