from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .heuristics import random_heuristic, rule_confidence_heuristic, shortest_path_heuristic
from .kb import Atom, KnowledgeBase
from .reasoner import ProofResult, SearchBundle, SearchStrategy, SymbolicReasoner
from .traces import SearchTraceRecord

HeuristicName = str


def heuristic_by_name(name: HeuristicName):
    if name == "shortest_path":
        return shortest_path_heuristic
    if name == "rule_confidence":
        return rule_confidence_heuristic
    if name == "random":
        return random_heuristic
    raise ValueError(f"Unknown heuristic: {name}")


@dataclass
class SearchRun:
    results: List[ProofResult]
    trace: List[SearchTraceRecord] | None = None


def search_query(
    kb: KnowledgeBase,
    query: Atom,
    *,
    strategy: SearchStrategy = SearchStrategy.BEST_FIRST,
    heuristic_name: str = "shortest_path",
    max_depth: int = 20,
    max_expansions: int = 20_000,
    top_k: int = 1,
    collect_trace: bool = False,
    utility_mode: str = "proof_distance",
    utility_decay: float = 1.0,
) -> SearchRun:
    reasoner = SymbolicReasoner(kb=kb, max_depth=max_depth, max_expansions=max_expansions)
    heuristic = heuristic_by_name(heuristic_name)
    bundle = reasoner.search(
        query,
        strategy=strategy,
        heuristic=heuristic,
        top_k=top_k,
        collect_trace=collect_trace,
        utility_mode=utility_mode,
        utility_decay=utility_decay,
    )
    if isinstance(bundle, SearchBundle):
        return SearchRun(results=bundle.results, trace=bundle.trace)
    return SearchRun(results=bundle, trace=None)
