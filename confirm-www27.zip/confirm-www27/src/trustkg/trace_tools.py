from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Sequence

from .traces import SearchTraceRecord, read_trace_records


@dataclass
class TraceValidationReport:
    valid: bool
    errors: List[str]
    warnings: List[str]
    trace_length: int
    proof_records: int
    dead_end_records: int
    timeout_records: int


@dataclass
class TraceReplayReport:
    trace_length: int
    replay_order: List[int]
    proof_path: List[int]
    errors: List[str]


def validate_trace_records(records: Sequence[SearchTraceRecord], kb=None) -> TraceValidationReport:
    errors: List[str] = []
    warnings: List[str] = []
    state_ids = [record.state_id for record in records]
    if len(state_ids) != len(set(state_ids)):
        errors.append("duplicate state_id values found")

    by_id = {record.state_id: record for record in records}
    query_repr = None
    proof_records = 0
    dead_end_records = 0
    timeout_records = 0

    builder = None
    if kb is not None:
        try:
            from .graph import SymbolGraphBuilder

            builder = SymbolGraphBuilder(kb)
        except (ModuleNotFoundError, RuntimeError) as exc:
            warnings.append(f"graph validation skipped because a dependency is missing: {exc}")

    for record in records:
        if record.parent_id is not None and record.parent_id not in by_id:
            errors.append(f"missing parent_id {record.parent_id} for state_id {record.state_id}")
        if query_repr is None:
            query_repr = record.query
        elif record.query != query_repr:
            errors.append("inconsistent query values in trace records")
        if record.label not in (0, 1):
            errors.append(f"invalid label {record.label} for state_id {record.state_id}")
        if record.label == 1:
            proof_records += 1
            if record.utility <= 0:
                errors.append(f"proof-labeled record {record.state_id} has non-positive utility")
        if record.outcome == "dead_end":
            dead_end_records += 1
        if record.outcome == "timeout":
            timeout_records += 1
        if builder is not None:
            try:
                builder.build_state(record.state)
            except Exception as exc:  # pragma: no cover - validation path
                errors.append(f"failed to build graph for state_id {record.state_id}: {exc}")

    valid = len(errors) == 0
    return TraceValidationReport(
        valid=valid,
        errors=errors,
        warnings=warnings,
        trace_length=len(records),
        proof_records=proof_records,
        dead_end_records=dead_end_records,
        timeout_records=timeout_records,
    )


def replay_trace_records(records: Sequence[SearchTraceRecord]) -> TraceReplayReport:
    errors: List[str] = []
    replay_order = [
        record.state_id
        for record in sorted(
            records,
            key=lambda r: (r.expanded_order if r.expanded_order >= 0 else 10**9, r.state_id),
        )
    ]
    by_id = {record.state_id: record for record in records}

    proof_path: List[int] = []
    proof_records = [record for record in records if record.outcome == "proof"]
    if proof_records:
        cursor = proof_records[0].state_id
        seen = set()
        while cursor is not None and cursor not in seen:
            seen.add(cursor)
            proof_path.append(cursor)
            parent = by_id.get(cursor).parent_id if cursor in by_id else None
            cursor = parent
        proof_path.reverse()
    else:
        errors.append("no proof record found in trace")

    return TraceReplayReport(
        trace_length=len(records),
        replay_order=replay_order,
        proof_path=proof_path,
        errors=errors,
    )


def load_and_validate_trace_file(path: str | Path, kb=None) -> TraceValidationReport:
    records = read_trace_records(path)
    return validate_trace_records(records, kb=kb)


def load_and_replay_trace_file(path: str | Path) -> TraceReplayReport:
    records = read_trace_records(path)
    return replay_trace_records(records)
