from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Sequence

from .kb import Atom
from .reasoner import ProofState


@dataclass
class SearchTraceRecord:
    state_id: int
    parent_id: int | None
    frontier_id: int
    query: Atom | None
    state: ProofState
    score: float
    strategy: str
    outcome: str
    utility: float
    weight: float
    label: int
    depth: int
    expanded_order: int
    generated_children: int

    def to_json(self) -> str:
        return json.dumps(serialize_trace_record(self), sort_keys=True)

    @staticmethod
    def from_json(line: str) -> "SearchTraceRecord":
        return deserialize_trace_record(json.loads(line))


@dataclass
class RankingPair:
    frontier_id: int
    better: Dict
    worse: Dict
    margin: float
    weight: float

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)

    @staticmethod
    def from_json(line: str) -> "RankingPair":
        payload = json.loads(line)
        return RankingPair(
            frontier_id=int(payload["frontier_id"]),
            better=dict(payload["better"]),
            worse=dict(payload["worse"]),
            margin=float(payload["margin"]),
            weight=float(payload["weight"]),
        )


def atom_to_dict(atom: Atom) -> Dict:
    return {"predicate": atom.predicate, "args": list(atom.args)}


def atom_from_dict(payload: Dict) -> Atom:
    return Atom(predicate=payload["predicate"], args=tuple(payload["args"]))


def state_to_dict(state: ProofState) -> Dict:
    return {
        "query": atom_to_dict(state.query) if state.query is not None else None,
        "goals": [atom_to_dict(goal) for goal in state.goals],
        "substitution": dict(state.substitution),
        "depth": state.depth,
        "path": [
            {
                "goal": atom_to_dict(step.goal),
                "clause_name": step.clause_name,
                "clause_kind": step.clause_kind,
                "substitution": list(step.substitution),
            }
            for step in state.path
        ],
    }


def state_from_dict(payload: Dict) -> ProofState:
    from .reasoner import ProofStep

    path = tuple(
        ProofStep(
            goal=atom_from_dict(step["goal"]),
            clause_name=step["clause_name"],
            clause_kind=step["clause_kind"],
            substitution=tuple(tuple(pair) for pair in step["substitution"]),
        )
        for step in payload.get("path", [])
    )
    query = atom_from_dict(payload["query"]) if payload.get("query") is not None else None
    return ProofState(
        goals=tuple(atom_from_dict(goal) for goal in payload["goals"]),
        query=query,
        substitution=tuple(
            sorted((key, value) for key, value in payload.get("substitution", {}).items())
        ),
        path=path,
        depth=int(payload.get("depth", 0)),
    )


def serialize_trace_record(record: SearchTraceRecord) -> Dict:
    return {
        "state_id": record.state_id,
        "parent_id": record.parent_id,
        "frontier_id": record.frontier_id,
        "query": atom_to_dict(record.query) if record.query is not None else None,
        "state": state_to_dict(record.state),
        "score": record.score,
        "strategy": record.strategy,
        "outcome": record.outcome,
        "utility": record.utility,
        "weight": record.weight,
        "label": record.label,
        "depth": record.depth,
        "expanded_order": record.expanded_order,
        "generated_children": record.generated_children,
    }


def deserialize_trace_record(payload: Dict) -> SearchTraceRecord:
    return SearchTraceRecord(
        state_id=int(payload["state_id"]),
        parent_id=payload.get("parent_id"),
        frontier_id=int(payload["frontier_id"]),
        query=atom_from_dict(payload["query"]) if payload.get("query") is not None else None,
        state=state_from_dict(payload["state"]),
        score=float(payload["score"]),
        strategy=str(payload["strategy"]),
        outcome=str(payload["outcome"]),
        utility=float(payload["utility"]),
        weight=float(payload["weight"]),
        label=int(payload["label"]),
        depth=int(payload["depth"]),
        expanded_order=int(payload["expanded_order"]),
        generated_children=int(payload["generated_children"]),
    )


def write_trace_records(path: str | Path, records: Sequence[SearchTraceRecord]) -> None:
    with Path(path).open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(record.to_json())
            handle.write("\n")


def read_trace_records(path: str | Path) -> List[SearchTraceRecord]:
    records: List[SearchTraceRecord] = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                records.append(SearchTraceRecord.from_json(line))
    return records


def build_pairwise_ranking_pairs(
    records: Sequence[SearchTraceRecord], min_margin: float = 0.0
) -> List[RankingPair]:
    grouped: Dict[int, List[SearchTraceRecord]] = {}
    for record in records:
        grouped.setdefault(record.frontier_id, []).append(record)

    pairs: List[RankingPair] = []
    for frontier_id, group in grouped.items():
        ordered = list(group)
        for i, better in enumerate(ordered):
            for j, worse in enumerate(ordered):
                if i == j:
                    continue
                if better.utility <= worse.utility + min_margin:
                    continue
                margin = max(1e-6, better.utility - worse.utility)
                pairs.append(
                    RankingPair(
                        frontier_id=frontier_id,
                        better=serialize_trace_record(better),
                        worse=serialize_trace_record(worse),
                        margin=margin,
                        weight=max(better.weight, worse.weight),
                    )
                )
    return pairs
