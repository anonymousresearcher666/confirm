from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Sequence

from .device import get_device
from .graph import SymbolGraphBuilder
from .model import TraceGuidedHeuristicNet
from .reasoner import SearchBundle, SearchStrategy, SymbolicReasoner
from .runtime import TORCH_AVAILABLE, require_torch, torch
from .traces import (
    RankingPair,
    SearchTraceRecord,
    build_pairwise_ranking_pairs,
    deserialize_trace_record,
)

if TORCH_AVAILABLE:
    from torch import nn
else:  # pragma: no cover - exercised only when torch is absent
    nn = None


@dataclass
class TrainingConfig:
    epochs: int = 10
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    gradient_clip: float = 5.0
    margin: float = 0.2
    device: str | None = None
    ranking_metric: str = "pairwise_accuracy"
    aux_risk_weight: float = 0.1
    aux_prune_weight: float = 0.1
    aux_contradiction_weight: float = 0.1


@dataclass
class ModelCheckpoint:
    model_state: dict
    hidden_dim: int
    num_layers: int
    dropout: float
    num_node_types: int
    num_edge_types: int
    node_feature_dim: int
    graph_feature_dim: int
    metadata: dict


def build_model(
    builder: SymbolGraphBuilder,
    hidden_dim: int = 128,
    num_layers: int = 2,
    dropout: float = 0.1,
) -> TraceGuidedHeuristicNet:
    if not TORCH_AVAILABLE:
        require_torch("GNN model construction")
    return TraceGuidedHeuristicNet(
        num_node_types=7,
        num_edge_types=13,
        hidden_dim=hidden_dim,
        num_layers=num_layers,
        dropout=dropout,
    )


def save_model_checkpoint(
    path: str | Path,
    model: TraceGuidedHeuristicNet,
    *,
    hidden_dim: int,
    num_layers: int,
    dropout: float,
    num_node_types: int = 7,
    num_edge_types: int = 13,
    node_feature_dim: int = 8,
    graph_feature_dim: int = 6,
    metadata: dict | None = None,
) -> None:
    if not TORCH_AVAILABLE:
        require_torch("Model checkpoint saving")
    payload = ModelCheckpoint(
        model_state=model.state_dict(),
        hidden_dim=hidden_dim,
        num_layers=num_layers,
        dropout=dropout,
        num_node_types=num_node_types,
        num_edge_types=num_edge_types,
        node_feature_dim=node_feature_dim,
        graph_feature_dim=graph_feature_dim,
        metadata=metadata or {},
    )
    torch.save(payload.__dict__, str(path))


def load_model_checkpoint(
    path: str | Path,
    *,
    map_location: str | torch.device | None = None,
) -> tuple[TraceGuidedHeuristicNet, dict]:
    if not TORCH_AVAILABLE:
        require_torch("Model checkpoint loading")
    payload = torch.load(str(path), map_location=map_location)
    model = TraceGuidedHeuristicNet(
        num_node_types=int(payload["num_node_types"]),
        num_edge_types=int(payload["num_edge_types"]),
        hidden_dim=int(payload["hidden_dim"]),
        num_layers=int(payload["num_layers"]),
        dropout=float(payload["dropout"]),
        node_feature_dim=int(payload.get("node_feature_dim", 8)),
        graph_feature_dim=int(payload.get("graph_feature_dim", 6)),
    )
    model.load_state_dict(payload["model_state"])
    metadata = dict(payload.get("metadata", {}))
    return model, metadata


def _to_device(graph, device):
    return type(graph)(
        node_ids=graph.node_ids.to(device),
        node_types=graph.node_types.to(device),
        edge_index=graph.edge_index.to(device),
        edge_type=graph.edge_type.to(device),
        node_features=graph.node_features.to(device),
        graph_features=graph.graph_features.to(device),
        active_mask=graph.active_mask.to(device),
        query_index=graph.query_index,
        state_index=graph.state_index,
        active_goal_index=graph.active_goal_index,
    )


def _score_state(
    model: TraceGuidedHeuristicNet, builder: SymbolGraphBuilder, record: SearchTraceRecord, device
) -> torch.Tensor:
    graph = builder.build_state(record.state)
    graph = _to_device(graph, device)
    return model(graph)


def _trace_aux_targets(record: SearchTraceRecord) -> dict[str, float]:
    return {
        "risk": 1.0 if record.label == 1 else 0.0,
        "prune": 1.0 if record.outcome in {"dead_end", "timeout"} else 0.0,
        "contradiction": 1.0 if record.outcome == "dead_end" else 0.0,
    }


def train_pairwise_ranking(
    model: TraceGuidedHeuristicNet,
    builder: SymbolGraphBuilder,
    pairs: Sequence[RankingPair],
    config: TrainingConfig,
) -> List[float]:
    if not TORCH_AVAILABLE:
        require_torch("GNN training")
    device = get_device(config.device)
    model.to(device)
    model.train()
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay
    )
    criterion = nn.MarginRankingLoss(margin=config.margin)
    bce = nn.BCEWithLogitsLoss()
    losses: List[float] = []

    if not pairs:
        return losses

    for _ in range(config.epochs):
        total_loss = 0.0
        for pair in pairs:
            better_record = deserialize_trace_record(pair.better)
            worse_record = deserialize_trace_record(pair.worse)
            better_graph = _to_device(builder.build_state(better_record.state), device)
            worse_graph = _to_device(builder.build_state(worse_record.state), device)
            optimizer.zero_grad(set_to_none=True)
            better_outputs = model.forward_all(better_graph)
            worse_outputs = model.forward_all(worse_graph)
            better_score = better_outputs["priority"].view(1)
            worse_score = worse_outputs["priority"].view(1)
            target = torch.ones(1, device=device)
            loss = criterion(better_score, worse_score, target) * float(pair.weight)
            if (
                config.aux_risk_weight > 0
                or config.aux_prune_weight > 0
                or config.aux_contradiction_weight > 0
            ):
                better_targets = _trace_aux_targets(better_record)
                worse_targets = _trace_aux_targets(worse_record)
                if config.aux_risk_weight > 0:
                    risk_loss = bce(
                        better_outputs["risk"].view(1),
                        torch.tensor([better_targets["risk"]], device=device),
                    )
                    risk_loss = risk_loss + bce(
                        worse_outputs["risk"].view(1),
                        torch.tensor([worse_targets["risk"]], device=device),
                    )
                    loss = loss + config.aux_risk_weight * risk_loss
                if config.aux_prune_weight > 0:
                    prune_loss = bce(
                        better_outputs["prune"].view(1),
                        torch.tensor([better_targets["prune"]], device=device),
                    )
                    prune_loss = prune_loss + bce(
                        worse_outputs["prune"].view(1),
                        torch.tensor([worse_targets["prune"]], device=device),
                    )
                    loss = loss + config.aux_prune_weight * prune_loss
                if config.aux_contradiction_weight > 0:
                    contradiction_loss = bce(
                        better_outputs["contradiction"].view(1),
                        torch.tensor([better_targets["contradiction"]], device=device),
                    )
                    contradiction_loss = contradiction_loss + bce(
                        worse_outputs["contradiction"].view(1),
                        torch.tensor([worse_targets["contradiction"]], device=device),
                    )
                    loss = loss + config.aux_contradiction_weight * contradiction_loss
            loss.backward()
            if config.gradient_clip > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip)
            optimizer.step()
            total_loss += float(loss.detach().cpu())
        losses.append(total_loss / max(1, len(pairs)))
    return losses


def evaluate_pairwise_ranking(
    model: TraceGuidedHeuristicNet,
    builder: SymbolGraphBuilder,
    pairs: Sequence[RankingPair],
    *,
    device: str | None = None,
) -> dict:
    if not TORCH_AVAILABLE:
        require_torch("GNN ranking evaluation")
    torch_device = get_device(device)
    model = model.to(torch_device)
    model.eval()

    correct = 0
    wrong = 0
    ties = 0
    total = 0
    frontier_ids: set[int] = set()
    with torch.no_grad():
        for pair in pairs:
            better_record = deserialize_trace_record(pair.better)
            worse_record = deserialize_trace_record(pair.worse)
            better_graph = _to_device(builder.build_state(better_record.state), torch_device)
            worse_graph = _to_device(builder.build_state(worse_record.state), torch_device)
            better_score = float(model(better_graph).detach().cpu())
            worse_score = float(model(worse_graph).detach().cpu())
            frontier_ids.add(int(pair.frontier_id))
            total += 1
            if better_score > worse_score:
                correct += 1
            elif better_score < worse_score:
                wrong += 1
            else:
                ties += 1

    accuracy = correct / total if total else 0.0
    return {
        "pair_count": total,
        "frontier_count": len(frontier_ids),
        "correct": correct,
        "wrong": wrong,
        "ties": ties,
        "accuracy": accuracy,
    }


def train_from_traces(
    model: TraceGuidedHeuristicNet,
    builder: SymbolGraphBuilder,
    records: Sequence[SearchTraceRecord],
    config: TrainingConfig,
    *,
    min_margin: float = 0.0,
) -> List[float]:
    pairs = build_pairwise_ranking_pairs(records, min_margin=min_margin)
    return train_pairwise_ranking(model, builder, pairs, config)


def train_from_traces_with_metrics(
    model: TraceGuidedHeuristicNet,
    builder: SymbolGraphBuilder,
    records: Sequence[SearchTraceRecord],
    config: TrainingConfig,
    *,
    min_margin: float = 0.0,
) -> dict:
    pairs = build_pairwise_ranking_pairs(records, min_margin=min_margin)
    losses = train_pairwise_ranking(model, builder, pairs, config)
    metrics = evaluate_pairwise_ranking(model, builder, pairs, device=config.device)
    return {
        "losses": losses,
        "pairwise_ranking": metrics,
        "branch_ranking": metrics,
        "ranking_metric": config.ranking_metric,
    }


def make_model_heuristic(
    model: TraceGuidedHeuristicNet,
    builder: SymbolGraphBuilder,
    *,
    device: str | None = None,
) -> Callable[[object, object], float]:
    if not TORCH_AVAILABLE:
        require_torch("GNN-guided heuristic")
    torch_device = get_device(device)
    model = model.to(torch_device)
    model.eval()

    def heuristic(state, kb) -> float:
        graph = builder.build_state(state)
        graph = _to_device(graph, torch_device)
        with torch.no_grad():
            return float(model(graph).detach().cpu())

    return heuristic


def iterative_trace_guided_learning(
    kb,
    query,
    builder: SymbolGraphBuilder,
    model: TraceGuidedHeuristicNet,
    *,
    baseline_strategy: SearchStrategy = SearchStrategy.BFS,
    learned_strategy: SearchStrategy = SearchStrategy.BEST_FIRST,
    iterations: int = 2,
    search_budget: int = 20_000,
    trace_top_k: int = 1,
    config: TrainingConfig | None = None,
    trace_utility_mode: str = "proof_distance",
    trace_utility_decay: float = 1.0,
) -> List[dict]:
    config = config or TrainingConfig()
    reasoner = SymbolicReasoner(kb, max_expansions=search_budget)
    history: List[dict] = []
    heuristic = None

    for iteration in range(iterations):
        if iteration == 0:
            bundle = reasoner.search(
                query,
                strategy=baseline_strategy,
                top_k=trace_top_k,
                collect_trace=True,
                utility_mode=trace_utility_mode,
                utility_decay=trace_utility_decay,
            )
        else:
            heuristic = make_model_heuristic(model, builder, device=config.device)
            bundle = reasoner.search(
                query,
                strategy=learned_strategy,
                heuristic=heuristic,
                top_k=trace_top_k,
                collect_trace=True,
                utility_mode=trace_utility_mode,
                utility_decay=trace_utility_decay,
            )
        assert isinstance(bundle, SearchBundle)
        losses = train_from_traces(model, builder, bundle.trace, config)
        history.append(
            {
                "iteration": iteration,
                "results": bundle.results,
                "trace_size": len(bundle.trace),
                "losses": losses,
                "trace_utility_mode": trace_utility_mode,
                "ranking_metric": config.ranking_metric,
            }
        )

    return history
