"""Paper 3 ConFIRM implementation: certified confinement and rule-risk auditing.

This module deliberately uses the package's ``Atom``, ``Rule`` and
``KnowledgeBase`` types.  It is the trust layer for the Paper 1/2 reasoner,
not a second prototype package with a second set of symbolic data structures.
"""

from __future__ import annotations

import heapq
import itertools
import math
import random
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from enum import Enum
from time import perf_counter
from types import MappingProxyType
from typing import Callable, Iterable, Mapping, Optional

from .kb import Atom, KnowledgeBase, Rule, is_variable
from .unify import apply_substitution, freshen_rule, resolve, unify_atoms

TRUSTED = "trusted"
CANDIDATE = "candidate"
REJECTED = "rejected"
PROVEN = "PROVEN"
HYPOTHESIZED = "HYPOTHESIZED"
REFUTED = "REFUTED"


class ExecutionMode(str, Enum):
    """Operational semantics for protected and evidence-collecting runs."""

    DEPLOYMENT = "deployment"
    SHADOW = "shadow"


@dataclass(frozen=True)
class Schema:
    """Finite schema used by the Paper 3 certificates and refutation checks."""

    types: Mapping[str, frozenset[str]] = field(default_factory=dict)
    domain: Mapping[str, str] = field(default_factory=dict)
    range_: Mapping[str, str] = field(default_factory=dict)
    disjoint: frozenset[frozenset[str]] = frozenset()
    functional: frozenset[str] = frozenset()
    irreflexive: frozenset[str] = frozenset()

    def type_ok(self, entity: str, required: str) -> bool:
        classes = self.types.get(entity, frozenset())
        if required in classes:
            return True
        return not any(frozenset((actual, required)) in self.disjoint for actual in classes)

    def disjoint_pair(self, left: str, right: str) -> bool:
        return frozenset((left, right)) in self.disjoint


@dataclass(frozen=True)
class TrustContext:
    """Paper 3 metadata associated with a regular :class:`KnowledgeBase`.

    Rule status and injection provenance are intentionally external metadata:
    they do not alter Paper 1/2 rule mining or serialization contracts.
    """

    kb: KnowledgeBase
    schema: Schema = field(default_factory=Schema)
    negatives: frozenset[Atom] = frozenset()
    rule_status: Mapping[str, str] = field(default_factory=dict)
    injected_rules: frozenset[str] = frozenset()

    def __post_init__(self) -> None:
        names = [rule.name for rule in self.kb.rules]
        known = set(names)
        duplicate_names = sorted(name for name, count in Counter(names).items() if count > 1)
        if duplicate_names:
            raise ValueError(f"Rule names must be unique: {duplicate_names}")

        statuses = dict(self.rule_status)
        invalid = set(statuses) - known
        if invalid:
            raise ValueError(f"Rule metadata refers to unknown rules: {sorted(invalid)}")
        invalid = set(self.injected_rules) - known
        if invalid:
            raise ValueError(f"Injected-rule metadata refers to unknown rules: {sorted(invalid)}")
        for name, status in statuses.items():
            if status not in {TRUSTED, CANDIDATE, REJECTED}:
                raise ValueError(f"Unknown status for {name}: {status}")
        trusted_injections = sorted(
            name for name in self.injected_rules if statuses.get(name, CANDIDATE) == TRUSTED
        )
        if trusted_injections:
            raise ValueError(
                f"Injected rules cannot be promoted to trusted status: {trusted_injections}"
            )

        # Copy before wrapping so a caller cannot mutate the original mapping
        # after validation and silently promote an injected rule to trusted.
        object.__setattr__(self, "rule_status", MappingProxyType(statuses))
        object.__setattr__(self, "injected_rules", frozenset(self.injected_rules))

    def status_of(self, rule_name: str) -> str:
        return self.rule_status.get(rule_name, CANDIDATE)

    def with_rules(
        self,
        rules: Iterable[Rule],
        *,
        status: str = CANDIDATE,
        injected: bool = False,
    ) -> "TrustContext":
        if status not in {TRUSTED, CANDIDATE, REJECTED}:
            raise ValueError(f"Unknown rule status: {status}")
        if injected and status != CANDIDATE:
            raise ValueError("Injected rules must be added with candidate status")
        additions = list(rules)
        names = [rule.name for rule in additions]
        if len(names) != len(set(names)) or set(names) & {rule.name for rule in self.kb.rules}:
            raise ValueError("Added rules must have unique, new names")
        statuses = dict(self.rule_status)
        statuses.update({name: status for name in names})
        return TrustContext(
            kb=KnowledgeBase(facts=list(self.kb.facts), rules=[*self.kb.rules, *additions]),
            schema=self.schema,
            negatives=self.negatives,
            rule_status=statuses,
            injected_rules=frozenset(
                set(self.injected_rules) | (set(names) if injected else set())
            ),
        )

    def with_rule_status(self, rule_name: str, status: str) -> "TrustContext":
        """Return a context with one rule safely reclassified.

        Candidate rules can be quarantined as Rejected.  Injection provenance
        is retained permanently, so an injected rule can never be promoted to
        Trusted through this API or by constructing another valid context.
        """
        if rule_name not in {rule.name for rule in self.kb.rules}:
            raise ValueError(f"Unknown rule: {rule_name}")
        if status not in {TRUSTED, CANDIDATE, REJECTED}:
            raise ValueError(f"Unknown rule status: {status}")
        if rule_name in self.injected_rules and status == TRUSTED:
            raise ValueError("Injected rules cannot be promoted to trusted status")
        statuses = dict(self.rule_status)
        statuses[rule_name] = status
        return TrustContext(
            kb=self.kb,
            schema=self.schema,
            negatives=self.negatives,
            rule_status=statuses,
            injected_rules=self.injected_rules,
        )

    def refutation_reason(self, atom: Atom) -> Optional[str]:
        """Return a reason for a ground false claim, otherwise ``None``.

        Deployment enforcement calls this for *all* derived atoms.  That fixes
        the original prototype's gap where explicit negatives and functional
        violations were emitted despite ``enforce_sigma=True``.
        """
        if any(is_variable(arg) for arg in atom.args):
            return None
        if atom in self.negatives:
            return "explicit-negative"
        if len(atom.args) != 2:
            return None
        subject, obj = atom.args
        if atom.predicate in self.schema.irreflexive and subject == obj:
            return "irreflexivity"
        domain = self.schema.domain.get(atom.predicate)
        if domain and not self.schema.type_ok(subject, domain):
            return "domain-violation"
        range_ = self.schema.range_.get(atom.predicate)
        if range_ and not self.schema.type_ok(obj, range_):
            return "range-violation"
        if atom.predicate in self.schema.functional:
            for fact in self.kb.facts_for(atom.predicate):
                if len(fact.args) == 2 and fact.args[0] == subject and fact.args[1] != obj:
                    return "functionality"
        return None

    def derivation_refutation_reason(self, atoms: Iterable[Atom]) -> Optional[str]:
        """Return the first contradiction in a jointly interpreted derivation."""
        ground = tuple(atom for atom in atoms if not any(is_variable(arg) for arg in atom.args))
        for atom in ground:
            reason = self.refutation_reason(atom)
            if reason is not None:
                return reason

        functional_values: dict[tuple[str, str], str] = {}
        required_types: dict[str, set[str]] = defaultdict(set)
        for atom in ground:
            if len(atom.args) != 2:
                continue
            subject, obj = atom.args
            domain = self.schema.domain.get(atom.predicate)
            range_ = self.schema.range_.get(atom.predicate)
            if domain:
                required_types[subject].add(domain)
            if range_:
                required_types[obj].add(range_)
            if atom.predicate in self.schema.functional:
                key = atom.predicate, subject
                previous = functional_values.setdefault(key, obj)
                if previous != obj:
                    return "functionality"

        for classes in required_types.values():
            ordered = sorted(classes)
            for index, left in enumerate(ordered):
                for right in ordered[index + 1 :]:
                    if self.schema.disjoint_pair(left, right):
                        return "type-obligation-conflict"
        return None


@dataclass(frozen=True)
class Certificate:
    kind: str
    witness: object


@dataclass(frozen=True)
class TrustState:
    query: Atom
    goals: tuple[Atom, ...]
    substitution: tuple[tuple[str, str], ...] = ()
    proof: tuple[tuple[str, Atom], ...] = ()
    depth: int = 0  # rule applications only

    def substitution_dict(self) -> dict[str, str]:
        return dict(self.substitution)

    def normalized_goals(self) -> tuple[Atom, ...]:
        substitution = self.substitution_dict()
        return tuple(apply_substitution(goal, substitution) for goal in self.goals)

    def normalized_proof(self) -> tuple[tuple[str, Atom], ...]:
        substitution = self.substitution_dict()
        return tuple((name, apply_substitution(atom, substitution)) for name, atom in self.proof)

    def canonical(self) -> tuple:
        """Exact, variable-renaming-invariant state key for safe subsumption."""
        names: dict[str, str] = {}

        def term(value: str) -> str:
            if not is_variable(value):
                return value
            if value not in names:
                names[value] = f"?{len(names)}"
            return names[value]

        substitution = self.substitution_dict()
        query = apply_substitution(self.query, substitution)
        goals = [apply_substitution(goal, substitution) for goal in self.goals]
        return (
            (query.predicate, tuple(term(arg) for arg in query.args)),
            tuple(
                sorted((goal.predicate, tuple(term(arg) for arg in goal.args)) for goal in goals)
            ),
        )


@dataclass(frozen=True)
class TrustAnswer:
    claim: Atom
    proof: tuple[tuple[str, Atom], ...]
    rules_used: tuple[str, ...]
    status: str
    refutation: Optional[str]


@dataclass(frozen=True)
class ClaimDecision:
    """Claim-level decision obtained by aggregating all discovered proof evidence.

    One trusted-only valid proof is sufficient for ``PROVEN``;
    ``HYPOTHESIZED`` means that only candidate-dependent valid proofs are
    available. ``REFUTED`` requires explicit refutation evidence (such as
    an operator-trusted negative or a witnessed schema contradiction);
    *absence of a derivation is not refutation*. This avoids conflating
    open-world unknown with false under finite search.
    """

    claim: Atom
    status: str
    proof_count: int
    trusted_proof_count: int
    candidate_proof_count: int
    refutations: tuple[str, ...] = ()


def classify_proof(
    context: TrustContext,
    claim: Atom,
    rules_used: Iterable[str],
    proof_atoms: Iterable[Atom] = (),
) -> tuple[str, Optional[str]]:
    """Apply the paper's proof-status semantics to one completed proof.

    Refutation dominates.  Otherwise, a fact-only or trusted-only proof is
    Proven, and every proof using at least one candidate rule is Hypothesized.
    Rejected rules cannot occur in a completed proof because expansion blocks
    them.
    """
    reason = context.derivation_refutation_reason((*proof_atoms, claim))
    if reason is not None:
        return REFUTED, reason
    statuses = tuple(context.status_of(name) for name in rules_used)
    if REJECTED in statuses:
        raise ValueError("A completed proof cannot contain a rejected rule")
    return (PROVEN if all(status == TRUSTED for status in statuses) else HYPOTHESIZED), None


def proven_claims(answers: Iterable[TrustAnswer]) -> frozenset[Atom]:
    """Return claims admitting at least one trusted-only, non-refuted proof."""
    return frozenset(answer.claim for answer in answers if answer.status == PROVEN)


def aggregate_claim_decisions(answers: Iterable[TrustAnswer]) -> tuple[ClaimDecision, ...]:
    """Aggregate proof-level evidence into deterministic claim-level statuses."""
    grouped: dict[Atom, list[TrustAnswer]] = defaultdict(list)
    for answer in answers:
        grouped[answer.claim].append(answer)

    decisions: list[ClaimDecision] = []
    for claim in sorted(grouped, key=lambda atom: (atom.predicate, atom.args)):
        evidence = grouped[claim]
        refutations = tuple(sorted({answer.refutation for answer in evidence if answer.refutation}))
        trusted = sum(answer.status == PROVEN for answer in evidence)
        candidate = sum(answer.status == HYPOTHESIZED for answer in evidence)
        if trusted:
            status = PROVEN
        elif candidate:
            status = HYPOTHESIZED
        else:
            status = REFUTED
        decisions.append(
            ClaimDecision(
                claim=claim,
                status=status,
                proof_count=len(evidence),
                trusted_proof_count=trusted,
                candidate_proof_count=candidate,
                refutations=refutations,
            )
        )
    return tuple(decisions)


def minimal_candidate_cutsets(
    proofs: Iterable[Iterable[str]],
    rule_status: Mapping[str, str],
) -> tuple[tuple[str, ...], ...]:
    """Enumerate every minimum-cardinality candidate hitting set.

    Returning every optimum exposes causal ambiguity instead of hiding it
    behind a deterministic tie-break. Trusted-only proofs remain evidence but
    are not blamed on the candidate layer.
    """
    candidate_proofs = [
        tuple(name for name in proof if rule_status.get(name) == CANDIDATE) for proof in proofs
    ]
    candidate_proofs = [proof for proof in candidate_proofs if proof]
    if not candidate_proofs:
        return ()

    possible = sorted(set().union(*(set(proof) for proof in candidate_proofs)))
    for size in range(1, len(possible) + 1):
        cuts = tuple(
            names
            for names in itertools.combinations(possible, size)
            if all(set(names).intersection(proof) for proof in candidate_proofs)
        )
        if cuts:
            return cuts
    return ()


def causal_candidate_cutset(
    proofs: Iterable[Iterable[str]],
    rule_status: Mapping[str, str],
) -> tuple[str, ...]:
    """Return a minimal candidate-rule cut set for refuted proofs.

    Proof rules must be ordered from the claim toward the leaves. Trusted-only
    alternatives are retained as evidence but are not blamed on the candidate
    layer. Ties between minimum-cardinality cut sets are resolved by proximity
    to the refuted claim and then deterministically by rule name.
    """
    proof_list = [tuple(proof) for proof in proofs]
    distance: dict[str, int] = {}
    for proof in proof_list:
        candidates = tuple(name for name in proof if rule_status.get(name, CANDIDATE) == CANDIDATE)
        if not candidates:
            continue
        for index, name in enumerate(candidates):
            distance[name] = min(distance.get(name, index), index)
    cuts = minimal_candidate_cutsets(proof_list, rule_status)
    if not cuts:
        return ()
    return min(cuts, key=lambda names: (sum(distance[name] for name in names), names))


@dataclass(frozen=True)
class SearchStats:
    expanded: int
    generated: int
    pruned: Mapping[str, int]
    exhausted_budget: bool
    proposer_calls: int = 0
    proposer_positive: int = 0
    certificate_checks: int = 0
    certificate_successes: int = 0
    certificate_seconds: float = 0.0
    elapsed_seconds: float = 0.0
    exhausted_state_budget: bool = False
    exhausted_time_budget: bool = False


PriorityFn = Callable[[TrustState, TrustContext], float]
PruneProposalFn = Callable[[TrustState, TrustContext], bool]
StateObserverFn = Callable[[TrustState, tuple[float, ...], Optional[str]], None]
UnsafeDiscardFn = Callable[[TrustState, TrustContext], bool]


class CertifiedReasoner:
    """Best-first symbolic search gated by the five Paper 3 certificates.

    A proposer can choose which states are certified.  It cannot discard an
    answer itself: the symbolic cascade decides every prune.
    """

    def __init__(
        self,
        context: TrustContext,
        *,
        max_depth: int = 6,
        enforce: bool = True,
        mode: ExecutionMode | str | None = None,
        certificate_kinds: Optional[Iterable[str]] = None,
    ) -> None:
        self.context = context
        self.max_depth = max_depth
        if mode is None:
            mode = ExecutionMode.DEPLOYMENT if enforce else ExecutionMode.SHADOW
        self.mode = ExecutionMode(mode)
        self.enforce = self.mode is ExecutionMode.DEPLOYMENT
        self.certificate_kinds = frozenset(
            certificate_kinds or {"C-PRE", "C-TYPE", "C-DEPTH", "C-SUBSUME", "C-UNSAT"}
        )
        self._rules_by_head: dict[str, list[Rule]] = defaultdict(list)
        for rule in context.kb.rules:
            self._rules_by_head[rule.head.predicate].append(rule)

    def _is_consistent(self, state: TrustState) -> bool:
        if not self.enforce:
            return True
        atoms = [*state.normalized_goals(), *(atom for _, atom in state.normalized_proof())]
        return self.context.derivation_refutation_reason(atoms) is None

    def _expand(self, state: TrustState) -> list[TrustState]:
        if not state.goals:
            return []
        substitution = state.substitution_dict()
        goal = apply_substitution(state.goals[0], substitution)
        rest = state.goals[1:]
        children: list[TrustState] = []
        # Indexed candidates are a sound superset of unifiable EDB facts,
        # in original source order (including duplicates). The original
        # unifier remains the only fact-admission decision. This preserves
        # every child state, proof identity and independent checker trace.
        for fact in self.context.kb.facts_for_goal_ordered(goal):
            updated = unify_atoms(goal, fact, substitution)
            if updated is None:
                continue
            child = TrustState(
                query=state.query,
                goals=rest,
                substitution=tuple(sorted(updated.items())),
                proof=state.proof + (("fact", fact),),
                depth=state.depth,
            )
            if self._is_consistent(child):
                children.append(child)
        for rule in self._rules_by_head.get(goal.predicate, ()):
            if self.context.status_of(rule.name) == REJECTED:
                continue
            fresh = freshen_rule(rule)
            updated = unify_atoms(goal, fresh.head, substitution)
            if updated is None:
                continue
            child = TrustState(
                query=state.query,
                goals=tuple(fresh.body) + rest,
                substitution=tuple(sorted(updated.items())),
                proof=state.proof + ((rule.name, goal),),
                depth=state.depth + 1,
            )
            if self._is_consistent(child):
                children.append(child)
        return children

    def _has_fact_match(self, goal: Atom, substitution: Mapping[str, str]) -> bool:
        grounded = apply_substitution(goal, dict(substitution))
        return any(
            unify_atoms(grounded, fact, dict(substitution)) is not None
            for fact in self.context.kb.facts_maybe_matching(grounded)
        )

    def _has_rule_match(self, goal: Atom, substitution: Mapping[str, str]) -> bool:
        grounded = apply_substitution(goal, dict(substitution))
        for rule in self._rules_by_head.get(grounded.predicate, ()):
            if (
                self.context.status_of(rule.name) != REJECTED
                and unify_atoms(grounded, freshen_rule(rule).head, dict(substitution)) is not None
            ):
                return True
        return False

    def _subsumption_key(self, state: TrustState) -> tuple:
        """Conservatively deduplicate only proof-identical residual states.

        Matching normalized queries and goals alone is UNSOUND: two prefixes
        can have different accumulated schema obligations, and the branch
        explored first might later be refuted. Moreover, distinct trusted/
        candidate proof traces must remain available for provenance auditing.

        Preserve the complete normalized proof trace and substitution in the
        key, not merely the proof trust class or current refutation status.
        This deliberately sacrifices aggressive cycle/subsumption pruning:
        it is exact proof-sensitive deduplication, NOT a general subsumption
        theorem. Keep this conservative guard until a stronger, proved
        implication relation over prefix obligations is available.
        """
        substitution = state.substitution_dict()
        return (
            apply_substitution(state.query, substitution),
            state.normalized_goals(),
            state.normalized_proof(),
            state.substitution,
        )

    def proposer_features(self, state: TrustState) -> tuple[float, ...]:
        """Cheap, label-free state features available before certification."""
        goals = state.normalized_goals()
        terms = [arg for goal in goals for arg in goal.args]
        ground_ratio = (
            sum(not is_variable(term) for term in terms) / len(terms) if terms else 1.0
        )
        first = goals[0] if goals else None
        fact_support = len(self.context.kb.facts_for(first.predicate)) if first else 0
        rule_support = len(self._rules_by_head.get(first.predicate, ())) if first else 0
        candidate_prefix = any(
            name != "fact" and self.context.status_of(name) == CANDIDATE
            for name, _ in state.proof
        )
        return (
            state.depth / max(1, self.max_depth),
            min(len(goals), 8) / 8.0,
            ground_ratio,
            math.log1p(fact_support) / 16.0,
            math.log1p(rule_support) / 8.0,
            float(fact_support == 0),
            float(rule_support == 0),
            float(candidate_prefix),
        )

    def _c_pre(self, state: TrustState) -> Optional[Certificate]:
        goal = state.normalized_goals()[0]
        substitution = state.substitution_dict()
        if not self._has_fact_match(goal, substitution) and not self._has_rule_match(
            goal, substitution
        ):
            return Certificate("C-PRE", goal)
        return None

    def _c_type(self, state: TrustState) -> Optional[Certificate]:
        if not self.enforce:
            return None
        for goal in state.normalized_goals():
            if self.context.refutation_reason(goal) in {
                "domain-violation",
                "range-violation",
                "irreflexivity",
                "functionality",
                "explicit-negative",
            }:
                return Certificate("C-TYPE", goal)
        return None

    def _remaining_lower_bound(self, state: TrustState) -> int:
        substitution = state.substitution_dict()
        lower_bound = 0
        for goal in state.normalized_goals():
            if not self._has_fact_match(goal, substitution) and self._has_rule_match(
                goal, substitution
            ):
                lower_bound += 1
        return lower_bound

    def _c_depth(self, state: TrustState) -> Optional[Certificate]:
        lower_bound = self._remaining_lower_bound(state)
        if state.depth + lower_bound > self.max_depth:
            return Certificate("C-DEPTH", (state.depth, lower_bound, self.max_depth))
        return None

    def _c_unsat(self, state: TrustState) -> Optional[Certificate]:
        """Type-obligation UNSAT without a Z3 runtime dependency.

        The abstraction is deliberately conservative: it only prunes when one
        term is required to inhabit two explicitly disjoint classes.  Ground
        obligations have already been checked by C-TYPE.
        """
        if not self.enforce:
            return None
        conflict = self._type_obligation_conflict(
            state.normalized_goals(), state.substitution_dict()
        )
        return Certificate("C-UNSAT", conflict) if conflict is not None else None

    def _type_obligation_conflict(
        self,
        atoms: Iterable[Atom],
        substitution: Mapping[str, str],
    ) -> Optional[tuple[str, str, str]]:
        """Find an explicitly disjoint pair of type obligations."""
        required: dict[str, set[str]] = defaultdict(set)
        for goal in atoms:
            if len(goal.args) != 2:
                continue
            for term, cls in (
                (goal.args[0], self.context.schema.domain.get(goal.predicate)),
                (goal.args[1], self.context.schema.range_.get(goal.predicate)),
            ):
                if cls:
                    required[resolve(term, substitution)].add(cls)
        for term, classes in required.items():
            ordered = sorted(classes)
            for index, left in enumerate(ordered):
                for right in ordered[index + 1 :]:
                    if self.context.schema.disjoint_pair(left, right):
                        return term, left, right
        return None

    def _completed_proof_is_consistent(self, state: TrustState) -> bool:
        """Validate semantic obligations independently of pruning choices."""
        if not self.enforce:
            return True
        atoms = tuple(atom for _, atom in state.normalized_proof())
        return (
            self.context.derivation_refutation_reason(atoms) is None
            and self._type_obligation_conflict(atoms, {}) is None
        )

    def certify(self, state: TrustState, seen: Mapping[tuple, int]) -> Optional[Certificate]:
        if not state.goals:
            return None
        for kind, checker in (
            ("C-PRE", self._c_pre),
            ("C-TYPE", self._c_type),
            ("C-DEPTH", self._c_depth),
        ):
            if kind not in self.certificate_kinds:
                continue
            certificate = checker(state)
            if certificate is not None:
                return certificate
        key = self._subsumption_key(state)
        previous_depth = seen.get(key)
        if (
            "C-SUBSUME" in self.certificate_kinds
            and previous_depth is not None
            and previous_depth <= state.depth
        ):
            return Certificate("C-SUBSUME", (key, previous_depth))
        return self._c_unsat(state) if "C-UNSAT" in self.certificate_kinds else None

    def search(
        self,
        query: Atom,
        *,
        priority: Optional[PriorityFn] = None,
        propose_prune: Optional[PruneProposalFn] = None,
        certified: bool = True,
        budget: int = 100_000,
        max_seconds: Optional[float] = None,
        observe_state: Optional[StateObserverFn] = None,
        unsafe_discard: Optional[UnsafeDiscardFn] = None,
    ) -> tuple[list[TrustAnswer], SearchStats]:
        started = perf_counter()
        priority = priority or (lambda state, context: -float(state.depth))
        propose_prune = propose_prune or (lambda state, context: True)
        root = TrustState(query=query, goals=(query,))
        frontier: list[tuple[float, int, TrustState]] = []
        counter = itertools.count()
        heapq.heappush(frontier, (-priority(root, self.context), next(counter), root))
        seen: dict[tuple, int] = {}
        answers: list[TrustAnswer] = []
        answer_keys: set[tuple[Atom, tuple[tuple[str, Atom], ...]]] = set()
        pruned: dict[str, int] = defaultdict(int)
        expanded = generated = 0
        proposer_calls = proposer_positive = 0
        certificate_checks = certificate_successes = 0
        certificate_seconds = 0.0

        while (
            frontier
            and expanded < budget
            and (max_seconds is None or perf_counter() - started < max_seconds)
        ):
            _, _, state = heapq.heappop(frontier)
            if state.depth > self.max_depth:
                continue
            # This hook exists only for explicitly uncertified baselines. It
            # is intentionally never consulted by the certified path and is
            # therefore not a ConFIRM safety mechanism.
            if unsafe_discard is not None and not certified and state.goals and unsafe_discard(state, self.context):
                continue
            if not state.goals:
                if not self._completed_proof_is_consistent(state):
                    continue
                claim = apply_substitution(state.query, state.substitution_dict())
                if any(is_variable(arg) for arg in claim.args):
                    continue
                rules_used = tuple(name for name, _ in state.proof if name != "fact")
                normalized_proof = state.normalized_proof()
                key = (claim, normalized_proof)
                if key not in answer_keys:
                    status, reason = classify_proof(
                        self.context,
                        claim,
                        rules_used,
                        (atom for _, atom in normalized_proof),
                    )
                    answers.append(
                        TrustAnswer(claim, normalized_proof, rules_used, status, reason)
                    )
                    answer_keys.add(key)
                continue
            proposal = False
            certificate: Optional[Certificate] = None
            if certified:
                proposer_calls += 1
                proposal = bool(propose_prune(state, self.context))
                proposer_positive += int(proposal)
                if proposal or observe_state is not None:
                    certificate_started = perf_counter()
                    certificate = self.certify(state, seen)
                    certificate_seconds += perf_counter() - certificate_started
                    certificate_checks += 1
                    certificate_successes += int(certificate is not None)
                if observe_state is not None:
                    observe_state(
                        state,
                        self.proposer_features(state),
                        certificate.kind if certificate is not None else None,
                    )
                if proposal and certificate is not None:
                    pruned[certificate.kind] += 1
                    continue
            seen.setdefault(self._subsumption_key(state), state.depth)
            children = self._expand(state)
            expanded += 1
            generated += len(children)
            for child in children:
                heapq.heappush(frontier, (-priority(child, self.context), next(counter), child))
        elapsed_seconds = perf_counter() - started
        # A protected claim can be explicitly contradicted even when all
        # positive branches have been soundly pruned. Expose this as a
        # claim-level negative witness, NOT as a fabricated positive proof.
        # The independent verifier must rederive the contradiction from its
        # operator-controlled facts/negatives/schema; this answer is untrusted.
        #
        # Only certified DEPLOYMENT and a completed search may emit this
        # first-class REFUTED verdict. Shadow/uncertified runs retain their
        # former proof-search semantics. Unknown queries remain undecided.
        if certified and self.enforce and not frontier and not any(
            is_variable(arg) for arg in query.args
        ):
            negative_reason = self.context.refutation_reason(query)
            if negative_reason is not None and not answers:
                answers.append(TrustAnswer(
                    query, (), (), REFUTED, negative_reason
                ))
        exhausted_state_budget = bool(frontier) and expanded >= budget
        exhausted_time_budget = (
            bool(frontier)
            and max_seconds is not None
            and elapsed_seconds >= max_seconds
            and not exhausted_state_budget
        )
        return answers, SearchStats(
            expanded=expanded,
            generated=generated,
            pruned=dict(pruned),
            exhausted_budget=bool(frontier),
            proposer_calls=proposer_calls,
            proposer_positive=proposer_positive,
            certificate_checks=certificate_checks,
            certificate_successes=certificate_successes,
            certificate_seconds=certificate_seconds,
            elapsed_seconds=elapsed_seconds,
            exhausted_state_budget=exhausted_state_budget,
            exhausted_time_budget=exhausted_time_budget,
        )


@dataclass(frozen=True)
class AuditRecord:
    answer: TrustAnswer
    risk_summary: float

    def blame_ranking(self, risk: Callable[[str], float]) -> tuple[str, ...]:
        return tuple(sorted(self.answer.rules_used, key=lambda name: (-risk(name), name)))


@dataclass(frozen=True)
class AttackScenario:
    """A labelled, executable rule-injection test case.

    The protected fact is present in the source KG.  The injected rule derives
    the same functional relation with a fresh object, so the expected outcome
    is known without treating a model score as ground truth.
    """

    family: str
    rule_name: str
    query: Atom
    protected_fact: Atom
    support: tuple[Atom, ...]


class HarmTable:
    def __init__(self) -> None:
        self.used: dict[str, int] = defaultdict(int)
        self.refuted: dict[str, int] = defaultdict(int)

    def observe(self, answer: TrustAnswer) -> None:
        for rule_name in answer.rules_used:
            self.used[rule_name] += 1
            if answer.status == REFUTED:
                self.refuted[rule_name] += 1

    def harm(self, rule_name: str) -> float:
        return self.refuted[rule_name] / self.used[rule_name] if self.used[rule_name] else 0.0


class SequentialEvidenceMonitor:
    """Detect sustained increases in rule-level refutation evidence.

    The monitor uses Page's one-sided cumulative-sum statistic internally, but
    its public name describes its role in ConFIRM rather than one estimator.
    """

    def __init__(
        self, *, baseline: float = 0.05, slack: float = 0.05, threshold: float = 3.0
    ) -> None:
        self.baseline, self.slack, self.threshold = baseline, slack, threshold
        self.score: dict[str, float] = defaultdict(float)
        self.detected: dict[str, int] = {}

    def observe(self, rule_name: str, *, refuted: bool, observation: int) -> float:
        self.score[rule_name] = max(
            0.0, self.score[rule_name] + float(refuted) - self.baseline - self.slack
        )
        if self.score[rule_name] > self.threshold and rule_name not in self.detected:
            self.detected[rule_name] = observation
        return self.score[rule_name]


def audit_answers(
    answers: Iterable[TrustAnswer], harm: Optional[HarmTable] = None
) -> list[AuditRecord]:
    harm = harm or HarmTable()
    answers = list(answers)
    for answer in answers:
        harm.observe(answer)
    return [
        AuditRecord(answer, max((harm.harm(name) for name in answer.rules_used), default=0.0))
        for answer in answers
    ]


def inject_attack(
    context: TrustContext, family: str, *, count: int = 1, seed: int = 0
) -> TrustContext:
    """Inject deterministic Paper 3 A1--A5 candidate rules with forged confidence."""
    rng = random.Random(seed)
    clean = [rule for rule in context.kb.rules if context.status_of(rule.name) != REJECTED]
    if not clean:
        return context
    predicates = sorted({fact.predicate for fact in context.kb.facts})
    additions: list[Rule] = []
    for index in range(count):
        base = clean[index % len(clean)]
        name = f"{family}_{index}"
        if family == "A1":
            if len(base.body) < 2:
                continue
            body = base.body[:-1]
            head = base.head
        elif family == "A2":
            if len(predicates) < 2:
                continue
            head = Atom(rng.choice(predicates), ("?x", "?z"))
            body = (
                Atom(rng.choice(predicates), ("?x", "?y")),
                Atom(rng.choice(predicates), ("?y", "?z")),
            )
        elif family == "A3":
            if not predicates:
                continue
            head = Atom(rng.choice(predicates), ("?x", "?y"))
            body = (Atom(rng.choice(predicates), ("?y", "?x")),)
        elif family == "A4":
            if not predicates:
                continue
            head = Atom(rng.choice(predicates), base.head.args)
            body = base.body
        elif family == "A5":
            if not predicates:
                continue
            predicate = rng.choice(predicates)
            head = Atom(predicate, ("?v0", "?v4"))
            body = tuple(Atom(predicate, (f"?v{step}", f"?v{step + 1}")) for step in range(4))
        else:
            raise ValueError("family must be one of A1, A2, A3, A4, A5")
        additions.append(
            Rule(name=name, head=head, body=body, confidence=max(0.95, base.confidence))
        )
    return context.with_rules(additions, status=CANDIDATE, injected=True)


def build_functionality_attack_suite(
    context: TrustContext,
    *,
    seed: int = 0,
    families: Iterable[str] = ("A1", "A2", "A3", "A4", "A5"),
) -> tuple[TrustContext, tuple[AttackScenario, ...]]:
    """Create deterministic, executable A1--A5 conflict injections.

    Real KG benchmarks generally do not ship complete schema constraints or
    labels for adversarial rules.  This protocol therefore creates *known*
    functionality violations from existing KG facts: only the candidate rule
    is injected, while every premise and protected fact comes from the source
    graph.  The generated rules are grounded intentionally, making attack
    success and refutation labels independently checkable from the artifact.
    """
    requested = tuple(families)
    invalid = set(requested) - {"A1", "A2", "A3", "A4", "A5"}
    if invalid:
        raise ValueError(f"Unknown attack families: {sorted(invalid)}")
    facts = sorted(context.kb.facts, key=lambda atom: (atom.predicate, atom.args))
    if not facts:
        raise ValueError("Cannot create an attack suite without source facts")
    rng = random.Random(seed)
    # Sampling independent indices keeps suite construction reproducible while
    # avoiding assumptions about a dataset's relation vocabulary.
    support_order = list(facts)
    rng.shuffle(support_order)
    additions: list[Rule] = []
    scenarios: list[AttackScenario] = []
    existing_names = {rule.name for rule in context.kb.rules}
    functional = set(context.schema.functional)

    def build_case_rules(
        *, family: str, index: int, protected: Atom, support: tuple[Atom, ...]
    ) -> tuple[list[Rule], str, Atom]:
        """Build a small proof DAG with redundant helpers and one culprit rule."""
        fresh_object = f"__trustkg_attack_{family.lower()}_{index}"
        intermediate = Atom(
            f"__trustkg_mid_{family.lower()}_{index}", (protected.args[0], protected.args[1])
        )
        helper_count = max(2, {"A1": 2, "A2": 3, "A3": 2, "A4": 3, "A5": 4}[family])
        helper_rules: list[Rule] = []
        for helper_index in range(helper_count):
            name = f"{family}_helper_{index}_{helper_index}"
            while name in existing_names:
                name += "_x"
            existing_names.add(name)
            body_atom = support[helper_index % len(support)]
            helper_rules.append(
                Rule(
                    name=name,
                    head=intermediate,
                    body=(body_atom,),
                    confidence=max(0.55, 0.85 - 0.05 * helper_index),
                )
            )
        culprit_name = f"{family}_functionality_conflict_{index}"
        while culprit_name in existing_names:
            culprit_name += "_x"
        existing_names.add(culprit_name)
        culprit_rule = Rule(
            name=culprit_name,
            head=Atom(protected.predicate, (protected.args[0], fresh_object)),
            body=(intermediate,),
            confidence=0.99,
        )
        return (
            [*helper_rules, culprit_rule],
            culprit_name,
            Atom(protected.predicate, (protected.args[0], fresh_object)),
        )

    for index, family in enumerate(requested):
        protected = facts[index % len(facts)]
        support_size = {"A1": 1, "A2": 2, "A3": 1, "A4": 2, "A5": 4}[family]
        support = tuple(
            support_order[(index + offset) % len(support_order)] for offset in range(support_size)
        )
        rules, name, query = build_case_rules(
            family=family, index=index, protected=protected, support=support
        )
        additions.extend(rules)
        scenarios.append(AttackScenario(family, name, query, protected, support))
        functional.add(protected.predicate)
    enriched = TrustContext(
        kb=KnowledgeBase(facts=list(context.kb.facts), rules=[*context.kb.rules, *additions]),
        schema=Schema(
            types=context.schema.types,
            domain=context.schema.domain,
            range_=context.schema.range_,
            disjoint=context.schema.disjoint,
            functional=frozenset(functional),
            irreflexive=context.schema.irreflexive,
        ),
        negatives=context.negatives,
        rule_status={**context.rule_status, **{rule.name: CANDIDATE for rule in additions}},
        injected_rules=frozenset(set(context.injected_rules) | {rule.name for rule in additions}),
    )
    return enriched, tuple(scenarios)
