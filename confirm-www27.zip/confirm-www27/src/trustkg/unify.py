from __future__ import annotations

from itertools import count
from typing import TYPE_CHECKING, Dict, Optional

if TYPE_CHECKING:
    from .kb import Atom, Rule

_fresh_counter = count()


def is_variable(symbol: str) -> bool:
    return symbol.startswith("?")


def resolve(term: str, substitution: Dict[str, str]) -> str:
    seen = set()
    while is_variable(term) and term in substitution and term not in seen:
        seen.add(term)
        term = substitution[term]
    return term


def apply_substitution(atom: Atom, substitution: Dict[str, str]) -> Atom:
    atom_type = type(atom)
    return atom_type(
        predicate=atom.predicate,
        args=tuple(resolve(arg, substitution) for arg in atom.args),
    )


def unify_terms(left: str, right: str, substitution: Dict[str, str]) -> Optional[Dict[str, str]]:
    left = resolve(left, substitution)
    right = resolve(right, substitution)

    if left == right:
        return substitution
    if is_variable(left):
        updated = dict(substitution)
        updated[left] = right
        return updated
    if is_variable(right):
        updated = dict(substitution)
        updated[right] = left
        return updated
    return None


def unify_atoms(left: Atom, right: Atom, substitution: Dict[str, str]) -> Optional[Dict[str, str]]:
    if left.predicate != right.predicate or len(left.args) != len(right.args):
        return None
    updated = dict(substitution)
    for l_arg, r_arg in zip(left.args, right.args):
        updated = unify_terms(l_arg, r_arg, updated)
        if updated is None:
            return None
    return updated


def freshen_rule(rule: Rule) -> Rule:
    suffix = next(_fresh_counter)
    renamed: Dict[str, str] = {}

    def rename_term(term: str) -> str:
        if not is_variable(term):
            return term
        if term not in renamed:
            renamed[term] = f"{term}_{suffix}"
        return renamed[term]

    atom_type = type(rule.head)
    rule_type = type(rule)
    head = atom_type(rule.head.predicate, tuple(rename_term(arg) for arg in rule.head.args))
    body = tuple(
        atom_type(atom.predicate, tuple(rename_term(arg) for arg in atom.args))
        for atom in rule.body
    )
    return rule_type(
        name=f"{rule.name}__{suffix}", head=head, body=body, confidence=rule.confidence
    )
