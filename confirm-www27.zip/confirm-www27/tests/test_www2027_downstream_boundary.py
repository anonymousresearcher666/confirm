"""Adversarial boundary contract for WWW 2027.

IndependentProof is a structured *in-process input contract*, not a
cryptographic token. Only trusted verifier-side code may construct it:
NEVER construct it from a producer JSON status/claimed audit flags.

The production threat boundary must isolate that verifier from an
adversarial producer (e.g., separate process/service and pinned input
hashes). An attacker able to execute arbitrary code within the trusted
consumer process is explicitly outside this Python-level API.
"""
from __future__ import annotations

import pytest

from trustkg.downstream_boundary import (
    Admission, Consumption, IndependentProof, Intent, authorize,
    unsafe_accept_all,
)


PIN = "e" * 64


def verified(status="PROVEN", **overrides):
    data = {
        "claim_status": status,
        "search_replayed": True,
        "verdict_rederived": True,
        "proof_is_complete": True,
        "full_rule_snapshot_sha256": PIN,
        "pinned_snapshot_sha256": PIN,
        "trusted_source_provenance_ok": True,
    }
    data.update(overrides)
    return IndependentProof(**data)


def test_verified_trusted_claim_authorizes_action():
    outcome=authorize(verified(),intent=Intent.SIDE_EFFECT)
    assert outcome==Admission(
        Consumption.EXECUTE, "verified_trusted_proof", True, False
    )


def test_research_display_is_never_a_side_effect_even_for_proven():
    read_only=authorize(verified(),intent=Intent.RESEARCH_DISPLAY)
    assert read_only.decision==Consumption.QUARANTINE
    assert read_only.informational_only
    assert not read_only.authorizes_side_effect


@pytest.mark.parametrize("score",[None,0.0,0.000001,0.5,1.0,float("nan"),float("inf")])
def test_no_risk_score_can_promote_candidate(score):
    proof=verified("HYPOTHESIZED")
    action=authorize(proof,intent=Intent.SIDE_EFFECT,candidate_risk_score=score)
    assert action.decision==Consumption.QUARANTINE
    assert not action.authorizes_side_effect
    info=authorize(proof,intent=Intent.RESEARCH_DISPLAY,candidate_risk_score=score)
    assert info.decision==Consumption.QUARANTINE
    assert info.informational_only and not info.authorizes_side_effect


@pytest.mark.parametrize("field,value",[
    ("search_replayed",False),
    ("verdict_rederived",False),
    ("proof_is_complete",False),
    ("pinned_snapshot_sha256","different-source"),
    ("full_rule_snapshot_sha256","different-digest"),
    ("trusted_source_provenance_ok",False),
])
def test_no_proven_action_without_external_verification(field,value):
    tampered=verified(**{field:value})
    decision=authorize(tampered,intent=Intent.SIDE_EFFECT,candidate_risk_score=0.0)
    assert decision.decision!=Consumption.EXECUTE
    assert not decision.authorizes_side_effect


def test_producer_only_forged_proven_is_quarantined():
    # Malicious producer changed a JSON status to PROVEN but has no
    # verifier-authenticated frontier or independently checked verdict.
    fake=verified(
        "PROVEN",search_replayed=False,verdict_rederived=False,
        proof_is_complete=False,
    )
    assert authorize(fake,intent=Intent.SIDE_EFFECT).decision==Consumption.QUARANTINE


@pytest.mark.parametrize("status",["REFUTED","UNKNOWN","", "PROVE"])
def test_rejected_or_unknown_never_authorizes(status):
    proof=verified(status)
    assert authorize(proof,intent=Intent.SIDE_EFFECT).decision==Consumption.REJECT


def test_permissive_policy_demonstrates_candidate_security_failure():
    assert unsafe_accept_all("HYPOTHESIZED") is True
    assert authorize(verified("HYPOTHESIZED"),intent=Intent.SIDE_EFFECT).authorizes_side_effect is False


def test_invalid_intent_fails_closed():
    with pytest.raises(ValueError):
        authorize(verified(),intent="side_effect")
