"""End-to-end v2 audit: separate-process GO input verifier + tamper matrix.

The test fixture includes a trusted 2-hop GO path and an unsupported
branch to exercise both terminal states and pruning certificates.
"""
from __future__ import annotations

import copy
import json
import os
import subprocess
import sys
from pathlib import Path

from trustkg.independent_transition_audit import (
    TrustedGOIndex, atom, canonical_sha256, replay_trace, trusted_go_snapshot,
)

ROOT = Path(__file__).resolve().parents[1]


def _jsonl(path, rows):
    path.write_text(
        "".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8"
    )


def _fixture(tmp_path):
    directory = tmp_path / "processed"
    directory.mkdir()
    _jsonl(directory / "facts.jsonl", [
        {"predicate": "annotatedTo", "args": ["gene", "GO_0"]},
        {"predicate": "subClassOf", "args": ["GO_0", "GO_1"]},
        {"predicate": "subClassOf", "args": ["GO_1", "GO_2"]},
        {"predicate": "irrelevant", "args": ["a", "b"]},
    ])
    _jsonl(directory / "trusted_rules.jsonl", [{
        "rule_id": "GO_T1",
        "compiled_expression": {
            "head": {"predicate": "annotatedTo", "args": ["?g", "?term"]},
            "body": [
                {"predicate": "annotatedTo", "args": ["?g", "?child"]},
                {"predicate": "subClassOf", "args": ["?child", "?term"]},
            ],
        },
    }])
    _jsonl(directory / "queries.jsonl", [
        {"query": {"predicate": "annotatedTo", "args": ["gene", "GO_2"]}},
        {"query": {"predicate": "missing", "args": ["gene", "none"]}},
    ])
    (directory / "schema.json").write_text("{}\n", encoding="utf-8")
    return directory


def _command(script, *args):
    env = dict(os.environ)
    env["PYTHONPATH"] = str(ROOT / "src")
    return subprocess.run(
        [sys.executable, str(ROOT / "scripts" / script), *map(str, args)],
        cwd=ROOT, env=env, capture_output=True, text=True,
    )


def test_full_transition_replay_and_mutation_rejections(tmp_path):
    processed = _fixture(tmp_path)
    trace = tmp_path / "new_trace.json"
    captured = _command(
        "capture_www2027_go_transition_audit.py",
        "--processed", processed, "--source-indices", "0,1",
        "--max-depth", "3", "--budget", "1000",
        "--max-seconds", "8", "--output", trace,
    )
    assert captured.returncode == 0, captured.stdout + captured.stderr
    data = json.loads(trace.read_text(encoding="utf-8"))
    assert data["passed_capture_completeness"]
    assert data["protocol"] == "independent_go_transition_audit_v2"

    report = tmp_path / "audit_report.json"
    verified = _command(
        "verify_www2027_go_transition_audit.py",
        "--input", trace, "--processed", processed,
        "--source-indices", "0,1",
        "--max-depth", "3", "--output", report,
    )
    assert verified.returncode == 0, verified.stdout + verified.stderr
    outcome = json.loads(report.read_text(encoding="utf-8"))
    assert outcome["passed"], outcome["failures"]
    assert outcome["independent_verdict_reconstruction_passed"] is True
    assert len(outcome["independent_verdict_rows"]) == 2
    assert outcome["certificate_count"] > 0
    assert outcome["results"][0]["checked_children"] > 0

    attacks = _command(
        "evaluate_www2027_transition_attacks.py",
        "--input", trace, "--processed", processed,
        "--source-indices", "0,1",
        "--max-depth", "3",
        "--output", tmp_path / "attacks.json",
    )
    assert attacks.returncode == 0, attacks.stdout + attacks.stderr
    attack_results = json.loads(
        (tmp_path / "attacks.json").read_text(encoding="utf-8")
    )
    assert attack_results["passed"]
    assert attack_results["attacks_run"] >= 10
    assert any(x["name"] == "forge_aggregated_claim_status" and x["detected"]
               for x in attack_results["attacks"])
    assert attack_results["escaped"] == 0

    # Legal transitions with a forged aggregate decision must fail the
    # separate verdict-check phase, not pass merely on frontier replay.
    false_claim = copy.deepcopy(data)
    false_claim["runs"][0]["decision_summary"] = []
    false_file = tmp_path / "forged_verdict.json"
    false_file.write_text(json.dumps(false_claim), encoding="utf-8")
    false_report = tmp_path / "forged_verdict_report.json"
    denied = _command(
        "verify_www2027_go_transition_audit.py",
        "--input", false_file, "--processed", processed,
        "--source-indices", "0,1", "--max-depth", "3",
        "--output", false_report,
    )
    assert denied.returncode != 0
    denied_json = json.loads(false_report.read_text(encoding="utf-8"))
    assert denied_json["independent_verdict_reconstruction_passed"] is False
    assert any(
        x["reason"] == "incorrect_aggregated_verdict_or_proof_counts"
        for x in denied_json["failures"]
    )

    # Independent locally trusted facts, not producer-attached snapshot.
    trusted = trusted_go_snapshot(processed)
    idx = TrustedGOIndex(trusted)
    query = atom("annotatedTo", ["gene", "GO_2"])
    assert data["producer_snapshot_sha256"] == canonical_sha256(trusted)
    assert replay_trace(
        data, [query, atom("missing", ["gene", "none"])],
        idx, max_depth=3,
    )["passed"]

    # Removing a producer state from a genuinely generated frontier fails.
    forged = copy.deepcopy(data)
    forged["queries"][0]["events"].pop(0)
    rejected = replay_trace(
        forged, [query, atom("missing", ["gene", "none"])],
        idx, max_depth=3,
    )
    assert not rejected["passed"]
    assert rejected["failures"]


def test_tampered_external_trusted_source_rejects_original_trace(tmp_path):
    processed = _fixture(tmp_path)
    trace = tmp_path / "trace.json"
    captured = _command(
        "capture_www2027_go_transition_audit.py",
        "--processed", processed, "--source-indices", "0",
        "--max-depth", "3", "--output", trace,
    )
    assert captured.returncode == 0, captured.stdout + captured.stderr
    original = json.loads(trace.read_text(encoding="utf-8"))
    assert original["passed_capture_completeness"]
    # A different trusted KB MUST NOT accept producer trace under old digest.
    (processed / "facts.jsonl").write_text(
        (processed / "facts.jsonl").read_text(encoding="utf-8")
        + json.dumps({"predicate": "missing", "args": ["z", "w"]}) + "\n",
        encoding="utf-8",
    )
    verified = _command(
        "verify_www2027_go_transition_audit.py",
        "--input", trace, "--processed", processed,
        "--source-indices", "0", "--max-depth", "3",
        "--output", tmp_path / "rejected.json",
    )
    assert verified.returncode != 0
    outcome = json.loads(
        (tmp_path / "rejected.json").read_text(encoding="utf-8")
    )
    assert not outcome["passed"]
    assert outcome["producer_digest_matches_trusted_snapshot"] is False


def test_2hop_go_normalized_terminal_claims_do_not_depend_on_trace(tmp_path):
    processed = _fixture(tmp_path)
    trace = tmp_path / "tr.json"
    cap = _command(
        "capture_www2027_go_transition_audit.py",
        "--processed", processed, "--source-indices", "0",
        "--max-depth", "3", "--output", trace,
    )
    assert cap.returncode == 0, cap.stdout + cap.stderr
    original = json.loads(trace.read_text(encoding="utf-8"))
    terminals = [
        e for e in original["queries"][0]["events"]
        if e["type"] == "terminal"
    ]
    assert terminals
    assert any(e["consistent"] for e in terminals)
    assert any(e["type"] == "certificate"
               for e in original["queries"][0]["events"])



def test_subsumption_prior_expansion_history_is_reconstructed(tmp_path):
    """Duplicate real support creates an authentic exact-state C-SUBSUME."""
    processed = tmp_path / "processed"
    processed.mkdir()
    _jsonl(processed / "facts.jsonl", [
        {"predicate": "start", "args": ["a"]},
        {"predicate": "start", "args": ["a"]},
        {"predicate": "finish", "args": ["a"]},
    ])
    _jsonl(processed / "trusted_rules.jsonl", [{
        "rule_id": "derive",
        "compiled_expression": {
            "head": {"predicate": "target", "args": ["?x"]},
            "body": [
                {"predicate": "start", "args": ["?x"]},
                {"predicate": "finish", "args": ["?x"]},
            ],
        },
    }])
    _jsonl(processed / "queries.jsonl", [
        {"query": {"predicate": "target", "args": ["a"]}},
    ])
    (processed / "schema.json").write_text("{}\n", encoding="utf-8")
    trace = tmp_path / "subsumption_trace.json"
    captured = _command(
        "capture_www2027_go_transition_audit.py",
        "--processed", processed, "--source-indices", "0",
        "--max-depth", "3", "--budget", "1000",
        "--output", trace,
    )
    assert captured.returncode == 0, captured.stdout + captured.stderr
    data = json.loads(trace.read_text(encoding="utf-8"))
    certs = [
        x for x in data["queries"][0]["events"]
        if x["type"] == "certificate"
        and x["evidence"]["kind"] == "C-SUBSUME"
    ]
    assert certs, "Expected true exact-state duplicate support"
    verdict = _command(
        "verify_www2027_go_transition_audit.py",
        "--input", trace, "--processed", processed,
        "--source-indices", "0", "--max-depth", "3",
        "--output", tmp_path / "verified.json",
    )
    assert verdict.returncode == 0, verdict.stdout + verdict.stderr
    assert json.loads((tmp_path / "verified.json").read_text())["passed"]

    malicious = copy.deepcopy(data)
    stolen = next(x for x in malicious["queries"][0]["events"]
                  if x["type"] == "certificate"
                  and x["evidence"]["kind"] == "C-SUBSUME")
    stolen["evidence"]["witness"] = {"seen_index": 9999}
    forged = tmp_path / "forged_history_trace.json"
    forged.write_text(json.dumps(malicious), encoding="utf-8")
    rejected = _command(
        "verify_www2027_go_transition_audit.py",
        "--input", forged, "--processed", processed,
        "--source-indices", "0", "--max-depth", "3",
        "--output", tmp_path / "rejected.json",
    )
    assert rejected.returncode != 0
    result = json.loads((tmp_path / "rejected.json").read_text())
    assert not result["passed"]
    assert any(
        failure["reason"] == "invalid_certificate_or_history"
        for failure in result["failures"]
    )
