"""Independently reconstructed terminal proof decisions and adversarial metadata.

Do not import the producer's aggregate_claim_decisions or classify_proof.
These tests include mixed trusted/candidate evidence, refutations, exact
deduplication, missing and forged claim totals.
"""
from __future__ import annotations

import copy

from trustkg.independent_transition_audit import TrustedGOIndex, atom
from trustkg.independent_verdict_audit import (
    reconstructed_decisions, compare_decisions,
)


def _snapshot():
    return {
        "facts": [
            atom("support", ["a"]),
            atom("support", ["b"]),
        ],
        "rules": [
            {
                "name": "T",
                "head": atom("q", ["?x"]),
                "body": [atom("support", ["?x"])],
                "status": "trusted",
            },
            {
                "name": "C",
                "head": atom("q", ["?x"]),
                "body": [atom("support", ["?x"])],
                "status": "candidate",
            },
        ],
        "negatives": [atom("q", ["b"])],
        "schema": {
            "types": {},
            "domain": {},
            "range": {},
            "disjoint": [],
            "functional": [],
            "irreflexive": [],
        },
    }


def _terminal(value, rule):
    return {
        "type": "terminal",
        "consistent": True,
        "state": {
            "query": atom("q", [value]),
            "goals": [],
            "proof": [
                {"rule": rule, "atom": atom("q", [value])},
                {"rule": "fact", "atom": atom("support", [value])},
            ],
            "substitution": [], "depth": 1,
        },
    }


def test_rebuild_mixed_proofs_and_refuted_claim():
    idx = TrustedGOIndex(_snapshot())
    refuted = _terminal("b", "T")
    # Deployment's terminal guard checks proof atoms before the
    # separate classifier checks the claim. A negative proof atom itself
    # would be rejected earlier; keep support ground and unrefuted here.
    refuted["state"]["proof"] = [
        {"rule": "fact", "atom": atom("support", ["b"])}
    ]
    evidence = [
        _terminal("a", "C"),
        _terminal("a", "T"),
        _terminal("a", "C"),  # same exact proof MUST be ignored
        refuted,  # completed support is nonnegative; query is negative
    ]
    decisions = reconstructed_decisions(evidence, idx)
    assert decisions == [
        [atom("q", ["a"]), "PROVEN", 1, 1],
        [atom("q", ["b"]), "REFUTED", 0, 0],
    ]
    only_candidate = reconstructed_decisions([_terminal("a", "C")], idx)
    assert only_candidate == [[atom("q", ["a"]), "HYPOTHESIZED", 0, 1]]


def test_forged_aggregated_verdicts_and_missing_run_are_rejected():
    idx = TrustedGOIndex(_snapshot())
    events = [_terminal("a", "C"), _terminal("a", "T")]
    correct = reconstructed_decisions(events, idx)
    source_indices = [17]
    audit_trace = {
        "queries": [{"source_index": 17, "events": events}],
        "runs": [{
            "source_index": 17, "complete": True,
            "decision_summary": correct,
        }],
    }
    assert compare_decisions(audit_trace, idx, source_indices)["passed"]
    for forged in (
        [], [[atom("q", ["a"]), "HYPOTHESIZED", 0, 2]],
        [[atom("q", ["a"]), "PROVEN", 999, 0]],
        [[atom("q", ["a"]), "REFUTED", 0, 0]],
    ):
        tampered = copy.deepcopy(audit_trace)
        tampered["runs"][0]["decision_summary"] = forged
        assert not compare_decisions(tampered, idx, source_indices)["passed"]
    removed = copy.deepcopy(audit_trace)
    removed["runs"].clear()
    assert not compare_decisions(removed, idx, source_indices)["passed"]


def test_rejected_rule_cannot_produce_valid_terminal():
    snapshot = _snapshot()
    snapshot["rules"][1]["status"] = "rejected"
    idx = TrustedGOIndex(snapshot)
    try:
        reconstructed_decisions([_terminal("a", "C")], idx)
    except ValueError as error:
        assert "rejected" in str(error)
    else:
        raise AssertionError("A rejected rule was accepted as completed proof")
