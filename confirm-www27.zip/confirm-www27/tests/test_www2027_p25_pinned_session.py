"""Preflight: warm independent replay checks full trace rather than cached verdicts."""
from __future__ import annotations
import copy

from trustkg.kb import Atom,KnowledgeBase
from trustkg.trust import TrustContext
from trustkg.independent_transition_audit import (
    TrustedGOIndex,atom,canonical_sha256,trusted_go_snapshot,
)
from capture_www2027_go_transition_audit import capture
from evaluate_www2027_all_certificate_replay import write_processed_fixture
from evaluate_www2027_p25_pinned_verifier_session import (
    verify_one,make_mutants,trusted_query_list,
)


def test_warm_verifier_refuses_changed_event_and_decision(tmp_path):
    fact=Atom("support",("real",))
    ctx=TrustContext(KnowledgeBase(facts=[fact],rules=[]))
    source=tmp_path/"source"
    trusted=write_processed_fixture(source,ctx,fact)
    trace_file=tmp_path/"genuine.json"
    payload=capture(
        processed=source,source_indices=[0],max_depth=3,
        budget=100,max_seconds=10,output=trace_file,
    )
    pin=trusted["snapshot_sha256"]
    snapshot=trusted_go_snapshot(source)
    assert canonical_sha256(snapshot)==pin
    index=TrustedGOIndex(snapshot)
    queries=trusted_query_list(source,[0])
    genuine=verify_one(payload,queries,index,pin,[0],3)
    assert genuine["passed"]
    altered=copy.deepcopy(payload)
    altered["queries"][0]["events"].pop(0)
    assert not verify_one(altered,queries,index,pin,[0],3)["passed"]
    forged=copy.deepcopy(payload)
    forged["runs"][0]["decision_summary"]=[]
    assert not verify_one(forged,queries,index,pin,[0],3)["passed"]


def test_mismatched_external_pin_fails_closed(tmp_path):
    fact=Atom("support",("real",))
    ctx=TrustContext(KnowledgeBase(facts=[fact],rules=[]))
    source=tmp_path/"source"
    meta=write_processed_fixture(source,ctx,fact)
    payload=capture(processed=source,source_indices=[0],max_depth=3,
                    budget=100,max_seconds=10,output=tmp_path/"trace.json")
    snapshot=trusted_go_snapshot(source)
    index=TrustedGOIndex(snapshot)
    checked=verify_one(payload,trusted_query_list(source,[0]),
                       index,"f"*64,[0],3)
    assert checked["passed"] is False
    assert checked["failures"][0]["reason"]=="mismatching_trusted_metadata_or_snapshot"
