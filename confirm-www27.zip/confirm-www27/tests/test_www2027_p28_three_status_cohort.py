"""P2.8: verify 48-query mixed real GO/GAF experiment cohort expectations."""
from __future__ import annotations

from evaluate_www2027_p28_real_kg_three_statuses import (
    pinned_nemo_cases,producer_check,construct,
)


def test_official_nemo_reference_contains_eight_real_positives_and_16_unknown():
    positive,unknown,sha=pinned_nemo_cases()
    assert len(positive)==8
    assert len(unknown)==16
    assert len(sha)==64
    assert sum(x["rule_id"].endswith("cellular_location") for x in positive)==4
    assert sum(x["rule_id"].endswith("process_participation") for x in positive)==4
    assert all(x["source_explicit_fact"] is False for x in positive)
    assert all(x["source_class"]=="real_target_nonentailed_control" for x in unknown)


def test_real_three_status_producer_guard_enforces_all_48_queries():
    q=[{"predicate":"sourcePredicate","args":[str(i)]} for i in range(48)]
    pin="a"*64
    runs=[]
    searches=[]
    for i,query in enumerate(q):
        if i<16:
            decision=[[query,"PROVEN",1,0]]
            run={"complete":True,"decision_summary":decision}
        elif i<32:
            decision=[[query,"REFUTED",0,0]]
            run={"complete":True,"decision_summary":decision,
                 "refutation_witness":{"reason":"explicit-negative"}}
        else:
            run={"complete":True,"decision_summary":[]}
        runs.append(run)
        searches.append({"query":query,"events":[{"x":1}]})
    original={
        "passed_capture_completeness":True,
        "producer_snapshot_sha256":pin,
        "source_indices":list(range(48)),
        "runs":runs,
        "queries":searches,
    }
    assert len(producer_check(original,pin,q))==48
    original["runs"][39]["decision_summary"]=[[q[39],"REFUTED",0,0]]
    try:
        producer_check(original,pin,q)
    except ValueError as err:
        assert "UNKNOWN" in str(err)
    else:
        raise AssertionError("fake REFUTED without evidence was accepted")


def test_real_48_query_manifest_is_pinned_separately_from_unchanged_source(tmp_path):
    # Regression: P2.8 v1 erroneously expected an operator-only query-list
    # revision to change the full trusted facts/rules/schema/negatives digest.
    from trustkg.independent_transition_audit import (
        canonical_sha256, trusted_go_snapshot,
    )
    from evaluate_www2027_gaf_not_real_refutations import sha256_file
    processed, pin, cohort = construct(tmp_path)
    assert cohort["source_queries_sha256"] != cohort["previous_32_query_manifest_sha256"]
    assert cohort["real_GO_T1_positive"] == 8
    assert cohort["real_GO_CAM_T3_T4_positive"] == 8
    assert cohort["genuine_human_mouse_GAF_qualified_negative"] == 16
    assert cohort["real_GO_CAM_unknown_controls"] == 16
    assert len(cohort["query_categories"]) == 48
    assert canonical_sha256(trusted_go_snapshot(processed)) == pin
    assert sha256_file(processed / "queries.jsonl") == cohort["source_queries_sha256"]
