"""W1 Web consumer process: baseline semantics and verification receipt binding.

These cheap tests do not claim network sandboxing, Web provenance
signatures, or biological negative ground truth.
"""
import copy
import hashlib
import json
from www2027_web_consumer_process import (
    check_operator_contract, request_rows, valid_decision,
)


def write_json(path,data):
    path.write_text(json.dumps(data,separators=(",",":"))+"\n",encoding="utf-8")
    return path


def fixture(tmp_path):
    query=[{"predicate":"sourceWebClaim","args":[f"https://example.org/{i}"]}
           for i in range(3)]
    ids=[0,2,4]
    pin="1"*64
    contract={
        "source_sha256":pin,
        "query_manifest_sha256":"2"*64,
        "source_indices":ids,
        "queries":query,
    }
    check_operator_contract(contract)
    status=[
        [[query[0],"PROVEN",1,0]],
        [[query[1],"REFUTED",0,0]],
        [],
    ]
    trace={
        "producer_snapshot_sha256":pin,
        "passed_capture_completeness":True,
        "source_indices":ids,
        "runs":[{"source_index":ids[i],"complete":True,
                 "decision_summary":status[i]} for i in range(3)],
        "queries":[{"source_index":ids[i],"query":query[i],
                    "events":[{"type":"expanded","state":{"a":i}}]}
                   for i in range(3)],
    }
    base={
        "passed":True,
        "independent_verdict_reconstruction_passed":True,
        "trusted_snapshot_sha256":pin,
        "source_indices":ids,
        "independent_verdict_rows":[{
            "source_index":ids[i],"equal":True,"verdicts":status[i]
        } for i in range(3)],
        "failures":[],
    }
    producer=write_json(tmp_path/"untrusted.json",trace)
    base["operator_trace_sha256"]=hashlib.sha256(producer.read_bytes()).hexdigest()
    bfile=write_json(tmp_path/"external_verifier.json",base)
    scenario={
        "name":"case","fixture_id":"main",
        "producer_untrusted_path":str(producer),
        "operator_baseline_report_path":str(bfile),
        "operator_verifier_report_path":str(bfile),
    }
    return contract,trace,base,producer,bfile,scenario


def test_normal_three_way_action_contract(tmp_path):
    contract,_,_,_,_,case=fixture(tmp_path)
    for mode in ("naive_producer_verdict","anchored_final_only",
                 "full_independent_replay"):
        r=request_rows(mode,case,contract)
        assert r["report_accepted"] is True
        assert (r["authorized"],r["refuted"],r["abstained"],r["quarantined"])==(1,1,1,0)


def test_no_promotion_of_candidate_only_evidence():
    q={"predicate":"locatedIn","args":["gene","component"]}
    assert valid_decision([[q,"HYPOTHESIZED",0,1]],q)[0]=="HYPOTHESIZED"
    assert valid_decision([[q,"PROVEN",0,1]],q)[0]=="INVALID"
    assert valid_decision([[q,"REFUTED",1,0]],q)[0]=="INVALID"


def test_post_verification_transcript_swap_is_rejected(tmp_path):
    contract,trace,_,producer,_,case=fixture(tmp_path)
    swapped=copy.deepcopy(trace)
    swapped["queries"][0]["events"].clear()
    write_json(producer,swapped)
    naive=request_rows("naive_producer_verdict",case,contract)
    anchored=request_rows("anchored_final_only",case,contract)
    full=request_rows("full_independent_replay",case,contract)
    assert naive["authorized"]==1
    assert anchored["authorized"]==1 # anchored does not examine the events
    assert full["authorized"]==0 and full["quarantined"]==3
    assert full["report_accepted"] is False


def test_forged_unknown_proven_is_blocked_only_by_verifying_regimes(tmp_path):
    contract,trace,base,producer,bfile,case=fixture(tmp_path)
    trace["runs"][2]["decision_summary"]=[[contract["queries"][2],"PROVEN",1,0]]
    write_json(producer,trace)
    assert request_rows("naive_producer_verdict",case,contract)["authorized"]==2
    assert request_rows("anchored_final_only",case,contract)["quarantined"]==3
    # Simulate a real verifier's structured failure, not a producer claim.
    base["passed"]=False
    base["failures"]=[{"reason":"incorrect_aggregated_verdict_or_proof_counts"}]
    base["operator_trace_sha256"]=hashlib.sha256(producer.read_bytes()).hexdigest()
    write_json(bfile,base)
    assert request_rows("full_independent_replay",case,contract)["quarantined"]==3


def test_fake_verifier_receipt_with_wrong_source_is_rejected(tmp_path):
    contract,_,base,_,report,case=fixture(tmp_path)
    base["trusted_snapshot_sha256"]="0"*64
    write_json(report,base)
    result=request_rows("full_independent_replay",case,contract)
    assert result["report_accepted"] is False
    assert result["authorized"]==0
