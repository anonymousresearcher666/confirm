"""W2 safety: verifier receipt MAC, exact producer bytes, revision and nonce."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path

os.environ["W2_ROLE"]="consumer"
path=Path(__file__).resolve().parents[1]/"experiments/www27/w2/distributed_service.py"
spec=importlib.util.spec_from_file_location("w2_isolated_service",path)
svc=importlib.util.module_from_spec(spec)
spec.loader.exec_module(svc)


def operator(tmp_path):
    contract={
        "revision":"v1","source_pin":"1"*64,"query_manifest_sha256":"2"*64,
        "indices":[0,8,16,32],
        "queries":[
            {"predicate":"annotatedTo","args":["geneA","GO:0001"]},
            {"predicate":"locatedIn","args":["geneB","GO:0002"]},
            {"predicate":"gafQualifiedAssociation","args":["GAF:g","enables","GO:0003",""]},
            {"predicate":"involvedIn","args":["geneC","GO:0004"]},
        ],
    }
    (tmp_path/"active.json").write_text(json.dumps(contract))
    (tmp_path/"receipt.key").write_bytes(b"test-only-32-byte-operator-HMAC-key")
    svc.OPERATOR=tmp_path
    svc.USED_NONCES.clear()
    return contract


def signed(contract,trace,nonce="112233445566778899aabbcc"):
    receipt={
        "protocol":"W2_SOURCE_PINNED_VERIFIER_RECEIPT_v1",
        "source_pin":contract["source_pin"],"revision":contract["revision"],
        "query_manifest_sha256":contract["query_manifest_sha256"],
        "indices":contract["indices"],"trace_sha256":svc.digest(trace),
        "nonce":nonce,"issued_unix":__import__("time").time().__int__(),
        "statuses":["PROVEN","PROVEN","REFUTED","UNKNOWN"],
        "certificate_count":6,"complete_frontier_replay":True,
    }
    return {"receipt":receipt,"mac":svc.signature(receipt)}


def test_valid_consumer_allows_only_independently_proven_and_denies_not(tmp_path):
    c=operator(tmp_path)
    trace={"query":"operator-selected-full-GO","events":[{"type":"expanded"}]}
    nonce="112233445566778899aabbcc"
    r=svc.action_consumer({"trace":trace,"nonce":nonce,
                           "signed_verifier_receipt":signed(c,trace,nonce)})
    assert r["verified_receipt"] is True
    assert (r["authorized"],r["denied_negative"],r["abstained"],r["quarantined"])==(2,1,1,0)


def test_replayed_receipt_is_rejected(tmp_path):
    c=operator(tmp_path)
    trace={"query":"source-data"}
    packet=signed(c,trace)
    message={"trace":trace,"nonce":packet["receipt"]["nonce"],
             "signed_verifier_receipt":packet}
    assert svc.action_consumer(message)["authorized"]==2
    assert svc.action_consumer(message)["quarantined"]==4


def test_trace_change_with_valid_receipt_fails_closed(tmp_path):
    c=operator(tmp_path)
    trace={"query":"source-data","events":["original"]}
    packet=signed(c,trace)
    altered={"query":"source-data","events":[]}
    r=svc.action_consumer({"trace":altered,"nonce":packet["receipt"]["nonce"],
                           "signed_verifier_receipt":packet})
    assert r["authorized"]==0 and r["quarantined"]==4


def test_mac_forgery_and_source_rotation_are_rejected(tmp_path):
    c=operator(tmp_path)
    trace={"a":1}
    original=signed(c,trace)
    tampered=dict(original)
    tampered["mac"]="0"*64
    for packet in (tampered,original):
        if packet is original:
            newer={**c,"revision":"v2","source_pin":"3"*64}
            (tmp_path/"active.json").write_text(json.dumps(newer))
        result=svc.action_consumer({
            "trace":trace,"nonce":original["receipt"]["nonce"],
            "signed_verifier_receipt":packet
        })
        assert result["authorized"]==0 and result["quarantined"]==4


def test_toxiproxy_conditions_are_measured_as_network_cost_not_reasoning():
    # This does NOT run Docker; scientific results require the real campaign.
    assert svc.MAX_DEPTH==3
    assert svc.ROLE=="consumer"
