"""W3 unit checks are NOT empirical trial results."""
from __future__ import annotations
import copy

import pytest

from evaluate_www2027_w3_application_trust_boundary import (
    CASES, EXPECTED, SELECTED, mutate_trace,
    build_operator_contract, summarize_consumption
)


def prepared_one(status):
    query={"predicate":"sourceGrounded","args":["A","B"]}
    return {"queries":[{"query":query,"events":[{"id":"actual_producer_event"}]}],
            "runs":[{"decision_summary":(
                [[query,"PROVEN",1,0]] if status=="PROVEN" else []
            )}]}


def test_status_forgery_changes_only_one_original_unknown_terminal_verdict():
    before=prepared_one("UNKNOWN")
    after=copy.deepcopy(before)
    mutate_trace(after,"false_status")
    assert before["runs"][0]["decision_summary"]==[]
    assert after["runs"][0]["decision_summary"][0][1]=="PROVEN"
    assert after["queries"]==before["queries"]


def test_frontier_deletion_preserves_original_positive_terminal_decision():
    before=prepared_one("PROVEN")
    after=copy.deepcopy(before)
    mutate_trace(after,"remove_frontier")
    assert len(after["queries"][0]["events"])==0
    assert after["runs"]==before["runs"]


def test_attack_must_match_original_state_not_fake_candidate():
    with pytest.raises(ValueError,match="UNKNOWN"):
        mutate_trace(prepared_one("PROVEN"),"false_status")
    with pytest.raises(ValueError,match="PROVEN"):
        mutate_trace(prepared_one("UNKNOWN"),"remove_frontier")
    with pytest.raises(ValueError,match="absent authentic event"):
        z=prepared_one("PROVEN")
        z["queries"][0]["events"]=[]
        mutate_trace(z,"remove_frontier")


def test_query_contract_has_externally_selected_source_indices():
    all_queries={i:{"predicate":"head","args":[str(i)]} for i in SELECTED}
    # Use no producer-transmitted metadata for the operator contract.
    contract={
        "source_sha256":"b"*64,
        "query_manifest_sha256":"c"*64,
        "source_indices":list(SELECTED),
        "queries":[all_queries[i] for i in SELECTED],
    }
    assert len(contract["source_indices"])==8
    assert EXPECTED.count("PROVEN")==4
    assert EXPECTED.count("REFUTED")==2
    assert EXPECTED.count("UNKNOWN")==2
    assert len(CASES)==2


def test_consumer_scenario_summary_uses_its_real_actions():
    name="attack_batch"
    results={}
    for mode in ("naive_producer_verdict","anchored_final_only",
                 "full_independent_replay"):
        results[mode]={"results":[{
            "scenario":name,"authorized":0,"refuted":0,
            "abstained":0,"quarantined":8,"report_accepted":False,
            "actions":[{"action":"QUARANTINE_UNVERIFIED"}]*8,
        }]}
    summary=summarize_consumption(results,name,"whole_batch")
    assert all(
        summary["modes"][mode]["quarantined"]==8
        for mode in results
    )
    assert all(
        summary["modes"][mode]["authorized"]==0
        for mode in results
    )
