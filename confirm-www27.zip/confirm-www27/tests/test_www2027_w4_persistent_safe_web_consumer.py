"""Unit regressions: only tiny toy source for tests, no research claims."""
from __future__ import annotations

import copy
import json

import pytest

from trustkg.kb import Atom,KnowledgeBase
from trustkg.trust import TrustContext
from trustkg.independent_transition_audit import (
    canonical_sha256,trusted_go_snapshot
)
from evaluate_www2027_all_certificate_replay import write_processed_fixture
from capture_www2027_go_transition_audit import capture
from evaluate_www2027_w4_persistent_safe_web_consumer import (
    ATTACKS,no_reused_decision,warm_worker,save_json,bound_attack_source_index
)
from www2027_web_consumer_process import request_rows


def simple_source(tmp_path):
    processed=tmp_path/"operator_source"
    goal=Atom("factualWebRelation",("resourceA","resourceB"))
    ctx=TrustContext(KnowledgeBase(facts=[goal],rules=[]))
    write_processed_fixture(processed,ctx,goal)
    raw=tmp_path/"legitimate.json"
    trace=capture(processed=processed,source_indices=[0],
                  max_depth=3,budget=200,max_seconds=10,output=raw)
    assert trace["passed_capture_completeness"] is True
    pin=canonical_sha256(trusted_go_snapshot(processed))
    return processed,goal,raw,trace,pin


def test_real_trace_alteration_does_not_reuse_decisions():
    x={"producer_snapshot_sha256":"a"*64,
       "queries":[{"query":{"predicate":"x","args":["a"]},
                   "events":[{"state":{"proof":"genuine"}}]}],
       "runs":[{"decision_summary":[[
           {"predicate":"x","args":["a"]},"PROVEN",1,0]]}]}
    untrusted=no_reused_decision(x,"remove_frontier")
    assert len(untrusted["queries"][0]["events"])==0
    assert x["queries"][0]["events"]
    malicious=no_reused_decision(x,"source_pin")
    assert malicious["producer_snapshot_sha256"]=="0"*64
    assert x["producer_snapshot_sha256"]=="a"*64


def test_real_trusted_worker_one_index_and_three_structured_denials(tmp_path):
    processed,goal,raw,trace,pin=simple_source(tmp_path)
    bad1=copy.deepcopy(trace)
    bad1["queries"][0]["events"].pop(0)
    bad2=copy.deepcopy(trace)
    bad2["runs"][0]["decision_summary"]=[]
    bad3=copy.deepcopy(trace)
    bad3["producer_snapshot_sha256"]="0"*64
    candidates=[bad1,bad2,bad3]
    requests=[]
    for i in range(8):
        requests.append({
            "name":f"clean_{i}","query_id":0,"trace_file":str(raw),
            "receipt_file":str(tmp_path/f"receipt_good_{i}.json"),
            "expect_accept":True
        })
    for j,mutant in enumerate(candidates):
        path=tmp_path/f"mutant_{j}.json"
        save_json(path,mutant)
        requests.append({
            "name":f"attack_{j}","query_id":0,
            "trace_file":str(path),
            "receipt_file":str(tmp_path/f"receipt_bad_{j}.json"),
            "expect_accept":False
        })
    manifest=tmp_path/"operator_manifest.json"
    save_json(manifest,requests)
    worker=warm_worker(
        processed,pin,manifest,tmp_path/"full_worker_summary.json")
    assert worker["passed"] is True
    assert worker["source_loaded_once"] is True
    assert worker["index_built_once"] is True
    assert worker["clean_acceptances"]==8
    assert worker["structured_attacker_rejections"]==3
    assert len(worker["requests"])==11
    good=json.loads((tmp_path/"receipt_good_0.json").read_text())
    bad=json.loads((tmp_path/"receipt_bad_0.json").read_text())
    assert good["passed"] is True
    assert good["independent_verdict_reconstruction_passed"] is True
    assert len(good["independent_verdict_rows"])==1
    assert bad["passed"] is False and bad["failures"]


def test_consumer_accepts_warm_receipt_only_for_identical_trace_bytes(tmp_path):
    processed,goal,raw,trace,pin=simple_source(tmp_path)
    requests=[{
        "name":f"replay_{i}","query_id":0,"trace_file":str(raw),
        "receipt_file":str(tmp_path/f"r{i}.json"),"expect_accept":True
    } for i in range(11)]
    path=tmp_path/"manifest.json"
    save_json(path,requests)
    warm_worker(processed,pin,path,tmp_path/"report.json")
    trusted_queries=[json.loads(z)["query"] for z in
                     (processed/"queries.jsonl").read_text().splitlines()]
    contract={
        "source_sha256":pin,
        "query_manifest_sha256":"f"*64,
        "source_indices":[0],"queries":trusted_queries
    }
    scenario={
        "name":"warm_exact",
        "fixture_id":"q0",
        "producer_untrusted_path":str(raw),
        "operator_verifier_report_path":str(tmp_path/"r0.json"),
        "operator_baseline_report_path":str(tmp_path/"r0.json"),
    }
    good=request_rows("full_independent_replay",scenario,contract)
    assert good["report_accepted"] is True
    assert good["authorized"]==1
    tampered=copy.deepcopy(trace)
    tampered["queries"][0]["events"].pop(0)
    altered=tmp_path/"after_operator_accept.json"
    save_json(altered,tampered)
    scenario["producer_untrusted_path"]=str(altered)
    rejected=request_rows("full_independent_replay",scenario,contract)
    assert rejected["report_accepted"] is False
    assert rejected["authorized"]==0
    assert rejected["quarantined"]==1


def test_attack_manifest_positions_do_not_change_from_w3():
    assert ATTACKS["unknown_falsely_proven"]["position"]==6
    assert ATTACKS["proven_frontier_event_removed"]["position"]==2
    assert ATTACKS["proven_source_pin_spoofed"]["position"]==3


def test_w4_application_report_uses_operator_source_id_not_attack_config():
    """Regression for W4 v1 KeyError: 'source_index' in summary."""
    original_queries=[0,1,8,12,16,24,32,40]
    for label,attack in ATTACKS.items():
        assert "source_index" not in attack
        actual=original_queries[attack["position"]]
        captured={"position":attack["position"],"source_index":actual}
        assert bound_attack_source_index(attack,captured,original_queries)==actual
        with pytest.raises(ValueError,match="differs from pinned"):
            bound_attack_source_index(
                attack,{"source_index":-1},original_queries
            )
